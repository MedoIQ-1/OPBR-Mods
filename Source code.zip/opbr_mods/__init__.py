"""OPBR Skin Mods Installer by MedoIQ."""

from .constants import APP_NAME, APP_VERSION, AUTHOR

__all__ = ["APP_NAME", "APP_VERSION", "AUTHOR"]
