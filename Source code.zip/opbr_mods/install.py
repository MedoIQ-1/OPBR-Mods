"""Core mod installation engine.

Everything here is UI-independent so it can be unit-tested headlessly.
"""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import time
import zipfile
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable, Iterable

from .config import Config, human_size, _clear_dir
from .constants import ASSET_EXTENSIONS, PREVIEW_EXTENSIONS, PREVIEW_NAMES
from .util import CancelToken, CancelledError, ModError, safe_name, sha256_file, utcnow

ProgressFn = Callable[[float | None, str], None]

JUNK_EXTENSIONS = {
    ".txt",
    ".md",
    ".url",
    ".lnk",
    ".pdf",
    ".mp4",
    ".webm",
    ".mov",
    ".ini",
    ".log",
    ".ds_store",
}


# --------------------------------------------------------------------------
# data model
# --------------------------------------------------------------------------
@dataclass
class FileRecord:
    rel: str
    target: str
    sha256: str
    size: int
    mtime: float

    def to_dict(self) -> dict:
        return {
            "rel": self.rel,
            "target": self.target,
            "sha256": self.sha256,
            "size": self.size,
            "mtime": self.mtime,
        }

    @classmethod
    def from_dict(cls, raw: dict) -> "FileRecord | None":
        try:
            return cls(
                rel=str(raw.get("rel") or ""),
                target=str(raw.get("target") or ""),
                sha256=str(raw.get("sha256") or ""),
                size=int(raw.get("size") or 0),
                mtime=float(raw.get("mtime") or 0),
            )
        except Exception:
            return None


@dataclass
class Manifest:
    id: str
    title: str
    feed_id: str = ""
    character: str = ""
    author: str = ""
    description: str = ""
    notes: str = ""
    gameplay_url: str = ""
    message_url: str = ""
    source: str = "manual"
    zip_name: str = ""
    source_zip: str = ""
    installed_at: str = ""
    feed_updated_at: str = ""
    preview: str = ""
    restore_only: bool = False
    assets_root: str = ""
    game_mode: str = "global"
    files: list[FileRecord] = field(default_factory=list)
    schema: int = 1
    manifest_path: str = ""

    @property
    def installed_dt(self) -> datetime | None:
        from .util import parse_iso

        return parse_iso(self.installed_at)

    @property
    def total_size(self) -> int:
        return sum(f.size for f in self.files)

    @property
    def size_text(self) -> str:
        return human_size(self.total_size)

    @property
    def preview_path(self) -> Path | None:
        if not self.preview:
            return None
        path = Path(self.preview)
        if path.is_absolute():
            return path if path.exists() else None
        return None

    def to_dict(self) -> dict:
        return {
            "schema": self.schema,
            "id": self.id,
            "feed_id": self.feed_id,
            "title": self.title,
            "character": self.character,
            "author": self.author,
            "description": self.description,
            "notes": self.notes,
            "gameplay_url": self.gameplay_url,
            "message_url": self.message_url,
            "source": self.source,
            "zip_name": self.zip_name,
            "source_zip": self.source_zip,
            "installed_at": self.installed_at,
            "feed_updated_at": self.feed_updated_at,
            "preview": self.preview,
            "restore_only": self.restore_only,
            "assets_root": self.assets_root,
            "game_mode": self.game_mode,
            "files": [f.to_dict() for f in self.files],
        }

    @classmethod
    def from_dict(cls, raw: dict, path: Path | None = None) -> "Manifest | None":
        try:
            files = [FileRecord.from_dict(item) for item in raw.get("files") or []]
            manifest = cls(
                id=str(raw.get("id") or ""),
                title=str(raw.get("title") or "Unnamed mod"),
                feed_id=str(raw.get("feed_id") or ""),
                character=str(raw.get("character") or ""),
                author=str(raw.get("author") or ""),
                description=str(raw.get("description") or ""),
                notes=str(raw.get("notes") or ""),
                gameplay_url=str(raw.get("gameplay_url") or ""),
                message_url=str(raw.get("message_url") or ""),
                source=str(raw.get("source") or "manual"),
                zip_name=str(raw.get("zip_name") or ""),
                source_zip=str(raw.get("source_zip") or ""),
                installed_at=str(raw.get("installed_at") or ""),
                feed_updated_at=str(raw.get("feed_updated_at") or ""),
                preview=str(raw.get("preview") or ""),
                restore_only=bool(raw.get("restore_only")),
                assets_root=str(raw.get("assets_root") or ""),
                game_mode=str(raw.get("game_mode") or "global"),
                files=[f for f in files if f is not None],
                schema=int(raw.get("schema") or 1),
                manifest_path=str(path or ""),
            )
            if not manifest.id:
                return None
            return manifest
        except Exception:
            return None


@dataclass
class PayloadItem:
    source: Path
    rel: str
    target: Path
    target_rel: str
    size: int


@dataclass
class Analysis:
    zip_path: Path
    extract_dir: Path
    assets_root: Path
    payload_root: Path
    original_mode: bool
    items: list[PayloadItem]
    preview_source: Path | None
    preview_bytes: bytes
    title_guess: str
    total_size: int
    conflicts: list[tuple[str, str]] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)

    @property
    def file_count(self) -> int:
        return len(self.items)


@dataclass
class VerifyIssue:
    rel: str
    reason: str


@dataclass
class VerifyResult:
    manifest_id: str
    issues: list[VerifyIssue]
    checked: int

    @property
    def ok(self) -> bool:
        return not self.issues


# --------------------------------------------------------------------------
# manifests
# --------------------------------------------------------------------------
def manifest_path_for(mods_dir: Path, mod_id: str) -> Path:
    return mods_dir / f"{safe_name(mod_id)}.json"


def load_manifests(mods_dir: Path) -> dict[str, Manifest]:
    result: dict[str, Manifest] = {}
    if not mods_dir.exists():
        return result
    for path in sorted(mods_dir.glob("*.json")):
        try:
            raw = json.loads(path.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue
        manifest = Manifest.from_dict(raw, path)
        if manifest is not None:
            result[manifest.id] = manifest
    return result


def save_manifest(mods_dir: Path, manifest: Manifest) -> Path:
    path = manifest_path_for(mods_dir, manifest.id)
    manifest.manifest_path = str(path)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(
        json.dumps(manifest.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    os.replace(tmp, path)
    return path


def remove_manifest(manifest: Manifest, mods_dir: Path) -> None:
    if manifest.manifest_path:
        try:
            Path(manifest.manifest_path).unlink(missing_ok=True)
        except OSError:
            pass
    else:
        try:
            manifest_path_for(mods_dir, manifest.id).unlink(missing_ok=True)
        except OSError:
            pass
    preview = manifest.preview_path
    if preview:
        try:
            preview.unlink(missing_ok=True)
        except OSError:
            pass


def owned_targets(mods_dir: Path) -> dict[str, tuple[str, str]]:
    """target(lowercase) -> (mod title, manifest id)"""
    owned: dict[str, tuple[str, str]] = {}
    for manifest in load_manifests(mods_dir).values():
        for record in manifest.files:
            owned.setdefault(record.target.lower(), (manifest.title, manifest.id))
    return owned


def shared_with(
    manifest: Manifest, all_manifests: dict[str, Manifest]
) -> list[str]:
    targets = {f.target.lower() for f in manifest.files}
    others: list[str] = []
    for other in all_manifests.values():
        if other.id == manifest.id:
            continue
        if any(f.target.lower() in targets for f in other.files):
            others.append(other.title)
    return others


# --------------------------------------------------------------------------
# archive analysis
# --------------------------------------------------------------------------
def prepare_archive(
    zip_path: Path,
    assets_root: Path,
    work_dir: Path,
    conflicts: dict[str, tuple[str, str]] | None = None,
    progress: ProgressFn | None = None,
    cancel: CancelToken | None = None,
) -> Analysis:
    zip_path = Path(zip_path)
    if not zip_path.is_file():
        raise ModError("The selected .zip file does not exist.")
    if zip_path.suffix.lower() != ".zip" or not zipfile.is_zipfile(zip_path):
        raise ModError("manual_invalid_zip")

    assets_root = Path(assets_root)
    if not assets_root.is_dir():
        raise ModError("The game assets folder is not available.")

    extract_dir = work_dir / f"extract_{int(time.time() * 1000)}"
    _safe_extract(zip_path, extract_dir, cancel)

    if progress:
        progress(None, "stage_analyze")

    base = _real_payload_base(extract_dir)
    special, original_mode = _find_special_dir(base)
    payload_root = special or base

    all_files = [p for p in _walk_files(payload_root) if p.is_file()]
    asset_files = [
        p for p in all_files if p.suffix.lower() in {e.lower() for e in ASSET_EXTENSIONS}
    ]
    if not asset_files:
        # Some mods use unusual extensions; fall back to everything that is not
        # documentation, a preview image or a hidden file.
        preview_file = _find_preview(extract_dir)
        asset_files = []
        for path in all_files:
            lower = path.name.lower()
            if path.suffix.lower() in JUNK_EXTENSIONS:
                continue
            if path.suffix.lower() in PREVIEW_EXTENSIONS:
                continue
            if preview_file and path == preview_file:
                continue
            if lower.startswith("."):
                continue
            asset_files.append(path)
    if not asset_files:
        raise ModError("manual_no_files")

    index = _asset_index(assets_root)
    items: list[PayloadItem] = []
    missing: list[str] = []
    ambiguous: list[str] = []
    for source in asset_files:
        rel_path = _clean_rel(source.relative_to(payload_root))
        if not rel_path.parts:
            continue
        rel = rel_path.as_posix()
        target = _resolve_target(assets_root, rel_path, index, ambiguous)
        if target is None:
            missing.append(rel)
            continue
        try:
            if not _is_within(target, assets_root):
                missing.append(rel)
                continue
        except Exception:
            missing.append(rel)
            continue
        items.append(
            PayloadItem(
                source=source,
                rel=rel,
                target=target,
                target_rel=_relative_to(target, assets_root),
                size=source.stat().st_size,
            )
        )

    if not items and missing:
        # Nothing matched at all: this is almost always the wrong game version
        # or a wrong assets folder, so explain how to fix it.
        preview = ", ".join(str(name) for name in missing[:4])
        suffix = "" if len(missing) <= 4 else f" (+{len(missing) - 4} more)"
        raise ModError(
            "Could not find these files in the game folder:\n"
            f"{preview}{suffix}\n\n"
            "Make sure the correct game version is selected in Settings."
        )
    if ambiguous:
        preview = ", ".join(ambiguous[:3])
        raise ModError(
            "These file names exist in more than one game folder, so the target "
            f"is ambiguous:\n{preview}\n\n"
            "Use a mod archive that keeps the original folder structure."
        )
    if not items:
        raise ModError("manual_no_files")

    preview_file = _find_preview(extract_dir)
    preview_bytes = b""
    if preview_file is not None:
        try:
            if preview_file.stat().st_size < 25 * 1024 * 1024:
                preview_bytes = preview_file.read_bytes()
        except OSError:
            preview_bytes = b""

    conflict_list: list[tuple[str, str]] = []
    if conflicts:
        for item in items:
            owner = conflicts.get(str(item.target).lower())
            if owner:
                conflict_list.append((item.target_rel, owner[0]))

    title_guess = _guess_title(zip_path)
    total_size = sum(item.size for item in items)
    return Analysis(
        zip_path=zip_path,
        extract_dir=extract_dir,
        assets_root=assets_root,
        payload_root=payload_root,
        original_mode=original_mode,
        items=items,
        preview_source=preview_file,
        preview_bytes=preview_bytes,
        title_guess=title_guess,
        total_size=total_size,
        conflicts=conflict_list,
        missing=missing,
    )


def cleanup_analysis(analysis: Analysis) -> None:
    _clear_dir(analysis.extract_dir)
    try:
        analysis.extract_dir.rmdir()
    except OSError:
        pass


def _safe_extract(zip_path: Path, dest: Path, cancel: CancelToken | None) -> None:
    dest.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(zip_path) as archive:
            members = archive.infolist()
            for member in members:
                if cancel is not None:
                    cancel.check()
                name = member.filename.replace("\\", "/")
                if not name or name.endswith("/"):
                    continue
                if name.startswith("/") or (len(name) > 1 and name[1] == ":"):
                    continue
                parts = [p for p in name.split("/") if p not in ("", ".")]
                if any(p == ".." for p in parts):
                    continue
                # Skip unix symlinks.
                if (member.external_attr >> 16) & 0o170000 == 0o120000:
                    continue
                target = dest.joinpath(*parts)
                try:
                    if not _is_within(target, dest):
                        continue
                except Exception:
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(member) as src, open(target, "wb") as out:
                    shutil.copyfileobj(src, out, 1024 * 1024)
    except zipfile.BadZipFile as exc:
        raise ModError("manual_invalid_zip") from exc
    except CancelledError:
        raise
    except Exception as exc:
        raise ModError(f"Could not extract the archive: {exc}") from exc


def _walk_files(root: Path) -> Iterable[Path]:
    for dirpath, _dirs, files in os.walk(root):
        for name in files:
            yield Path(dirpath) / name


def _real_payload_base(extract_dir: Path) -> Path:
    """Unwrap a single top-level folder created by 'Compress to zip'.

    A folder literally named ``mod`` or ``original`` is meaningful, so it is
    never unwrapped.
    """
    base = extract_dir
    for _ in range(2):
        try:
            entries = list(base.iterdir())
        except OSError:
            return base
        files = [e for e in entries if e.is_file()]
        dirs = [e for e in entries if e.is_dir()]
        if (
            not files
            and len(dirs) == 1
            and dirs[0].name.lower() not in ("mod", "original")
        ):
            base = dirs[0]
        else:
            break
    return base


def _find_special_dir(base: Path) -> tuple[Path | None, bool]:
    """Find a 'mod' or 'original' folder (case-insensitive)."""
    try:
        entries = [e for e in base.iterdir() if e.is_dir()]
    except OSError:
        return None, False
    for entry in entries:
        if entry.name.lower() == "mod":
            return entry, False
    for entry in entries:
        if entry.name.lower() == "original":
            return entry, True
    # One level deeper (wrapper folder that contains mod/original).
    for entry in entries:
        try:
            subs = [s for s in entry.iterdir() if s.is_dir()]
        except OSError:
            continue
        for sub in subs:
            if sub.name.lower() == "mod":
                return sub, False
        for sub in subs:
            if sub.name.lower() == "original":
                return sub, True
    return None, False


def _clean_rel(rel: Path) -> Path:
    parts = [p for p in rel.parts if p not in ("", ".")]
    while parts and parts[0].lower() in ("streamingassets", "assets"):
        parts.pop(0)
    return Path(*parts) if parts else Path()


def _asset_index(root: Path) -> dict[str, list[Path]]:
    index: dict[str, list[Path]] = {}
    for dirpath, _dirs, files in os.walk(root):
        for name in files:
            path = Path(dirpath) / name
            index.setdefault(name.lower(), []).append(path)
    return index


def _resolve_target(
    assets_root: Path,
    rel: Path,
    index: dict[str, list[Path]],
    ambiguous: list[str],
) -> Path | None:
    direct = assets_root / rel
    try:
        if direct.is_file():
            return direct
    except OSError:
        pass

    candidates = index.get(rel.name.lower(), [])
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]

    # Prefer the candidate whose tail matches the archive path.
    rel_parts = [p.lower() for p in rel.parts]
    best_score = -1
    best: list[Path] = []
    for candidate in candidates:
        cand_parts = [p.lower() for p in candidate.parts]
        score = 0
        for a, b in zip(reversed(rel_parts), reversed(cand_parts)):
            if a == b:
                score += 1
            else:
                break
        if score > best_score:
            best_score = score
            best = [candidate]
        elif score == best_score:
            best.append(candidate)
    if len(best) == 1:
        return best[0]
    ambiguous.append(str(rel))
    return None


def _find_preview(root: Path) -> Path | None:
    images: list[Path] = []
    named: list[Path] = []
    for path in _walk_files(root):
        if path.suffix.lower() not in PREVIEW_EXTENSIONS:
            continue
        images.append(path)
        stem = path.stem.lower()
        if any(stem == n or stem.startswith(n + "_") or stem.startswith(n + "-") for n in PREVIEW_NAMES):
            named.append(path)
        elif "preview" in stem:
            named.append(path)
    pool = named or images
    if not pool:
        return None
    pool.sort(key=lambda p: (len(p.parts), len(p.name)))
    return pool[0]


def _guess_title(zip_path: Path) -> str:
    stem = zip_path.stem
    stem = stem.replace("_", " ").replace("-", " ").strip()
    return " ".join(stem.split())[:120] or "Imported mod"


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False
    except OSError:
        return False


def _relative_to(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except Exception:
        try:
            return path.relative_to(root).as_posix()
        except Exception:
            return path.name


# --------------------------------------------------------------------------
# install / restore / uninstall
# --------------------------------------------------------------------------
def install_analysis(
    analysis: Analysis,
    mods_dir: Path,
    changelog_path: Path,
    *,
    title: str = "",
    character: str = "",
    author: str = "",
    description: str = "",
    notes: str = "",
    gameplay_url: str = "",
    message_url: str = "",
    feed_id: str = "",
    feed_updated_at: str = "",
    source: str = "manual",
    source_zip: str = "",
    game_mode: str = "global",
    existing: Manifest | None = None,
    auto_clear: bool = True,
    progress: ProgressFn | None = None,
    cancel: CancelToken | None = None,
) -> Manifest:
    if analysis.original_mode:
        raise ModError("This archive contains original files; use restore instead.")
    if not analysis.items:
        raise ModError("manual_no_files")

    total = max(1, len(analysis.items))
    mod_id = feed_id or f"manual_{int(time.time())}_{safe_name(analysis.zip_path.stem)}"
    target_set = {str(item.target).lower() for item in analysis.items}

    # On upgrade, delete files from the old version that are not part of the
    # new one so we never leave stale assets behind.
    if existing is not None and existing.files:
        for record in existing.files:
            if record.target.lower() in target_set:
                continue
            try:
                target = Path(record.target)
                if _is_within(target, Path(analysis.assets_root)) and target.is_file():
                    target.unlink()
            except OSError:
                continue

    records: list[FileRecord] = []
    for index, item in enumerate(analysis.items, start=1):
        if cancel is not None:
            cancel.check()
        item.target.parent.mkdir(parents=True, exist_ok=True)
        digest = _copy_with_hash(item.source, item.target, cancel)
        try:
            stat = item.target.stat()
            size = stat.st_size
            mtime = stat.st_mtime
        except OSError:
            size = item.size
            mtime = time.time()
        records.append(
            FileRecord(
                rel=item.target_rel,
                target=str(item.target),
                sha256=digest,
                size=size,
                mtime=mtime,
            )
        )
        if progress:
            progress(index / total, "stage_install")

    manifest = Manifest(
        id=mod_id,
        feed_id=feed_id,
        title=title or analysis.title_guess,
        character=character,
        author=author,
        description=description,
        notes=notes,
        gameplay_url=gameplay_url,
        message_url=message_url,
        source=source,
        zip_name=analysis.zip_path.name,
        source_zip=source_zip if source_zip and Path(source_zip).is_file() else "",
        installed_at=utcnow().isoformat(),
        feed_updated_at=feed_updated_at,
        restore_only=False,
        assets_root=str(analysis.assets_root),
        game_mode=game_mode,
        files=records,
    )

    if analysis.preview_bytes:
        preview_name = f"{safe_name(mod_id)}_preview.png"
        preview_path = mods_dir / preview_name
        try:
            preview_path.write_bytes(analysis.preview_bytes)
            manifest.preview = str(preview_path)
        except OSError:
            manifest.preview = ""

    save_manifest(mods_dir, manifest)
    append_changelog(
        changelog_path,
        "install",
        manifest,
        extra={"updated": existing is not None},
    )
    if auto_clear:
        cleanup_analysis(analysis)
    if progress:
        progress(1.0, "stage_finalize")
    return manifest


def restore_analysis(
    analysis: Analysis,
    mods_dir: Path,
    changelog_path: Path,
    *,
    auto_clear: bool = True,
    progress: ProgressFn | None = None,
    cancel: CancelToken | None = None,
) -> int:
    """Copy 'original' files back and drop mod records that owned them."""
    if not analysis.original_mode:
        raise ModError("This is not an original/restore archive.")
    total = max(1, len(analysis.items))
    restored_targets: set[str] = set()
    for index, item in enumerate(analysis.items, start=1):
        if cancel is not None:
            cancel.check()
        item.target.parent.mkdir(parents=True, exist_ok=True)
        _copy_with_hash(item.source, item.target, cancel)
        restored_targets.add(str(item.target).lower())
        if progress:
            progress(index / total, "stage_install")

    manifests = load_manifests(mods_dir)
    for manifest in manifests.values():
        remaining = [f for f in manifest.files if f.target.lower() not in restored_targets]
        if len(remaining) == len(manifest.files):
            continue
        if not remaining:
            remove_manifest(manifest, mods_dir)
        else:
            manifest.files = remaining
            save_manifest(mods_dir, manifest)
    append_changelog(
        changelog_path,
        "restore",
        None,
        extra={
            "files": len(restored_targets),
            "title": analysis.title_guess,
            "assets": str(analysis.assets_root),
        },
    )
    if auto_clear:
        cleanup_analysis(analysis)
    if progress:
        progress(1.0, "stage_finalize")
    return len(restored_targets)


def uninstall_manifest(
    manifest: Manifest,
    mods_dir: Path,
    changelog_path: Path,
    *,
    force: bool = False,
    progress: ProgressFn | None = None,
    cancel: CancelToken | None = None,
) -> int:
    assets_root = Path(manifest.assets_root) if manifest.assets_root else None
    deleted = 0
    total = max(1, len(manifest.files))
    for index, record in enumerate(manifest.files, start=1):
        if cancel is not None and not force:
            cancel.check()
        target = Path(record.target)
        allowed = True
        if assets_root is not None:
            try:
                allowed = _is_within(target, assets_root)
            except Exception:
                allowed = False
        elif not force:
            allowed = False
        if allowed and target.is_file():
            try:
                target.unlink()
                deleted += 1
            except OSError:
                if not force:
                    raise ModError(f"Could not delete {target.name}. Is the game running?")
        if progress:
            progress(index / total, "stage_uninstall")
    remove_manifest(manifest, mods_dir)
    append_changelog(
        changelog_path,
        "purge" if force else "uninstall",
        manifest,
        extra={"deleted": deleted},
    )
    if progress:
        progress(1.0, "stage_finalize")
    return deleted


def verify_manifest(
    manifest: Manifest,
    progress: ProgressFn | None = None,
    cancel: CancelToken | None = None,
) -> VerifyResult:
    issues: list[VerifyIssue] = []
    total = max(1, len(manifest.files))
    for index, record in enumerate(manifest.files, start=1):
        if cancel is not None:
            cancel.check()
        target = Path(record.target)
        try:
            if not target.is_file():
                issues.append(VerifyIssue(record.rel or target.name, "missing"))
                continue
            stat = target.stat()
            if int(stat.st_size) != int(record.size):
                issues.append(VerifyIssue(record.rel or target.name, "size"))
                continue
            if abs(float(stat.st_mtime) - float(record.mtime)) > 1.0:
                # Timestamp changed: verify the actual bytes before flagging it.
                try:
                    digest = sha256_file(target, cancel)
                except CancelledError:
                    raise
                except OSError:
                    issues.append(VerifyIssue(record.rel or target.name, "modified"))
                    continue
                if digest != record.sha256:
                    issues.append(VerifyIssue(record.rel or target.name, "hash"))
                else:
                    issues.append(VerifyIssue(record.rel or target.name, "date"))
        except OSError:
            issues.append(VerifyIssue(record.rel or target.name, "missing"))
        if progress:
            progress(index / total, "stage_verify")
    return VerifyResult(manifest.id, issues, len(manifest.files))


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def _copy_with_hash(src: Path, dst: Path, cancel: CancelToken | None = None) -> str:
    digest = hashlib.sha256()
    tmp = dst.with_name(dst.name + ".opbrtmp")
    try:
        with open(src, "rb") as fh_in, open(tmp, "wb") as fh_out:
            while True:
                if cancel is not None:
                    cancel.check()
                chunk = fh_in.read(1024 * 1024)
                if not chunk:
                    break
                digest.update(chunk)
                fh_out.write(chunk)
        os.replace(tmp, dst)
    except Exception:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass
        raise
    return digest.hexdigest()


def append_changelog(
    changelog_path: Path,
    event: str,
    manifest: Manifest | None,
    extra: dict | None = None,
) -> None:
    entry = {
        "ts": utcnow().isoformat(),
        "event": event,
        "id": manifest.id if manifest else "",
        "title": manifest.title if manifest else "",
        "files": len(manifest.files) if manifest else 0,
        "size": manifest.total_size if manifest else 0,
        "assets": manifest.assets_root if manifest else "",
        "game": manifest.game_mode if manifest else "",
    }
    if manifest and manifest.source:
        entry["source"] = manifest.source
    if extra:
        entry.update(extra)
    try:
        changelog_path.parent.mkdir(parents=True, exist_ok=True)
        with open(changelog_path, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except OSError:
        pass


def read_changelog(changelog_path: Path, limit: int = 300) -> list[dict]:
    if not changelog_path.exists():
        return []
    entries: list[dict] = []
    try:
        with open(changelog_path, "r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    item = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(item, dict):
                    entries.append(item)
    except OSError:
        return []
    entries.reverse()
    return entries[:limit]
