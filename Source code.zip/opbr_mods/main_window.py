"""Frameless main window with sidebar navigation and custom title bar."""

from __future__ import annotations

import logging
from pathlib import Path

from PySide6.QtCore import (
    QEasingCurve,
    QEvent,
    QPoint,
    QPropertyAnimation,
    QRect,
    QRectF,
    QSize,
    Qt,
    QThreadPool,
    QTimer,
    Signal,
)
from PySide6.QtGui import (
    QColor,
    QCursor,
    QFont,
    QGuiApplication,
    QIcon,
    QPainter,
    QPen,
    QPixmap,
)
from PySide6.QtWidgets import (
    QApplication,
    QFrame,
    QGraphicsOpacityEffect,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QSizeGrip,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from . import i18n
from .config import Config
from .constants import (
    APP_NAME,
    APP_SHORT,
    APP_VERSION,
    AUTHOR,
    DISCORD_INVITE,
    DISCORD_NAME,
    LANGUAGES,
)
from .context import AppContext
from .paths import detect_games
from .steam import launch_game
from .util import open_url
from .ui import icons
from .ui.cards import ModCard
from .ui.common import (
    FxButton,
    IconButton,
    LogoMark,
    NavButton,
    ToastHost,
    _alpha,
    set_animations,
)
from .ui.dialogs_extra import DonateDialog, FirstRunDialog
from .ui.page_base import BasePage
from .ui.page_browse import BrowsePage
from .ui.page_installed import InstalledPage
from .ui.page_manual import ManualPage
from .ui.page_settings import SettingsPage
from .ui.workers import Worker
from .ui.theme import (
    BG,
    BORDER,
    BORDER_HI,
    CYAN,
    GREEN,
    MUTED,
    ORANGE,
    RED,
    SURFACE,
    TEXT,
    TEXT_DIM,
    YELLOW,
    body_font,
    heading_font,
)

log = logging.getLogger(__name__)

PAGE_TITLES = {
    "browse": ("nav_browse", "grid"),
    "installed": ("nav_installed", "box"),
    "manual": ("nav_manual", "download"),
    "settings": ("nav_settings", "gear"),
}

MIN_WIDTH = 1080
MIN_HEIGHT = 700


class ResizeHandle(QWidget):
    """Invisible edge/corner handle used to resize a frameless window."""

    def __init__(self, direction: str, parent: QWidget) -> None:
        super().__init__(parent)
        self.direction = direction
        self._origin: QPoint | None = None
        self._geometry: QRect | None = None
        cursors = {
            "l": Qt.CursorShape.SizeHorCursor,
            "r": Qt.CursorShape.SizeHorCursor,
            "t": Qt.CursorShape.SizeVerCursor,
            "b": Qt.CursorShape.SizeVerCursor,
            "tl": Qt.CursorShape.SizeFDiagCursor,
            "br": Qt.CursorShape.SizeFDiagCursor,
            "tr": Qt.CursorShape.SizeBDiagCursor,
            "bl": Qt.CursorShape.SizeBDiagCursor,
        }
        self.setCursor(cursors.get(direction, Qt.CursorShape.ArrowCursor))
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, False)

    def mousePressEvent(self, event) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            window = self.window()
            if window is not None and not window.isMaximized():
                self._origin = event.globalPosition().toPoint()
                self._geometry = window.geometry()
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:  # noqa: N802
        if self._origin is None or self._geometry is None:
            return
        window = self.window()
        if window is None or window.isMaximized():
            return
        delta = event.globalPosition().toPoint() - self._origin
        geo = QRect(self._geometry)
        d = self.direction
        min_w, min_h = MIN_WIDTH, MIN_HEIGHT
        if "l" in d:
            new_left = min(geo.left() + delta.x(), geo.right() - min_w)
            geo.setLeft(new_left)
        if "r" in d:
            geo.setRight(max(geo.left() + min_w, geo.right() + delta.x()))
        if "t" in d:
            new_top = min(geo.top() + delta.y(), geo.bottom() - min_h)
            geo.setTop(new_top)
        if "b" in d:
            geo.setBottom(max(geo.top() + min_h, geo.bottom() + delta.y()))
        window.setGeometry(geo)
        event.accept()

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        self._origin = None
        self._geometry = None
        super().mouseReleaseEvent(event)


class TitleBar(QWidget):
    def __init__(self, window: "MainWindow") -> None:
        super().__init__(window)
        self._window = window
        self._drag_origin: QPoint | None = None
        self.setFixedHeight(58)
        self.setObjectName("TitleBar")

        layout = QHBoxLayout(self)
        layout.setContentsMargins(18, 8, 12, 8)
        layout.setSpacing(12)

        self.logo = LogoMark(34)
        layout.addWidget(self.logo, 0, Qt.AlignmentFlag.AlignVCenter)

        titles = QVBoxLayout()
        titles.setSpacing(0)
        self.title_label = QLabel(APP_SHORT)
        self.title_label.setFont(heading_font(14.0, QFont.Weight.Black))
        self.title_label.setStyleSheet("color: #FFFFFF; letter-spacing: 1.4px;")
        titles.addWidget(self.title_label)
        self.sub_label = QLabel("SKIN MODS INSTALLER")
        self.sub_label.setFont(body_font(7.4, QFont.Weight.Bold))
        self.sub_label.setStyleSheet(f"color: {MUTED}; letter-spacing: 2.2px;")
        titles.addWidget(self.sub_label)
        layout.addLayout(titles)
        layout.addStretch(1)

        self.launch_btn = FxButton(
            i18n.tr("launch_game"), self, variant="cyan", height=32, icon_name="play"
        )
        self.launch_btn.setMinimumWidth(136)
        self.launch_btn.clicked.connect(window.launch_game)
        layout.addWidget(self.launch_btn, 0, Qt.AlignmentFlag.AlignVCenter)

        self.min_btn = IconButton("minimize", self, size=32, icon_size=13)
        self.min_btn.setToolTip("Minimize")
        self.min_btn.clicked.connect(window.showMinimized)
        layout.addWidget(self.min_btn)

        self.max_btn = IconButton("maximize", self, size=32, icon_size=13)
        self.max_btn.setToolTip("Maximize")
        self.max_btn.clicked.connect(window.toggle_maximize)
        layout.addWidget(self.max_btn)

        self.close_btn = IconButton(
            "close", self, size=32, icon_size=13, danger=True
        )
        self.close_btn.setToolTip("Close")
        self.close_btn.clicked.connect(window.close)
        layout.addWidget(self.close_btn)

    def mousePressEvent(self, event) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_origin = (
                event.globalPosition().toPoint() - self._window.frameGeometry().topLeft()
            )
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:  # noqa: N802
        if self._drag_origin is not None and not self._window.isMaximized():
            self._window.move(event.globalPosition().toPoint() - self._drag_origin)
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        self._drag_origin = None
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self._window.toggle_maximize()
            event.accept()
            return
        super().mouseDoubleClickEvent(event)


class Sidebar(QWidget):
    def __init__(self, window: "MainWindow") -> None:
        super().__init__(window)
        self._window = window
        self.setFixedWidth(236)
        self.setObjectName("Sidebar")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 18, 14, 18)
        layout.setSpacing(6)

        label = QLabel(i18n.tr("app_short"))
        label.setFont(body_font(7.6, QFont.Weight.Bold))
        label.setStyleSheet(f"color: {MUTED}; letter-spacing: 2.0px; padding-left: 8px;")
        layout.addWidget(label)
        layout.addSpacing(6)

        self.nav_buttons: dict[str, NavButton] = {}
        for key, (title_key, icon_name) in PAGE_TITLES.items():
            button = NavButton(i18n.tr(title_key), icon_name)
            button.clicked.connect(lambda _c=False, k=key: window.navigate(k))
            layout.addWidget(button)
            self.nav_buttons[key] = button

        layout.addSpacing(14)
        layout.addStretch(1)

        donate = FxButton(
            i18n.tr("sidebar_donate"),
            self,
            variant="binance",
            height=34,
            icon_name="heart",
        )
        donate.setToolTip(i18n.tr("donate_title"))
        donate.clicked.connect(lambda: DonateDialog(self._window).exec())
        layout.addWidget(donate)

        discord = FxButton(
            i18n.tr("sidebar_discord"),
            self,
            variant="discord",
            height=34,
            icon_name="discord",
        )
        discord.setToolTip(DISCORD_INVITE)
        discord.clicked.connect(lambda: open_url(DISCORD_INVITE))
        layout.addWidget(discord)
        layout.addSpacing(8)

        tip = QLabel(i18n.tr("settings_warning"))
        tip.setWordWrap(True)
        tip.setFont(body_font(8.2))
        tip.setStyleSheet(
            f"color: {YELLOW}; background: rgba(255, 210, 63, 0.06);"
            "border: 1px solid rgba(255, 210, 63, 0.20); border-radius: 9px;"
            "padding: 9px 10px;"
        )
        layout.addWidget(tip)
        layout.addSpacing(10)

        credit = QLabel(f"{i18n.tr('settings_made_by')} {AUTHOR}  ·  {DISCORD_NAME}")
        credit.setFont(body_font(8.0, QFont.Weight.DemiBold))
        credit.setStyleSheet(f"color: {MUTED};")
        credit.setWordWrap(True)
        layout.addWidget(credit)

        version = QLabel(f"v{APP_VERSION}")
        version.setFont(body_font(7.6))
        version.setStyleSheet(f"color: #5C5C68;")
        layout.addWidget(version)


class ContentHost(QWidget):
    def __init__(self, window: "MainWindow") -> None:
        super().__init__(window)
        self._window = window
        self.setObjectName("ContentHost")
        from .ui.common import Backdrop

        self.grid = QGridLayout(self)
        self.grid.setContentsMargins(0, 0, 0, 0)
        self.grid.setSpacing(0)
        self.backdrop = Backdrop(self)
        self.grid.addWidget(self.backdrop, 0, 0)
        self.pages = QStackedWidget(self)
        self.pages.setObjectName("Pages")
        self.grid.addWidget(self.pages, 0, 0)
        self.toasts = ToastHost(self)
        self.toasts.setGeometry(self.rect())
        self.toasts.raise_()

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self.toasts.setGeometry(self.rect())
        self.toasts.raise_()


class MainWindow(QMainWindow):
    def __init__(self, config: Config | None = None) -> None:
        super().__init__()
        self.config = config or Config()
        self.ctx = AppContext(self.config)
        self._workers: set = set()
        self._page_widgets: dict[str, BasePage] = {}
        self._current_key = "browse"
        self._resize_handles: list[ResizeHandle] = []
        self._fade_anim: QPropertyAnimation | None = None
        self._auto_detect_running = False

        self.setWindowTitle(APP_NAME)
        self.setWindowIcon(icons.app_icon())
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setMinimumSize(MIN_WIDTH, MIN_HEIGHT)
        width, height = self.config.window_size()
        self.resize(width, height)

        self._root_holder = QWidget(self)
        self._root_holder.setObjectName("RootHolder")
        self.setCentralWidget(self._root_holder)
        self._outer = QVBoxLayout(self._root_holder)
        self._outer.setContentsMargins(12, 12, 12, 12)
        self._outer.setSpacing(0)

        self._apply_direction()
        self._build_ui()
        self._build_resize_handles()

        self._autosave_timer = QTimer(self)
        self._autosave_timer.setSingleShot(True)
        self._autosave_timer.setInterval(500)
        self._autosave_timer.timeout.connect(self._save_geometry)

        self._first_run_timer = QTimer(self)
        self._first_run_timer.setSingleShot(True)
        self._first_run_timer.setInterval(320)
        self._first_run_timer.timeout.connect(self._maybe_first_run)

        self.navigate("browse")
        self._first_run_timer.start()
        QTimer.singleShot(400, self.auto_detect_game)

    # ----------------------------------------------------------------- build
    def _build_ui(self) -> None:
        if self._fade_anim is not None:
            try:
                self._fade_anim.stop()
            except Exception:
                pass
            self._fade_anim = None
        for handle in self._resize_handles:
            try:
                handle.setParent(None)
                handle.deleteLater()
            except Exception:
                pass
        self._resize_handles = []

        old_root = getattr(self, "root", None)
        if old_root is not None:
            self._outer.removeWidget(old_root)
            old_root.setParent(None)
            old_root.deleteLater()

        self.root = QFrame(self._root_holder)
        self.root.setObjectName("RootFrame")
        self._outer.addWidget(self.root)

        layout = QVBoxLayout(self.root)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.title_bar = TitleBar(self)
        layout.addWidget(self.title_bar)

        divider = QFrame()
        divider.setFixedHeight(1)
        divider.setStyleSheet(f"background: {BORDER};")
        layout.addWidget(divider)

        body = QWidget()
        body_layout = QHBoxLayout(body)
        body_layout.setContentsMargins(0, 0, 0, 0)
        body_layout.setSpacing(0)
        self.sidebar = Sidebar(self)
        body_layout.addWidget(self.sidebar)
        self.content = ContentHost(self)
        body_layout.addWidget(self.content, 1)
        layout.addWidget(body, 1)

        # Pages
        self._page_widgets = {}
        for key in ("browse", "installed", "manual", "settings"):
            page = self._make_page(key)
            if page is None:
                continue
            self._page_widgets[key] = page
            self.content.pages.addWidget(page)

        self.content.toasts.raise_()
        self._sync_nav()

    def _make_page(self, key: str) -> BasePage | None:
        if key == "browse":
            return BrowsePage(self.ctx, self)
        if key == "installed":
            return InstalledPage(self.ctx, self)
        if key == "manual":
            return ManualPage(self.ctx, self)
        if key == "settings":
            page = SettingsPage(self.ctx, self)
            page.language_changed.connect(self.apply_language)
            return page
        return None

    def _build_resize_handles(self) -> None:
        for direction in ("tl", "t", "tr", "l", "r", "bl", "b", "br"):
            handle = ResizeHandle(direction, self._root_holder)
            handle.raise_()
            self._resize_handles.append(handle)
        self._layout_handles()

    def _layout_handles(self) -> None:
        if not self._resize_handles:
            return
        host = self._root_holder
        w, h = host.width(), host.height()
        thickness = 6
        corner = 14
        mapping = {
            "tl": QRect(0, 0, corner, corner),
            "t": QRect(corner, 0, max(0, w - corner * 2), thickness),
            "tr": QRect(w - corner, 0, corner, corner),
            "l": QRect(0, corner, thickness, max(0, h - corner * 2)),
            "r": QRect(w - thickness, corner, thickness, max(0, h - corner * 2)),
            "bl": QRect(0, h - corner, corner, corner),
            "b": QRect(corner, h - thickness, max(0, w - corner * 2), thickness),
            "br": QRect(w - corner, h - corner, corner, corner),
        }
        for handle in self._resize_handles:
            handle.setGeometry(mapping.get(handle.direction, QRect()))
            handle.raise_()

    # ---------------------------------------------------------------- window
    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        self._layout_handles()
        if hasattr(self, "content"):
            self.content.toasts.setGeometry(self.content.rect())
            self.content.toasts.raise_()
        self._autosave_timer.start()

    def moveEvent(self, event) -> None:  # noqa: N802
        super().moveEvent(event)

    def changeEvent(self, event) -> None:  # noqa: N802
        if event.type() == QEvent.Type.WindowStateChange:
            if hasattr(self, "_outer"):
                margin = 0 if self.isMaximized() else 12
                self._outer.setContentsMargins(margin, margin, margin, margin)
            if hasattr(self, "root"):
                self.root.setStyleSheet(
                    "#RootFrame {"
                    f"background: {BG};"
                    f"border: {'0px' if self.isMaximized() else '1px'} solid {BORDER};"
                    f"border-radius: {'0px' if self.isMaximized() else '16px'};"
                    "}"
                )
            if hasattr(self, "title_bar"):
                self.title_bar.max_btn.icon_name = (
                    "restore" if self.isMaximized() else "maximize"
                )
                self.title_bar.max_btn.update()
        super().changeEvent(event)

    def toggle_maximize(self) -> None:
        if self.isMaximized():
            self.showNormal()
        else:
            self.showMaximized()

    def _save_geometry(self) -> None:
        if self.isMinimized() or self.isMaximized():
            return
        try:
            self.config.set_window_size(self.width(), self.height())
        except Exception:
            pass

    # ------------------------------------------------------------- direction
    def _apply_direction(self) -> None:
        app = QApplication.instance()
        if app is None:
            return
        if self.config.language == "ar":
            app.setLayoutDirection(Qt.LayoutDirection.RightToLeft)
        else:
            app.setLayoutDirection(Qt.LayoutDirection.LeftToRight)

    # -------------------------------------------------------------- navigate
    def navigate(self, key: str) -> None:
        page = self._page_widgets.get(key)
        if page is None:
            return
        self._current_key = key
        self.content.pages.setCurrentWidget(page)
        self._sync_nav()
        self._fade_in(page)
        try:
            page.on_show()
        except Exception:
            log.exception("on_show failed for %s", key)

    def _fade_in(self, page: QWidget) -> None:
        from .ui.common import ANIMATIONS

        if not ANIMATIONS:
            return
        effect = QGraphicsOpacityEffect(page)
        effect.setOpacity(0.0)
        page.setGraphicsEffect(effect)
        anim = QPropertyAnimation(effect, b"opacity", self)
        anim.setDuration(190)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)

        def cleanup() -> None:
            try:
                # setGraphicsEffect(None) also deletes the effect (ownership),
                # so never call deleteLater() on it here.
                page.setGraphicsEffect(None)
            except RuntimeError:
                pass
            except Exception:
                pass

        anim.finished.connect(cleanup)
        self._fade_anim = anim
        anim.start(QPropertyAnimation.DeletionPolicy.DeleteWhenStopped)

    def _sync_nav(self) -> None:
        for key, button in self.sidebar.nav_buttons.items():
            button.set_active(key == self._current_key)

    # --------------------------------------------------------------- actions
    def toast(self, message: str, kind: str = "success") -> None:
        try:
            self.content.toasts.show_message(message, kind)
        except Exception:
            log.exception("toast failed")

    def launch_game(self) -> None:
        try:
            launch_game(self.config.steam_app_id)
            self.toast(i18n.tr("toast_launch"), "info")
        except Exception:
            self.toast(i18n.tr("steam_missing"), "error")

    # ----------------------------------------------------------- auto detect
    def auto_detect_game(self) -> None:
        """Locate the game folder in the background and select it automatically.

        The usual LocalLow locations are primed by :meth:`Config.load`, so this
        only has to run when no usable folder is selected yet. It keeps the UI
        responsive and refreshes Settings/Installed Mods once a path is found.
        """
        if self._auto_detect_running:
            return
        if self.ctx.assets_root() is not None:
            return
        self._auto_detect_running = True

        def job(progress, cancel):
            return detect_games()

        worker = Worker(job)
        self._workers.add(worker)

        def done(found) -> None:
            self._auto_detect_running = False
            self._workers.discard(worker)
            if not isinstance(found, dict) or not found:
                return
            self.config.set_detected(found)
            mode = self.config.game_mode
            if self.config.known_assets_path(mode) is None:
                mode = "global" if "global" in found else next(iter(found))
                self.config.set("game_mode", mode)
                self.toast(i18n.tr("toast_game_detected"), "success")
            self._refresh_detection_pages()

        def failed(_message: str) -> None:
            self._auto_detect_running = False
            self._workers.discard(worker)

        def cancelled() -> None:
            self._auto_detect_running = False
            self._workers.discard(worker)

        worker.signals.finished.connect(done)
        worker.signals.failed.connect(failed)
        worker.signals.cancelled.connect(cancelled)
        QThreadPool.globalInstance().start(worker)

    def _refresh_detection_pages(self) -> None:
        for key in ("settings", "installed"):
            page = self._page_widgets.get(key)
            if page is None:
                continue
            try:
                page.on_show()
            except Exception:
                log.exception("on_show failed for %s", key)

    def notify_library_changed(self) -> None:
        try:
            self.ctx.reload_installed()
            for page in self._page_widgets.values():
                hook = getattr(page, "notify_library_changed", None)
                if callable(hook):
                    hook()
        except Exception:
            log.exception("notify_library_changed failed")

    def apply_animations(self, enabled: bool) -> None:
        set_animations(enabled)
        try:
            self.content.backdrop.set_animations(enabled)
        except Exception:
            pass

    def apply_language(self, code: str) -> None:
        if code not in LANGUAGES:
            code = "en"
        self.config.language = code
        i18n.set_language(code)
        self._apply_direction()
        QTimer.singleShot(0, self._rebuild_for_language)

    def _rebuild_for_language(self) -> None:
        current = self._current_key
        self._build_ui()
        self._build_resize_handles()
        self.navigate(current)
        self.toast(i18n.tr("toast_saved"), "success")

    # ------------------------------------------------------------- first run
    def _maybe_first_run(self) -> None:
        if not self.config.get("first_run", True):
            return
        dialog = FirstRunDialog(self, self.config)
        accepted = dialog.exec() == FirstRunDialog.DialogCode.Accepted
        if accepted:
            self.config.set("language_chosen", True)
            code = self.config.language
            i18n.set_language(code)
            self._apply_direction()
            self._build_ui()
            self._build_resize_handles()
            self.navigate("browse")
        self.config.set("first_run", False)
        QTimer.singleShot(0, self.auto_detect_game)

    # ----------------------------------------------------------------- close
    def closeEvent(self, event) -> None:  # noqa: N802
        try:
            self._save_geometry()
        except Exception:
            pass
        for worker in list(self._workers):
            try:
                worker.cancel()
            except Exception:
                pass
        # Keep the worker objects alive until their pool threads return; the
        # signals object lives on the worker and would otherwise be deleted
        # while a thread is still emitting.
        try:
            from PySide6.QtCore import QThreadPool

            QThreadPool.globalInstance().waitForDone(3000)
        except Exception:
            pass
        super().closeEvent(event)
