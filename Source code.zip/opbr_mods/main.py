"""Application bootstrap."""

from __future__ import annotations

import logging
import os
import sys
import traceback
from logging.handlers import RotatingFileHandler
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import QApplication, QMessageBox

from . import i18n
from .config import Config, resource_path
from .constants import APP_NAME, APP_VERSION
from .main_window import MainWindow
from .ui import icons
from .ui.common import set_animations
from .ui.theme import apply_theme


def _setup_logging(config: Config) -> None:
    try:
        config.logs_dir.mkdir(parents=True, exist_ok=True)
        handler = RotatingFileHandler(
            config.app_log_path,
            maxBytes=1_500_000,
            backupCount=3,
            encoding="utf-8",
        )
        handler.setFormatter(
            logging.Formatter("%(asctime)s  %(levelname)-7s %(name)s: %(message)s")
        )
        root = logging.getLogger()
        root.setLevel(logging.INFO)
        root.addHandler(handler)
    except Exception:
        pass


def _install_excepthook() -> None:
    def hook(exc_type, exc_value, exc_tb) -> None:
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_tb)
            return
        logging.getLogger("unhandled").error(
            "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
        )
        try:
            QMessageBox.critical(
                None,
                APP_NAME,
                f"An unexpected error occurred:\n\n{exc_value}",
            )
        except Exception:
            pass

    sys.excepthook = hook


def _app_icon() -> None:
    icon = icons.app_icon()
    app = QApplication.instance()
    if app is not None:
        app.setWindowIcon(icon)


def main(argv: list[str] | None = None) -> int:
    if sys.platform == "win32":
        try:
            import ctypes

            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                "MedoIQ.OPBRModsInstaller.1"
            )
        except Exception:
            pass

    os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")
    try:
        QApplication.setHighDpiScaleFactorRoundingPolicy(
            Qt.HighDpiScaleFactorRoundingPolicy.PassThrough
        )
    except Exception:
        pass

    app = QApplication(argv if argv is not None else sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationDisplayName(APP_NAME)
    app.setOrganizationName("MedoIQ")
    app.setApplicationVersion(APP_VERSION)

    config = Config()
    _setup_logging(config)
    _install_excepthook()

    i18n.set_language(config.language)
    set_animations(config.animations)
    apply_theme(app)
    _app_icon()

    window = MainWindow(config)
    window.show()
    if config.animations:
        # Gentle opening animation.
        try:
            from PySide6.QtCore import QEasingCurve, QPropertyAnimation

            window.setWindowOpacity(0.0)
            anim = QPropertyAnimation(window, b"windowOpacity", window)
            anim.setDuration(240)
            anim.setStartValue(0.0)
            anim.setEndValue(1.0)
            anim.setEasingCurve(QEasingCurve.Type.OutCubic)
            anim.start(QPropertyAnimation.DeletionPolicy.DeleteWhenStopped)
        except Exception:
            window.setWindowOpacity(1.0)
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
