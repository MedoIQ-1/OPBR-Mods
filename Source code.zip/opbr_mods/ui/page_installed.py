"""Installed mods page."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QThreadPool, QTimer, Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QScrollArea,
    QSizePolicy,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from .. import i18n
from ..install import (
    VerifyResult,
    load_manifests,
    verify_manifest,
    read_changelog,
)
from ..util import CancelledError
from .cards import InstalledCard
from .common import (
    Badge,
    EmptyState,
    FxButton,
    SearchBar,
    Spinner,
    _alpha,
)
from .dialogs_extra import ChangelogDialog, InstalledDetailsDialog
from .operations import repair_flow, uninstall_flow
from .page_base import Banner, BasePage, run_operation
from .theme import (
    BORDER,
    CYAN,
    GREEN,
    MUTED,
    ORANGE,
    RED,
    TEXT,
    YELLOW,
    body_font,
    heading_font,
)
from .workers import Worker


class InstalledPage(BasePage):
    def __init__(self, ctx, window) -> None:
        super().__init__(ctx, window)
        self._cards: list[InstalledCard] = []
        self._verifying = False
        self._verify_worker: Worker | None = None
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(160)
        self._search_timer.timeout.connect(self._rebuild_cards)

        right = QWidget()
        right_layout = QHBoxLayout(right)
        right_layout.setContentsMargins(0, 4, 0, 0)
        right_layout.setSpacing(9)
        self.summary_badge = Badge("0", "orange")
        self.issue_badge = Badge("", "yellow")
        self.issue_badge.hide()
        self.verify_spinner = Spinner(size=18)
        self.verify_spinner.hide()
        self.log_btn = FxButton(
            i18n.tr("installed_changelog"),
            self,
            variant="ghost",
            height=36,
            icon_name="clock",
        )
        self.log_btn.clicked.connect(self._show_log)
        self.verify_btn = FxButton(
            i18n.tr("btn_verify_all"),
            self,
            variant="secondary",
            height=36,
            icon_name="shield",
        )
        self.verify_btn.clicked.connect(lambda: self.verify_all(force=True))
        right_layout.addWidget(self.summary_badge)
        right_layout.addWidget(self.issue_badge)
        right_layout.addWidget(self.verify_spinner)
        right_layout.addWidget(self.log_btn)
        right_layout.addWidget(self.verify_btn)
        self.root.addWidget(
            self.build_header(
                i18n.tr("installed_title"), i18n.tr("installed_subtitle"), right
            )
        )

        assets = self.ctx.assets_root()
        self.assets_banner = Banner(
            i18n.tr("installed_missing_assets"), "warning"
        )
        self.assets_banner.setVisible(assets is None)
        self.root.addWidget(self.assets_banner)

        toolbar = QWidget()
        toolbar_layout = QHBoxLayout(toolbar)
        toolbar_layout.setContentsMargins(0, 0, 0, 0)
        toolbar_layout.setSpacing(10)
        self.search = SearchBar(i18n.tr("installed_search_ph"))
        self.search.textChanged.connect(lambda _t: self._search_timer.start())
        toolbar_layout.addWidget(self.search, 1)
        self.ok_badge = Badge(i18n.tr("installed_all_ok"), "green")
        self.ok_badge.hide()
        toolbar_layout.addWidget(self.ok_badge)
        self.root.addWidget(toolbar)

        self.stack = QStackedWidget()
        self.stack.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.root.addWidget(self.stack, 1)

        empty_holder = QWidget()
        empty_layout = QVBoxLayout(empty_holder)
        empty_layout.setContentsMargins(0, 0, 0, 0)
        self.empty_state = EmptyState(
            "box",
            i18n.tr("installed_empty_title"),
            i18n.tr("installed_empty_sub"),
            action_text=i18n.tr("nav_browse"),
            action=lambda: self.window.navigate("browse"),
        )
        empty_layout.addWidget(self.empty_state)
        self.stack.addWidget(empty_holder)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.list_holder = QWidget()
        self.list_layout = QVBoxLayout(self.list_holder)
        self.list_layout.setContentsMargins(2, 2, 8, 8)
        self.list_layout.setSpacing(10)
        self.list_layout.addStretch(1)
        self.scroll.setWidget(self.list_holder)
        self.stack.addWidget(self.scroll)

        self._refresh_badges()

    # ------------------------------------------------------------------ data
    def on_show(self) -> None:
        self.ctx.reload_installed()
        self.assets_banner.setVisible(self.ctx.assets_root() is None)
        self._rebuild_cards()
        if not self.ctx.verification and self.ctx.installed:
            QTimer.singleShot(120, lambda: self.verify_all(force=False))

    def notify_library_changed(self) -> None:
        self.ctx.reload_installed()
        self.assets_banner.setVisible(self.ctx.assets_root() is None)
        self._rebuild_cards()

    def _refresh_badges(self) -> None:
        total = len(self.ctx.installed)
        broken = sum(
            1
            for manifest in self.ctx.installed.values()
            if self.ctx.issues_for(manifest)
        )
        self.summary_badge.set_text(i18n.tr("installed_summary", n=total))
        if broken:
            self.issue_badge.set_kind("yellow", i18n.tr("installed_needs_fix", n=broken))
            self.issue_badge.show()
        else:
            self.issue_badge.hide()
        if total and not broken and self.ctx.verification:
            self.ok_badge.show()
        else:
            self.ok_badge.hide()

    def _clear_cards(self) -> None:
        for card in self._cards:
            card.setParent(None)
            card.deleteLater()
        self._cards.clear()
        # Remove leftover layout items (keep the trailing stretch).
        while self.list_layout.count() > 1:
            item = self.list_layout.takeAt(0)
            widget = item.widget() if item else None
            if widget is not None:
                widget.deleteLater()

    def _rebuild_cards(self) -> None:
        self._clear_cards()
        manifests = list(self.ctx.installed.values())
        query = self.search.text().strip().casefold()
        if query:
            manifests = [
                m
                for m in manifests
                if query
                in " ".join([m.title, m.character, m.author, m.zip_name]).casefold()
            ]
        if not manifests:
            self.stack.setCurrentIndex(0)
            self._refresh_badges()
            return
        manifests.sort(key=lambda m: m.installed_at or "", reverse=True)
        for manifest in manifests:
            issues = self.ctx.issues_for(manifest)
            reason = self.ctx.reason_text(issues) if issues else ""
            card = InstalledCard(
                manifest,
                self.ctx.images,
                needs_fix=bool(issues),
                reason=reason,
            )
            card.fix_requested.connect(self._fix)
            card.uninstall_requested.connect(self._uninstall)
            card.purge_requested.connect(self._purge)
            card.details_requested.connect(self._details)
            self.list_layout.insertWidget(self.list_layout.count() - 1, card)
            self._cards.append(card)
        self.stack.setCurrentIndex(1)
        self._refresh_badges()

    # --------------------------------------------------------------- verify
    def verify_all(self, force: bool = False) -> None:
        if self._verifying:
            return
        self.ctx.reload_installed()
        manifests = list(self.ctx.installed.values())
        if not manifests:
            self._rebuild_cards()
            return
        if not force and self.ctx.verification:
            self._rebuild_cards()
            return
        self._verifying = True
        self.verify_btn.setEnabled(False)
        self.verify_spinner.show()
        self.verify_spinner.start()
        self.window.toast(i18n.tr("toast_verifying"), "info")

        def job(progress, cancel):
            results: dict[str, VerifyResult] = {}
            total = max(1, len(manifests))
            for index, manifest in enumerate(manifests, start=1):
                if cancel.cancelled:
                    raise CancelledError()
                sub = lambda frac, stage, i=index, t=total: progress(
                    (i - 1 + (frac or 0)) / t, stage
                )
                results[manifest.id] = verify_manifest(
                    manifest,
                    progress=sub,
                    cancel=cancel,
                )
            return results

        def done(results) -> None:
            self._verifying = False
            self._verify_worker = None
            self.verify_spinner.stop()
            self.verify_spinner.hide()
            self.verify_btn.setEnabled(True)
            self.ctx.verification.update(results)
            broken = sum(1 for r in results.values() if not r.ok)
            self._rebuild_cards()
            if broken:
                self.window.toast(i18n.tr("installed_verify_bad"), "warning")
            else:
                self.window.toast(i18n.tr("installed_verify_ok"), "success")

        def failed(message: str) -> None:
            self._verifying = False
            self._verify_worker = None
            self.verify_spinner.stop()
            self.verify_spinner.hide()
            self.verify_btn.setEnabled(True)
            self.window.toast(message, "error")

        def cancelled() -> None:
            self._verifying = False
            self._verify_worker = None
            self.verify_spinner.stop()
            self.verify_spinner.hide()
            self.verify_btn.setEnabled(True)

        worker = Worker(job)
        self._verify_worker = worker
        self.window._workers.add(worker)
        worker.signals.finished.connect(done)
        worker.signals.failed.connect(failed)
        worker.signals.cancelled.connect(cancelled)
        QThreadPool.globalInstance().start(worker)

    # -------------------------------------------------------------- actions
    def _fix(self, manifest) -> None:
        repair_flow(self.window, manifest)

    def _uninstall(self, manifest) -> None:
        uninstall_flow(self.window, manifest)

    def _purge(self, manifest) -> None:
        uninstall_flow(self.window, manifest, force=True)

    def _details(self, manifest) -> None:
        from PySide6.QtGui import QPixmap

        preview = None
        path = manifest.preview_path
        if path is not None:
            pixmap = QPixmap(str(path))
            if not pixmap.isNull():
                preview = pixmap
        else:
            pixmap = self.ctx.images.pixmap(f"installed_{manifest.id}")
            if pixmap is not None:
                preview = pixmap
        dialog = InstalledDetailsDialog(
            self.window, manifest, preview, self.ctx.issues_for(manifest)
        )
        dialog.exec()

    def _show_log(self) -> None:
        ChangelogDialog(self.window, self.ctx.config).exec()
