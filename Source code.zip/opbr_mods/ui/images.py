"""Asynchronous thumbnail downloading + caching."""

from __future__ import annotations

import logging
import urllib.request
from pathlib import Path

from PySide6.QtCore import QObject, QThreadPool, Signal
from PySide6.QtGui import QColor, QPixmap, QPainter, QLinearGradient, QFont
from PySide6.QtCore import QRectF, Qt

from ..config import Config, human_size
from ..constants import USER_AGENT
from .theme import heading_font, ORANGE, CYAN
from .workers import Worker

log = logging.getLogger(__name__)


class ImageService(QObject):
    ready = Signal(str)

    def __init__(self, config: Config, parent: QObject | None = None) -> None:
        super().__init__(parent)
        self.config = config
        self._cache: dict[str, QPixmap] = {}
        self._pending: set[str] = set()
        self._failed: set[str] = set()
        self._workers: dict[str, Worker] = {}
        self._pool = QThreadPool.globalInstance()

    def cached(self, key: str) -> QPixmap | None:
        pixmap = self._cache.get(key)
        if pixmap is not None and not pixmap.isNull():
            return pixmap
        return None

    def placeholder(self, width: int = 600, height: int = 420) -> QPixmap:
        pixmap = QPixmap(width, height)
        pixmap.fill(QColor("#111116"))
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        gradient = QLinearGradient(0, 0, width, height)
        gradient.setColorAt(0.0, QColor("#1A1A22"))
        gradient.setColorAt(0.55, QColor("#101014"))
        gradient.setColorAt(1.0, QColor("#16161D"))
        painter.fillRect(0, 0, width, height, gradient)
        painter.setOpacity(0.15)
        painter.setPen(QColor(ORANGE))
        for i in range(-height, width, 46):
            painter.drawLine(i, height, i + height, 0)
        painter.setOpacity(1.0)
        font = heading_font(max(28, int(height * 0.16)), QFont.Weight.Black)
        font.setItalic(True)
        painter.setFont(font)
        painter.setPen(QColor(ORANGE))
        painter.drawText(
            QRectF(0, 0, width, height * 0.9),
            Qt.AlignmentFlag.AlignCenter,
            "OPBR",
        )
        painter.setFont(heading_font(max(12, int(height * 0.045)), QFont.Weight.Bold))
        painter.setPen(QColor("#5D5D6B"))
        painter.drawText(
            QRectF(0, height * 0.68, width, height * 0.2),
            Qt.AlignmentFlag.AlignCenter,
            "SKIN MODS",
        )
        painter.end()
        return pixmap

    def request(
        self,
        key: str,
        url: str,
        cache_path: Path | None = None,
        fallback_url: str = "",
        force: bool = False,
    ) -> None:
        if not key:
            return
        if key in self._cache and not force:
            self.ready.emit(key)
            return
        if key in self._pending:
            return
        if cache_path is not None and cache_path.exists() and not force:
            pixmap = QPixmap(str(cache_path))
            if not pixmap.isNull():
                self._cache[key] = pixmap
                self.ready.emit(key)
                return
        if not (url or fallback_url):
            self._failed.add(key)
            self.ready.emit(key)
            return
        self._pending.add(key)

        def job(progress, cancel):
            if cache_path is not None and cache_path.exists() and not force:
                return cache_path.read_bytes()
            last = None
            for candidate in (url, fallback_url):
                if not candidate:
                    continue
                try:
                    request = urllib.request.Request(
                        candidate,
                        headers={
                            "User-Agent": USER_AGENT,
                            "Accept": "image/avif,image/webp,image/png,image/jpeg,*/*",
                            "Referer": "https://discord.com/",
                        },
                    )
                    with urllib.request.urlopen(request, timeout=25) as response:
                        data = response.read()
                    if data and cache_path is not None:
                        try:
                            cache_path.parent.mkdir(parents=True, exist_ok=True)
                            tmp = cache_path.with_suffix(cache_path.suffix + ".part")
                            tmp.write_bytes(data)
                            tmp.replace(cache_path)
                        except OSError:
                            pass
                    return data
                except Exception as exc:
                    last = exc
                    continue
            # A missing/expired preview must not look like an application
            # failure; report an empty payload and let the caller fall back to
            # the painted placeholder.
            log.debug("Preview download failed for %s: %s", key, last)
            return b""

        worker = Worker(job)
        self._workers[key] = worker

        def done(result, key=key):
            self._pending.discard(key)
            self._workers.pop(key, None)
            if isinstance(result, (bytes, bytearray)) and result:
                pixmap = QPixmap()
                if pixmap.loadFromData(bytes(result)):
                    self._cache[key] = pixmap
                else:
                    self._failed.add(key)
            else:
                self._failed.add(key)
            self.ready.emit(key)

        def failed(message, key=key):
            log.debug("Thumbnail failed %s: %s", key, message)
            self._pending.discard(key)
            self._workers.pop(key, None)
            self._failed.add(key)
            self.ready.emit(key)

        worker.signals.finished.connect(done)
        worker.signals.failed.connect(failed)
        worker.signals.cancelled.connect(lambda key=key: failed("cancelled", key))
        self._pool.start(worker)

    def pixmap(self, key: str) -> QPixmap | None:
        return self._cache.get(key)
