"""QThreadPool worker wrapper."""

from __future__ import annotations

import logging
from typing import Callable

from PySide6.QtCore import QObject, QRunnable, Signal, Slot

from ..util import CancelToken, CancelledError

log = logging.getLogger(__name__)


class WorkerSignals(QObject):
    finished = Signal(object)
    failed = Signal(str)
    cancelled = Signal()
    progress = Signal(object, str)


class Worker(QRunnable):
    """Runs fn(progress, cancel) on a pool thread."""

    def __init__(self, fn: Callable) -> None:
        super().__init__()
        self.fn = fn
        self.token = CancelToken()
        self.signals = WorkerSignals()
        self.setAutoDelete(True)

    def cancel(self) -> None:
        self.token.cancel()

    def _emit(self, signal, *args) -> None:
        try:
            signal.emit(*args)
        except RuntimeError:
            # The owning window was destroyed while the thread was running.
            pass

    def _progress(self, *args) -> None:
        self._emit(self.signals.progress, *args)

    @Slot()
    def run(self) -> None:
        try:
            result = self.fn(self._progress, self.token)
        except CancelledError:
            self._emit(self.signals.cancelled)
        except Exception as exc:
            log.exception("Background task failed")
            self._emit(self.signals.failed, str(exc) or exc.__class__.__name__)
        else:
            self._emit(self.signals.finished, result)
