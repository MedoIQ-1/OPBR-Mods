"""Settings page."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QThreadPool, QTimer, Qt, Signal
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QScrollArea,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from .. import i18n
from ..config import Config, human_size
from ..constants import (
    APP_VERSION,
    AUTHOR,
    DISCORD_INVITE,
    DISCORD_NAME,
    LANGUAGE_NAMES,
    LANGUAGES,
)
from ..paths import detect_games, normalize_assets_path
from ..util import open_in_explorer, open_url
from .common import (
    AlertDialog,
    Badge,
    ComboBox,
    ConfirmDialog,
    FxButton,
    IconButton,
    SearchBar,
    ToggleSwitch,
    _alpha,
    section_label,
)
from .dialogs_extra import ChangelogDialog, DonateDialog
from .page_base import Banner, BasePage, run_operation
from .theme import (
    BORDER,
    BORDER_HI,
    CYAN,
    GREEN,
    MUTED,
    ORANGE,
    ORANGE_2,
    RED,
    SURFACE,
    SURFACE_2,
    TEXT,
    TEXT_DIM,
    YELLOW,
    body_font,
    heading_font,
)
from .workers import Worker


class SettingsSection(QWidget):
    """A titled card that stacks rows."""

    def __init__(
        self,
        title: str,
        subtitle: str = "",
        icon_name: str = "gear",
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet(
            f"SettingsSection {{ background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 14px; }}"
        )
        self._icon = icon_name
        outer = QVBoxLayout(self)
        outer.setContentsMargins(18, 16, 18, 16)
        outer.setSpacing(11)

        head = QHBoxLayout()
        head.setSpacing(10)
        self._badge = _SectionBadge(icon_name)
        head.addWidget(self._badge, 0, Qt.AlignmentFlag.AlignTop)
        titles = QVBoxLayout()
        titles.setSpacing(1)
        title_label = QLabel(title)
        title_label.setFont(heading_font(12.4, QFont.Weight.Bold))
        title_label.setStyleSheet(f"color: {TEXT};")
        titles.addWidget(title_label)
        if subtitle:
            sub_label = QLabel(subtitle)
            sub_label.setFont(body_font(8.9))
            sub_label.setStyleSheet(f"color: {MUTED};")
            sub_label.setWordWrap(True)
            titles.addWidget(sub_label)
        head.addLayout(titles, 1)
        outer.addLayout(head)
        self.body = QVBoxLayout()
        self.body.setSpacing(9)
        outer.addLayout(self.body)

    def add_row(self, widget: QWidget) -> None:
        self.body.addWidget(widget)

    def add_layout(self, layout) -> None:
        self.body.addLayout(layout)


class _SectionBadge(QWidget):
    def __init__(self, icon_name: str, size: int = 34) -> None:
        super().__init__()
        self._icon = icon_name
        self.setFixedSize(size, size)

    def paintEvent(self, event) -> None:  # noqa: N802
        from PySide6.QtCore import QRectF
        from PySide6.QtGui import QBrush, QColor, QPainter, QPen

        from . import icons

        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        painter.setPen(QPen(_alpha(ORANGE, 100), 1))
        painter.setBrush(QBrush(_alpha(ORANGE, 24)))
        painter.drawRoundedRect(rect, 9, 9)
        icons.paint_icon(
            painter, self._icon, rect.adjusted(9, 9, -9, -9), ORANGE, 1.7
        )
        painter.end()


class SettingsPage(BasePage):
    language_changed = Signal(str)

    def __init__(self, ctx, window) -> None:
        super().__init__(ctx, window)
        self._detecting = False
        self._pending_mode = ctx.config.game_mode
        self._pending_custom = str(ctx.config.get("custom_assets") or "")

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        holder = QWidget()
        holder.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        layout = QVBoxLayout(holder)
        layout.setContentsMargins(2, 2, 10, 12)
        layout.setSpacing(13)

        layout.addWidget(self._build_language())
        layout.addWidget(self._build_game())
        layout.addWidget(self._build_launch())
        layout.addWidget(self._build_storage())
        layout.addWidget(self._build_appearance())
        layout.addWidget(self._build_about())
        layout.addStretch(1)
        scroll.setWidget(holder)

        self.root.addWidget(
            self.build_header(
                i18n.tr("settings_title"), i18n.tr("settings_subtitle")
            )
        )
        self.root.addWidget(scroll, 1)

    # ------------------------------------------------------------- language
    def _build_language(self) -> QWidget:
        section = SettingsSection(
            i18n.tr("settings_language_title"),
            i18n.tr("settings_language_sub"),
            "globe",
        )
        row = QWidget()
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(0, 0, 0, 0)
        row_layout.setSpacing(12)
        combo = ComboBox()
        for code in LANGUAGES:
            combo.addItem(f"{LANGUAGE_NAMES.get(code, code)}", code)
        index = combo.findData(self.ctx.config.language)
        if index >= 0:
            combo.setCurrentIndex(index)
        combo.setFixedWidth(280)
        combo.currentIndexChanged.connect(
            lambda _i: self._change_language(combo.currentData())
        )
        self.language_combo = combo
        row_layout.addWidget(combo)
        row_layout.addStretch(1)
        current = Badge(self.ctx.config.language.upper(), "cyan")
        row_layout.addWidget(current)
        self.language_badge = current
        section.add_row(row)
        return self._stretch(section)

    def _change_language(self, code: str) -> None:
        if not code:
            return
        self.ctx.config.language = code
        i18n.set_language(code)
        self.language_badge.set_text(code.upper())
        self.language_changed.emit(code)

    # ----------------------------------------------------------------- game
    def _build_game(self) -> QWidget:
        section = SettingsSection(
            i18n.tr("settings_game_title"),
            i18n.tr("settings_game_sub"),
            "folder",
        )
        self.mode_row = QWidget()
        mode_layout = QHBoxLayout(self.mode_row)
        mode_layout.setContentsMargins(0, 0, 0, 0)
        mode_layout.setSpacing(8)
        self.mode_buttons: dict[str, FxButton] = {}
        for mode, key in (
            ("global", "settings_game_global"),
            ("jp", "settings_game_jp"),
            ("custom", "settings_game_custom"),
        ):
            button = FxButton(
                i18n.tr(key), self, variant="chip", height=32, radius=8
            )
            button.setCheckable(True)
            button.setFixedWidth(104)
            button.clicked.connect(lambda _c=False, m=mode: self._select_mode(m))
            mode_layout.addWidget(button)
            self.mode_buttons[mode] = button
        mode_layout.addStretch(1)
        detect = FxButton(
            i18n.tr("settings_game_detect"), self, variant="secondary", height=32, icon_name="compass"
        )
        detect.clicked.connect(self._detect)
        mode_layout.addWidget(detect)
        self.detect_btn = detect
        section.add_row(self.mode_row)

        self.path_label = QLabel("")
        self.path_label.setWordWrap(True)
        self.path_label.setFont(body_font(8.9))
        self.path_label.setStyleSheet(
            f"color: {TEXT_DIM}; background: #0E0E13; border: 1px solid {BORDER};"
            "border-radius: 8px; padding: 9px 11px;"
        )
        self.path_label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )
        section.add_row(self.path_label)

        self.game_status = QLabel("")
        self.game_status.setFont(body_font(8.9, QFont.Weight.DemiBold))
        self.game_status.setWordWrap(True)
        section.add_row(self.game_status)

        buttons = QHBoxLayout()
        buttons.setSpacing(8)
        choose = FxButton(
            i18n.tr("btn_browse"), self, variant="ghost", height=34, icon_name="folder"
        )
        choose.clicked.connect(self._choose_folder)
        buttons.addWidget(choose)
        open_btn = FxButton(
            i18n.tr("btn_open_folder"), self, variant="ghost", height=34, icon_name="external"
        )
        open_btn.clicked.connect(self._open_assets)
        buttons.addWidget(open_btn)
        buttons.addStretch(1)
        section.add_layout(buttons)
        self._mode_selected = self.ctx.config.game_mode
        self._sync_mode_buttons()
        self._sync_path()
        return self._stretch(section)

    def _sync_mode_buttons(self) -> None:
        for mode, button in self.mode_buttons.items():
            button.setChecked(mode == self._mode_selected)
            button.update()

    def _select_mode(self, mode: str) -> None:
        self._mode_selected = mode
        self._sync_mode_buttons()
        if mode == "custom" and not self._pending_custom:
            self._choose_folder()
        else:
            self.ctx.config.set("game_mode", mode)
            self._sync_path()

    def _sync_path(self) -> None:
        mode = self._mode_selected
        config = self.ctx.config
        if mode == "custom":
            raw = self._pending_custom or str(config.get("custom_assets") or "")
            path = Path(raw) if raw else None
        else:
            detected = config.detected().get(mode, "")
            path = Path(detected) if detected and Path(detected).is_dir() else None
        if path is not None and path.is_dir():
            self.path_label.setText(
                i18n.tr("settings_selected", path=str(path))
            )
            self.path_label.setStyleSheet(
                f"color: {TEXT_DIM}; background: #0E0E13; border: 1px solid {BORDER};"
                "border-radius: 8px; padding: 9px 11px;"
            )
            self.game_status.setText(i18n.tr("settings_game_found"))
            self.game_status.setStyleSheet(f"color: {GREEN};")
        else:
            self.path_label.setText(
                i18n.tr("settings_selected", path=str(path) if path else "—")
            )
            self.game_status.setText(i18n.tr("settings_game_not_found"))
            self.game_status.setStyleSheet(f"color: {YELLOW};")

    def _open_assets(self) -> None:
        path = self.ctx.assets_root()
        if path is not None:
            open_in_explorer(path)

    def _choose_folder(self) -> None:
        start = self._pending_custom or str(Path.home())
        folder = QFileDialog.getExistingDirectory(
            self.window, i18n.tr("settings_game_path"), start
        )
        if not folder:
            if self._mode_selected == "custom" and not self._pending_custom:
                self._mode_selected = self.ctx.config.game_mode
                self._sync_mode_buttons()
            return
        normalized = normalize_assets_path(folder)
        if normalized is None:
            AlertDialog(
                self.window,
                i18n.tr("settings_game_title"),
                i18n.tr("settings_game_invalid"),
                kind="warning",
            ).exec()
            return
        self._pending_custom = str(normalized)
        self._mode_selected = "custom"
        self._sync_mode_buttons()
        self.ctx.config.set("game_mode", "custom")
        self.ctx.config.set("custom_assets", str(normalized))
        self._sync_path()
        self.window.toast(i18n.tr("settings_game_saved"))

    def _detect(self) -> None:
        if self._detecting:
            return
        self._detecting = True
        self.detect_btn.setEnabled(False)
        self.game_status.setText(i18n.tr("stage_scan"))
        self.game_status.setStyleSheet(f"color: {ORANGE_2};")

        def job(progress, cancel):
            return detect_games(progress=lambda name: progress(None, "stage_scan"))

        def done(found) -> None:
            self._detecting = False
            self.detect_btn.setEnabled(True)
            if found:
                self.ctx.config.set_detected(found)
                self._sync_path()
                self.window.toast(i18n.tr("settings_game_found"))
                # Persist detected paths for both modes.
                if self._mode_selected == "custom":
                    self._mode_selected = "global" if "global" in found else "jp"
                    self.ctx.config.set("game_mode", self._mode_selected)
                    self._sync_mode_buttons()
                    self._sync_path()
            else:
                self.game_status.setText(i18n.tr("settings_game_not_found"))
                self.game_status.setStyleSheet(f"color: {YELLOW};")

        def failed(message: str) -> None:
            self._detecting = False
            self.detect_btn.setEnabled(True)
            self.game_status.setText(message)
            self.game_status.setStyleSheet(f"color: {RED};")

        run_operation(
            self.window,
            i18n.tr("stage_scan"),
            job,
            on_done=done,
            on_error=failed,
            initial_status=i18n.tr("stage_scan"),
        )

    # --------------------------------------------------------------- launch
    def _build_launch(self) -> QWidget:
        section = SettingsSection(
            i18n.tr("settings_launch_title"),
            i18n.tr("settings_launch_sub"),
            "play",
        )
        row = QWidget()
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(0, 0, 0, 0)
        row_layout.setSpacing(12)
        info = QLabel(
            f"{i18n.tr('settings_steam_id')}: {self.ctx.config.steam_app_id}"
        )
        info.setFont(body_font(9.0))
        info.setStyleSheet(f"color: {MUTED};")
        row_layout.addWidget(info)
        row_layout.addStretch(1)
        launch = FxButton(
            i18n.tr("launch_game"), self, variant="primary", height=38, icon_name="play"
        )
        launch.setMinimumWidth(160)
        launch.clicked.connect(self.window.launch_game)
        row_layout.addWidget(launch)
        section.add_row(row)
        return self._stretch(section)

    # -------------------------------------------------------------- storage
    def _build_storage(self) -> QWidget:
        section = SettingsSection(
            i18n.tr("settings_temp_title"),
            i18n.tr("settings_temp_sub"),
            "box",
        )
        self.temp_size_label = QLabel("")
        self.temp_size_label.setFont(body_font(9.0))
        self.temp_size_label.setStyleSheet(f"color: {TEXT_DIM};")
        section.add_row(self.temp_size_label)

        auto_row = QWidget()
        auto_layout = QHBoxLayout(auto_row)
        auto_layout.setContentsMargins(0, 0, 0, 0)
        auto_layout.setSpacing(10)
        auto_label = QLabel(i18n.tr("settings_temp_auto"))
        auto_label.setFont(body_font(9.2))
        auto_label.setStyleSheet(f"color: {TEXT_DIM};")
        auto_layout.addWidget(auto_label, 1)
        self.auto_toggle = ToggleSwitch(checked=self.ctx.config.auto_clear_temp)
        self.auto_toggle.toggled.connect(self._toggle_auto_clear)
        auto_layout.addWidget(self.auto_toggle)
        section.add_row(auto_row)

        buttons = QHBoxLayout()
        buttons.setSpacing(8)
        clear_temp = FxButton(
            i18n.tr("settings_temp_clear"), self, variant="secondary", height=34, icon_name="trash"
        )
        clear_temp.clicked.connect(self._clear_temp)
        buttons.addWidget(clear_temp)
        clear_cache = FxButton(
            i18n.tr("btn_clear_cache"), self, variant="ghost", height=34, icon_name="image"
        )
        clear_cache.clicked.connect(self._clear_cache)
        buttons.addWidget(clear_cache)
        buttons.addStretch(1)
        section.add_layout(buttons)
        self._refresh_temp_size()
        return self._stretch(section)

    def _refresh_temp_size(self) -> None:
        try:
            size = self.ctx.config.temp_size()
        except Exception:
            size = 0
        self.temp_size_label.setText(
            i18n.tr("settings_temp_size", size=human_size(size)) or ""
        )

    def _toggle_auto_clear(self, checked: bool) -> None:
        self.ctx.config.set("auto_clear_temp", bool(checked))

    def _clear_temp(self) -> None:
        try:
            self.ctx.config.clear_temp()
        except Exception:
            pass
        self._refresh_temp_size()
        self.window.toast(i18n.tr("settings_temp_cleared"), "success")

    def _clear_cache(self) -> None:
        try:
            self.ctx.config.clear_thumb_cache()
        except Exception:
            pass
        self.ctx.images._cache.clear()
        self.window.notify_library_changed()
        self.window.toast(i18n.tr("settings_cache_cleared"), "success")

    # ----------------------------------------------------------- appearance
    def _build_appearance(self) -> QWidget:
        section = SettingsSection(
            i18n.tr("settings_appearance_title"),
            i18n.tr("settings_appearance_sub"),
            "sparkle",
        )
        row = QWidget()
        row_layout = QHBoxLayout(row)
        row_layout.setContentsMargins(0, 0, 0, 0)
        row_layout.setSpacing(10)
        label = QLabel(i18n.tr("settings_animations"))
        label.setFont(body_font(9.2))
        label.setStyleSheet(f"color: {TEXT_DIM};")
        row_layout.addWidget(label, 1)
        self.anim_toggle = ToggleSwitch(checked=self.ctx.config.animations)
        self.anim_toggle.toggled.connect(self._toggle_animations)
        row_layout.addWidget(self.anim_toggle)
        section.add_row(row)

        data_row = QWidget()
        data_layout = QHBoxLayout(data_row)
        data_layout.setContentsMargins(0, 0, 0, 0)
        data_layout.setSpacing(8)
        data_label = QLabel(i18n.tr("settings_data_folder"))
        data_label.setFont(body_font(9.2))
        data_label.setStyleSheet(f"color: {TEXT_DIM};")
        data_layout.addWidget(data_label, 1)
        open_data = FxButton(
            i18n.tr("settings_open_data"), self, variant="ghost", height=32, icon_name="folder"
        )
        open_data.clicked.connect(
            lambda: open_in_explorer(self.ctx.config.root)
        )
        data_layout.addWidget(open_data)
        section.add_row(data_row)
        return self._stretch(section)

    def _toggle_animations(self, checked: bool) -> None:
        self.ctx.config.set("animations", bool(checked))
        self.window.apply_animations(bool(checked))

    # ---------------------------------------------------------------- about
    def _build_about(self) -> QWidget:
        section = SettingsSection(
            i18n.tr("settings_about_title"),
            i18n.tr("settings_about_sub"),
            "shield",
        )
        section.add_row(Banner(i18n.tr("settings_warning"), "warning"))

        text = QLabel(i18n.tr("settings_about_text"))
        text.setWordWrap(True)
        text.setFont(body_font(9.1))
        text.setStyleSheet(f"color: {MUTED};")
        section.add_row(text)

        credit = QWidget()
        credit_layout = QHBoxLayout(credit)
        credit_layout.setContentsMargins(0, 0, 0, 0)
        credit_layout.setSpacing(8)
        made = QLabel(
            f"{i18n.tr('settings_made_by')}  {AUTHOR}   ·   "
            f"{i18n.tr('settings_discord')}  {DISCORD_NAME}"
        )
        made.setFont(body_font(9.2, QFont.Weight.DemiBold))
        made.setStyleSheet(f"color: {ORANGE_2};")
        credit_layout.addWidget(made)
        copy_btn = IconButton(
            "copy", self, size=28, icon_size=13, tooltip=i18n.tr("common_copy")
        )
        copy_btn.clicked.connect(
            lambda: self._copy(f"{DISCORD_NAME}")
        )
        credit_layout.addWidget(copy_btn)
        credit_layout.addStretch(1)
        version = QLabel(i18n.tr("about_version", v=APP_VERSION))
        version.setFont(body_font(8.8))
        version.setStyleSheet(f"color: {MUTED};")
        credit_layout.addWidget(version)
        section.add_row(credit)

        buttons = QHBoxLayout()
        buttons.setSpacing(8)
        donate_btn = FxButton(
            i18n.tr("sidebar_donate"), self, variant="binance", height=34, icon_name="heart"
        )
        donate_btn.clicked.connect(
            lambda: DonateDialog(self.window).exec()
        )
        buttons.addWidget(donate_btn)
        if DISCORD_INVITE:
            invite = FxButton(
                i18n.tr("sidebar_discord"),
                self,
                variant="discord",
                height=34,
                icon_name="discord",
            )
            invite.clicked.connect(lambda: open_url(DISCORD_INVITE))
            buttons.addWidget(invite)
        log_btn = FxButton(
            i18n.tr("settings_view_log"), self, variant="ghost", height=34, icon_name="clock"
        )
        log_btn.clicked.connect(
            lambda: ChangelogDialog(self.window, self.ctx.config).exec()
        )
        buttons.addWidget(log_btn)
        reset_btn = FxButton(
            i18n.tr("settings_reset"), self, variant="danger", height=34, icon_name="alert"
        )
        reset_btn.clicked.connect(self._reset_settings)
        buttons.addWidget(reset_btn)
        buttons.addStretch(1)
        section.add_layout(buttons)

        fan = QLabel(i18n.tr("settings_fan"))
        fan.setFont(body_font(8.4))
        fan.setStyleSheet(f"color: {MUTED};")
        section.add_row(fan)
        return self._stretch(section)

    def _copy(self, text: str) -> None:
        from PySide6.QtWidgets import QApplication

        QApplication.clipboard().setText(text)
        self.window.toast(i18n.tr("common_copied"), "info")

    def _reset_settings(self) -> None:
        if not ConfirmDialog.ask(
            self.window,
            i18n.tr("settings_reset"),
            i18n.tr("settings_reset_confirm"),
            i18n.tr("settings_reset"),
            i18n.tr("btn_cancel"),
            kind="warning",
            danger=True,
        ):
            return
        config = self.ctx.config
        language = config.language
        config.data["game_mode"] = "global"
        config.data["custom_assets"] = ""
        config.data["auto_clear_temp"] = True
        config.data["animations"] = True
        config.data["auto_refresh_minutes"] = 15
        config.save()
        self.auto_toggle.setChecked(True)
        self.anim_toggle.setChecked(True)
        self.window.apply_animations(True)
        self._mode_selected = "global"
        self._sync_mode_buttons()
        self._sync_path()
        self.window.toast(i18n.tr("toast_saved"))

    def _stretch(self, widget: QWidget) -> QWidget:
        widget.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Maximum)
        return widget

    # ------------------------------------------------------------------ sync
    def on_show(self) -> None:
        self._pending_custom = str(self.ctx.config.get("custom_assets") or "")
        self._mode_selected = self.ctx.config.game_mode
        self._sync_mode_buttons()
        self._sync_path()
        self._refresh_temp_size()
        index = self.language_combo.findData(self.ctx.config.language)
        if index >= 0:
            self.language_combo.blockSignals(True)
            self.language_combo.setCurrentIndex(index)
            self.language_combo.blockSignals(False)
        self.language_badge.set_text(self.ctx.config.language.upper())
        self.anim_toggle.blockSignals(True)
        self.anim_toggle.setChecked(self.ctx.config.animations)
        self.anim_toggle.blockSignals(False)
        self.auto_toggle.blockSignals(True)
        self.auto_toggle.setChecked(self.ctx.config.auto_clear_temp)
        self.auto_toggle.blockSignals(False)
