"""Secondary dialogs: mod details, change log and the first-run wizard."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QRectF, QSize, Qt, QTimer
from PySide6.QtGui import QBrush, QColor, QFont, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap
from PySide6.QtWidgets import (
    QComboBox,
    QFileDialog,
    QFrame,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QScrollArea,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from .. import i18n
from ..config import Config, human_size, resource_path
from ..constants import (
    APP_VERSION,
    BINANCE_ID,
    BINANCE_PAY_NAME,
    DISCORD_INVITE,
    DISCORD_NAME,
    LANGUAGE_NAMES,
    LANGUAGES,
)
from ..feed import FeedMod
from ..install import Manifest, read_changelog
from ..paths import detect_games, normalize_assets_path
from ..util import format_date, open_in_explorer, open_url, time_ago
from . import icons
from .common import (
    AlertDialog,
    Badge,
    ConfirmDialog,
    FxButton,
    FxDialog,
    IconButton,
    LogoMark,
    _alpha,
    _IconBadge,
    section_label,
)
from .page_base import Banner, details_row
from .theme import (
    BORDER,
    CYAN,
    GREEN,
    MUTED,
    ORANGE,
    ORANGE_2,
    RED,
    SURFACE,
    SURFACE_2,
    TEXT,
    TEXT_DIM,
    YELLOW,
    body_font,
    heading_font,
)


class CoverImage(QWidget):
    def __init__(self, pixmap: QPixmap | None, width: int = 300, height: int = 300) -> None:
        super().__init__()
        self._pixmap = pixmap
        self.setFixedSize(width, height)

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        rect = QRectF(self.rect())
        clip = QPainterPath()
        clip.addRoundedRect(rect, 12, 12)
        painter.setClipPath(clip)
        if self._pixmap is None or self._pixmap.isNull():
            grad = QLinearGradient(0, 0, rect.width(), rect.height())
            grad.setColorAt(0, QColor("#1B1B23"))
            grad.setColorAt(1, QColor("#0F0F14"))
            painter.fillRect(rect, QBrush(grad))
            painter.setPen(QColor("#3A3A45"))
            painter.setFont(heading_font(44, QFont.Weight.Black))
            painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, "OPBR")
        else:
            scaled = self._pixmap.scaled(
                self.size() * self.devicePixelRatioF(),
                Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                Qt.TransformationMode.SmoothTransformation,
            )
            scaled.setDevicePixelRatio(self.devicePixelRatioF())
            x = (self.width() - scaled.width() / scaled.devicePixelRatioF()) / 2
            y = (self.height() - scaled.height() / scaled.devicePixelRatioF()) / 2
            painter.drawPixmap(int(x), int(y), scaled)
        painter.setClipping(False)
        painter.setPen(QPen(_alpha(ORANGE, 70), 1))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRoundedRect(rect.adjusted(0.5, 0.5, -0.5, -0.5), 12, 12)
        painter.end()


class ModDetailsDialog(FxDialog):
    def __init__(
        self,
        parent,
        mod: FeedMod,
        preview: QPixmap | None,
        state: str,
        manifest: Manifest | None,
        on_install=None,
        on_fix=None,
        on_uninstall=None,
    ) -> None:
        super().__init__(parent, i18n.tr("browse_details_title"), width=800, icon_name="sparkle", icon_kind="orange")
        body = QHBoxLayout()
        body.setSpacing(20)
        body.addWidget(CoverImage(preview, 300, 300), 0, Qt.AlignmentFlag.AlignTop)

        info = QVBoxLayout()
        info.setSpacing(8)
        title = QLabel(mod.display_title)
        title.setFont(heading_font(17, QFont.Weight.Black))
        title.setWordWrap(True)
        title.setStyleSheet(f"color: {TEXT};")
        info.addWidget(title)

        chips = QHBoxLayout()
        chips.setSpacing(6)
        chips.addWidget(Badge(mod.character_text, "orange"))
        if state == "needs_fix":
            chips.addWidget(Badge(i18n.tr("status_needs_fix"), "yellow"))
        elif state == "installed":
            chips.addWidget(Badge(i18n.tr("status_installed"), "green"))
        elif state == "update":
            chips.addWidget(Badge(i18n.tr("status_update"), "cyan"))
        chips.addStretch(1)
        info.addLayout(chips)

        details = QVBoxLayout()
        details.setSpacing(6)
        details.addWidget(details_row(i18n.tr("common_author"), mod.author_text))
        details.addWidget(details_row(i18n.tr("details_posted"), format_date(mod.created_at)))
        details.addWidget(details_row(i18n.tr("details_download_size"), mod.size_text))
        details.addWidget(details_row(i18n.tr("details_zip"), mod.zip_name or "—"))
        info.addLayout(details)

        if mod.description:
            info.addSpacing(4)
            info.addWidget(section_label(i18n.tr("details_description")))
            desc = QLabel(mod.description)
            desc.setWordWrap(True)
            desc.setFont(body_font(9.4))
            desc.setStyleSheet(f"color: {TEXT_DIM};")
            info.addWidget(desc)
        if mod.notes:
            info.addSpacing(2)
            info.addWidget(section_label(i18n.tr("details_notes")))
            notes = QLabel(mod.notes)
            notes.setWordWrap(True)
            notes.setFont(body_font(9.4))
            notes.setStyleSheet(f"color: {MUTED};")
            info.addWidget(notes)

        links = QHBoxLayout()
        links.setSpacing(8)
        if mod.gameplay_url:
            game = FxButton(
                i18n.tr("details_gameplay"), self, variant="ghost", height=32, icon_name="external"
            )
            game.clicked.connect(lambda: open_url(mod.gameplay_url))
            links.addWidget(game)
        if mod.message_url:
            msg = FxButton(
                i18n.tr("details_message"), self, variant="ghost", height=32, icon_name="external"
            )
            msg.clicked.connect(lambda: open_url(mod.message_url))
            links.addWidget(msg)
        links.addStretch(1)
        info.addStretch(1)
        info.addLayout(links)
        body.addLayout(info, 1)
        self.add_body_layout(body)

        close_btn = self.add_button(i18n.tr("btn_close"), "secondary", self.reject)
        close_btn.setMinimumWidth(96)
        if state != "not_installed" and on_uninstall:
            uninstall = self.add_button(
                i18n.tr("btn_uninstall"), "danger", lambda: (self.accept(), on_uninstall(mod)), icon_name="trash"
            )
            uninstall.setMinimumWidth(110)
        if state != "not_installed" and on_fix:
            fix = self.add_button(
                i18n.tr("btn_fix"), "ghost", lambda: (self.accept(), on_fix(mod)), icon_name="wrench"
            )
            fix.setMinimumWidth(86)
        if on_install:
            install = self.add_button(
                i18n.tr("btn_update") if state == "update" else (i18n.tr("btn_reinstall") if state != "not_installed" else i18n.tr("btn_install")),
                "primary",
                lambda: (self.accept(), on_install(mod)),
                icon_name="download",
            )
            install.setMinimumWidth(110)


class InstalledDetailsDialog(FxDialog):
    def __init__(self, parent, manifest: Manifest, preview: QPixmap | None, issues: list) -> None:
        super().__init__(parent, manifest.title, width=780, icon_name="box", icon_kind="green")
        body = QHBoxLayout()
        body.setSpacing(20)
        body.addWidget(CoverImage(preview, 240, 240), 0, Qt.AlignmentFlag.AlignTop)

        info = QVBoxLayout()
        info.setSpacing(7)
        char = QLabel(manifest.character or "—")
        char.setFont(body_font(10.2, QFont.Weight.DemiBold))
        char.setStyleSheet(f"color: {ORANGE_2};")
        info.addWidget(char)
        info.addWidget(details_row(i18n.tr("common_author"), manifest.author or "—"))
        info.addWidget(details_row(i18n.tr("common_installed_on"), format_date(manifest.installed_dt)))
        info.addWidget(details_row(i18n.tr("common_files"), f"{len(manifest.files)}  ·  {manifest.size_text}"))
        info.addWidget(details_row(i18n.tr("details_installed_path"), manifest.assets_root or "—"))
        if manifest.source_zip:
            info.addWidget(details_row(i18n.tr("details_source"), manifest.source_zip))
        if issues:
            info.addSpacing(4)
            warn = QLabel(" · ".join(f"{i18n.tr('reason_' + i.reason)}: {Path(i.rel).name}" for i in issues[:8]))
            warn.setWordWrap(True)
            warn.setFont(body_font(9.0, QFont.Weight.DemiBold))
            warn.setStyleSheet(f"color: {YELLOW};")
            info.addWidget(warn)
        info.addStretch(1)
        info.addWidget(section_label(i18n.tr("details_files")))
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedHeight(150)
        holder = QWidget()
        fl = QVBoxLayout(holder)
        fl.setContentsMargins(0, 0, 6, 0)
        fl.setSpacing(3)
        for record in manifest.files[:60]:
            label = QLabel(record.rel or Path(record.target).name)
            label.setFont(body_font(8.6))
            label.setStyleSheet(f"color: {MUTED};")
            label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            fl.addWidget(label)
        if len(manifest.files) > 60:
            more = QLabel(i18n.tr("common_more", n=len(manifest.files) - 60))
            more.setFont(body_font(8.6, QFont.Weight.Bold))
            more.setStyleSheet(f"color: {ORANGE};")
            fl.addWidget(more)
        fl.addStretch(1)
        scroll.setWidget(holder)
        info.addWidget(scroll)
        body.addLayout(info, 1)
        self.add_body_layout(body)
        close = self.add_button(i18n.tr("btn_close"), "primary", self.accept)
        close.setMinimumWidth(100)


class ChangelogDialog(FxDialog):
    def __init__(self, parent, config: Config) -> None:
        super().__init__(parent, i18n.tr("settings_log_title"), width=720, icon_name="clock", icon_kind="cyan")
        entries = read_changelog(config.changelog_path, limit=200)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedHeight(420)
        holder = QWidget()
        layout = QVBoxLayout(holder)
        layout.setContentsMargins(2, 2, 8, 2)
        layout.setSpacing(7)
        if not entries:
            empty = QLabel(i18n.tr("settings_log_empty"))
            empty.setFont(body_font(9.6))
            empty.setStyleSheet(f"color: {MUTED};")
            layout.addWidget(empty)
        for entry in entries:
            layout.addWidget(_changelog_row(entry))
        layout.addStretch(1)
        scroll.setWidget(holder)
        self.add_body(scroll)

        open_btn = self.add_button(
            i18n.tr("btn_open_logs"), "ghost", lambda: open_in_explorer(config.logs_dir), icon_name="folder"
        )
        open_btn.setMinimumWidth(120)
        close = self.add_button(i18n.tr("btn_close"), "primary", self.accept)
        close.setMinimumWidth(100)


def _changelog_row(entry: dict) -> QWidget:
    event = str(entry.get("event") or "?")
    colors = {
        "install": GREEN,
        "uninstall": YELLOW,
        "purge": RED,
        "restore": CYAN,
    }
    color = colors.get(event, MUTED)
    row = QFrame()
    row.setStyleSheet(
        f"QFrame {{ background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 9px; }}"
    )
    layout = QHBoxLayout(row)
    layout.setContentsMargins(12, 9, 12, 9)
    layout.setSpacing(12)
    badge = QLabel(event.upper())
    badge.setFixedWidth(76)
    badge.setFont(body_font(7.8, QFont.Weight.Bold))
    badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
    badge.setStyleSheet(
        f"color: {color}; background: {_alpha(color, 30).name(QColor.NameFormat.HexArgb)};"
        f"border: 1px solid {_alpha(color, 90).name(QColor.NameFormat.HexArgb)}; border-radius: 5px;"
        "padding: 2px 6px;"
    )
    layout.addWidget(badge)
    title = QLabel(str(entry.get("title") or entry.get("id") or "—"))
    title.setFont(body_font(9.4, QFont.Weight.DemiBold))
    title.setStyleSheet(f"color: {TEXT};")
    layout.addWidget(title, 1)
    meta = QLabel(
        f"{entry.get('files', 0)} files · {human_size(int(entry.get('size') or 0))}"
    )
    meta.setFont(body_font(8.5))
    meta.setStyleSheet(f"color: {MUTED};")
    layout.addWidget(meta)
    when = QLabel(format_date(_parse(entry.get("ts"))))
    when.setFont(body_font(8.5))
    when.setStyleSheet(f"color: {MUTED};")
    layout.addWidget(when)
    return row


def _parse(value):
    from ..util import parse_iso

    return parse_iso(value)


class DonateDialog(FxDialog):
    """Binance Pay details with the bundled QR poster."""

    def __init__(self, parent) -> None:
        super().__init__(
            parent,
            i18n.tr("donate_title"),
            width=424,
            icon_name="heart",
            icon_kind="orange",
        )
        sub = QLabel(i18n.tr("donate_sub"))
        sub.setWordWrap(True)
        sub.setFont(body_font(9.2))
        sub.setStyleSheet(f"color: {MUTED};")
        self.add_body(sub)

        qr = QLabel()
        qr.setAlignment(Qt.AlignmentFlag.AlignCenter)
        qr.setFixedSize(256, 256)
        qr.setStyleSheet("background: #FFFFFF; border-radius: 14px; padding: 10px;")
        pixmap = QPixmap(str(resource_path("assets", "binance_qr.png")))
        if not pixmap.isNull():
            qr.setPixmap(
                pixmap.scaled(
                    232,
                    232,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            )
        else:
            qr.setText("Binance")
        qr_row = QHBoxLayout()
        qr_row.addStretch(1)
        qr_row.addWidget(qr)
        qr_row.addStretch(1)
        self.add_body_layout(qr_row)

        scan = QLabel(i18n.tr("donate_scan"))
        scan.setAlignment(Qt.AlignmentFlag.AlignCenter)
        scan.setFont(body_font(9.2, QFont.Weight.DemiBold))
        scan.setStyleSheet(f"color: {TEXT_DIM};")
        self.add_body(scan)

        card = QFrame()
        card.setStyleSheet(
            f"QFrame {{ background: #0E0E13; border: 1px solid {BORDER}; border-radius: 11px; }}"
        )
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(14, 11, 14, 11)
        card_layout.setSpacing(8)

        id_row = QHBoxLayout()
        id_row.setSpacing(10)
        id_labels = QVBoxLayout()
        id_labels.setSpacing(1)
        id_title = QLabel(i18n.tr("donate_binance_id"))
        id_title.setFont(body_font(8.2, QFont.Weight.Bold))
        id_title.setStyleSheet(f"color: {MUTED};")
        id_labels.addWidget(id_title)
        id_value = QLabel(BINANCE_ID)
        id_value.setFont(heading_font(15.0, QFont.Weight.Bold))
        id_value.setStyleSheet(f"color: {ORANGE_2};")
        id_value.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )
        id_labels.addWidget(id_value)
        id_row.addLayout(id_labels, 1)
        copy_btn = IconButton(
            "copy", self, size=30, icon_size=14, tooltip=i18n.tr("donate_copy_id")
        )
        copy_btn.clicked.connect(self._copy_id)
        id_row.addWidget(copy_btn)
        card_layout.addLayout(id_row)

        name_row = QHBoxLayout()
        name_row.setSpacing(10)
        name_title = QLabel(i18n.tr("donate_pay_name"))
        name_title.setFont(body_font(8.6))
        name_title.setStyleSheet(f"color: {MUTED};")
        name_row.addWidget(name_title)
        name_row.addStretch(1)
        name_value = QLabel(BINANCE_PAY_NAME)
        name_value.setFont(body_font(9.6, QFont.Weight.DemiBold))
        name_value.setStyleSheet(f"color: {TEXT};")
        name_row.addWidget(name_value)
        card_layout.addLayout(name_row)
        self.add_body(card)

        note = QLabel(i18n.tr("donate_note"))
        note.setWordWrap(True)
        note.setFont(body_font(8.6))
        note.setStyleSheet(
            f"color: {YELLOW}; background: rgba(255, 210, 63, 0.06);"
            "border: 1px solid rgba(255, 210, 63, 0.20); border-radius: 8px;"
            "padding: 8px 10px;"
        )
        self.add_body(note)

        thanks = QLabel(i18n.tr("donate_thanks"))
        thanks.setWordWrap(True)
        thanks.setFont(body_font(9.2, QFont.Weight.DemiBold))
        thanks.setStyleSheet(f"color: {GREEN};")
        self.add_body(thanks)

        self.add_button(
            i18n.tr("donate_open_app"),
            "binance",
            lambda: open_url("https://www.binance.com/en/pay"),
            icon_name="binance",
        )
        self.add_button(i18n.tr("btn_close"), "secondary", self.accept)

    def _copy_id(self) -> None:
        from PySide6.QtWidgets import QApplication

        QApplication.clipboard().setText(BINANCE_ID)
        parent = self.parentWidget()
        toast = getattr(parent, "toast", None)
        if callable(toast):
            toast(i18n.tr("common_copied"), "info")


class FirstRunDialog(FxDialog):
    def __init__(self, parent, config: Config) -> None:
        super().__init__(parent, i18n.tr("first_title"), width=760, icon_name="sparkle", icon_kind="orange")
        self.config = config
        self.detected_language = config.data.get("detected_language") or self._detect_language()
        self.detected_games: dict[str, str] = {}
        self.selected_folder = ""
        self.step = 0

        self.stack = QStackedWidget()
        self.stack.setFixedHeight(400)
        self.add_body(self.stack)
        self._build_welcome()
        self._build_language()
        self._build_game()

        self.back_btn = self.add_button(i18n.tr("btn_back"), "ghost", self._back)
        self.skip_btn = self.add_button(i18n.tr("btn_skip"), "ghost", self._skip)
        self.next_btn = self.add_button(i18n.tr("btn_next"), "primary", self._next)
        self.next_btn.setMinimumWidth(120)
        self._update_buttons()
        QTimer.singleShot(150, self._auto_detect)

    def _detect_language(self) -> str:
        from ..config import detect_system_language

        return detect_system_language()

    def _make_page(self) -> tuple[QWidget, QVBoxLayout]:
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(14, 8, 14, 8)
        layout.setSpacing(12)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        return page, layout

    def _build_welcome(self) -> None:
        page, layout = self._make_page()
        logo_row = QHBoxLayout()
        logo_row.addWidget(LogoMark(72))
        text = QVBoxLayout()
        title = QLabel(i18n.tr("first_welcome"))
        title.setFont(heading_font(21, QFont.Weight.Black))
        title.setWordWrap(True)
        title.setStyleSheet(f"color: {TEXT};")
        text.addWidget(title)
        sub = QLabel(i18n.tr("first_welcome_sub"))
        sub.setFont(body_font(10.2))
        sub.setWordWrap(True)
        sub.setStyleSheet(f"color: {MUTED};")
        text.addWidget(sub)
        logo_row.addLayout(text, 1)
        layout.addLayout(logo_row)
        layout.addSpacing(10)
        layout.addWidget(Banner(i18n.tr("about_warning_body"), "warning"))
        layout.addStretch(1)
        self.stack.addWidget(page)

    def _build_language(self) -> None:
        page, layout = self._make_page()
        title = QLabel(i18n.tr("first_lang_title"))
        title.setFont(heading_font(19, QFont.Weight.Black))
        title.setStyleSheet(f"color: {TEXT};")
        layout.addWidget(title)
        sub = QLabel(i18n.tr("first_lang_sub"))
        sub.setFont(body_font(9.7))
        sub.setWordWrap(True)
        sub.setStyleSheet(f"color: {MUTED};")
        layout.addWidget(sub)
        layout.addSpacing(8)
        detected = QLabel(
            i18n.tr(
                "first_lang_detected",
                lang=LANGUAGE_NAMES.get(self.detected_language, self.detected_language),
            )
        )
        detected.setFont(body_font(9.6, QFont.Weight.DemiBold))
        detected.setStyleSheet(f"color: {ORANGE_2};")
        layout.addWidget(detected)
        self.language_combo = QComboBox()
        for code in LANGUAGES:
            self.language_combo.addItem(LANGUAGE_NAMES.get(code, code), code)
        index = self.language_combo.findData(self.detected_language)
        if index >= 0:
            self.language_combo.setCurrentIndex(index)
        self.language_combo.setMinimumHeight(40)
        layout.addWidget(self.language_combo)
        note = QLabel(i18n.tr("settings_language_sub"))
        note.setFont(body_font(8.8))
        note.setStyleSheet(f"color: {MUTED};")
        layout.addWidget(note)
        layout.addStretch(1)
        self.stack.addWidget(page)

    def _build_game(self) -> None:
        page, layout = self._make_page()
        title = QLabel(i18n.tr("first_game_title"))
        title.setFont(heading_font(19, QFont.Weight.Black))
        title.setStyleSheet(f"color: {TEXT};")
        layout.addWidget(title)
        sub = QLabel(i18n.tr("first_game_sub"))
        sub.setFont(body_font(9.7))
        sub.setWordWrap(True)
        sub.setStyleSheet(f"color: {MUTED};")
        layout.addWidget(sub)
        layout.addSpacing(8)

        self.game_status = QLabel(i18n.tr("common_loading"))
        self.game_status.setFont(body_font(9.6, QFont.Weight.DemiBold))
        self.game_status.setWordWrap(True)
        self.game_status.setStyleSheet(f"color: {ORANGE_2};")
        layout.addWidget(self.game_status)

        self.game_detail = QLabel("")
        self.game_detail.setFont(body_font(8.8))
        self.game_detail.setWordWrap(True)
        self.game_detail.setStyleSheet(f"color: {MUTED};")
        layout.addWidget(self.game_detail)

        buttons = QHBoxLayout()
        buttons.setSpacing(9)
        choose = FxButton(
            i18n.tr("first_game_choose"), self, variant="secondary", icon_name="folder"
        )
        choose.clicked.connect(self._choose_folder)
        buttons.addWidget(choose)
        detect = FxButton(i18n.tr("btn_recheck"), self, variant="ghost", icon_name="refresh")
        detect.clicked.connect(self._auto_detect)
        buttons.addWidget(detect)
        buttons.addStretch(1)
        layout.addLayout(buttons)
        layout.addWidget(Banner(i18n.tr("settings_fan"), "info"))
        layout.addStretch(1)
        self.stack.addWidget(page)

    def _auto_detect(self) -> None:
        self.game_status.setText(i18n.tr("stage_scan"))
        self.game_detail.setText("")
        QTimer.singleShot(60, self._run_detection)

    def _run_detection(self) -> None:
        try:
            found = detect_games()
        except Exception:
            found = {}
        self.detected_games = found
        if found:
            self.config.set_detected(found)
            # Make the found version active right away so the user does not
            # have to finish the wizard and press Detect in Settings.
            mode = self.config.game_mode
            if mode not in found:
                mode = "global" if "global" in found else next(iter(found))
                self.config.set("game_mode", mode, save=False)
            paths = "\n".join(f"{k.upper()}: {v}" for k, v in found.items())
            self.game_status.setText(i18n.tr("settings_game_found"))
            self.game_detail.setText(paths)
            self.game_status.setStyleSheet(f"color: {GREEN};")
        else:
            self.game_status.setText(i18n.tr("first_game_missing"))
            self.game_status.setStyleSheet(f"color: {YELLOW};")
        self._update_buttons()

    def _choose_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, i18n.tr("settings_game_path"))
        if not folder:
            return
        normalized = normalize_assets_path(folder)
        if normalized is None:
            AlertDialog(
                self,
                i18n.tr("settings_game_title"),
                i18n.tr("settings_game_invalid"),
                kind="warning",
            ).exec()
            return
        self.selected_folder = str(normalized)
        self.game_status.setText(i18n.tr("settings_game_found"))
        self.game_detail.setText(str(normalized))
        self.game_status.setStyleSheet(f"color: {GREEN};")

    def _update_buttons(self) -> None:
        is_last = self.step == self.stack.count() - 1
        self.back_btn.setVisible(self.step > 0)
        self.skip_btn.setVisible(not is_last)
        self.next_btn.setText(i18n.tr("first_start") if is_last else i18n.tr("btn_next"))
        self.next_btn.icon_name = "check" if is_last else None
        self.next_btn.update()

    def _back(self) -> None:
        if self.step > 0:
            self.step -= 1
            self.stack.setCurrentIndex(self.step)
            self._update_buttons()

    def _next(self) -> None:
        if self.step < self.stack.count() - 1:
            if self.step == 1:
                code = self.language_combo.currentData()
                self.config.set("language", code, save=False)
                i18n.set_language(code)
            self.step += 1
            self.stack.setCurrentIndex(self.step)
            self._update_buttons()
        else:
            self._finish()

    def _skip(self) -> None:
        self.step += 1
        self.stack.setCurrentIndex(min(self.step, self.stack.count() - 1))
        self._update_buttons()

    def _finish(self) -> None:
        code = self.language_combo.currentData()
        self.config.language = code
        self.config.set("language_chosen", True)
        self.config.set("first_run", False)
        if self.selected_folder:
            # A folder chosen by hand stays a custom path, even when it happens
            # to be in the default LocalLow location.
            self.config.set("custom_assets", self.selected_folder)
            self.config.set("game_mode", "custom")
        self.accept()
