"""OPBR-inspired visual theme."""

from __future__ import annotations

from PySide6.QtGui import QColor, QFont, QFontDatabase, QPalette
from PySide6.QtWidgets import QApplication

# --- palette (sampled from the official OPBR site) ------------------------
BG = "#08080B"
BG_2 = "#0C0C10"
SURFACE = "#131318"
SURFACE_2 = "#191920"
SURFACE_3 = "#212129"
BORDER = "#2A2A33"
BORDER_HI = "#3B3B47"
TEXT = "#F6F6F8"
TEXT_DIM = "#B9B9C3"
MUTED = "#8C8C98"
ORANGE = "#FF8A00"
ORANGE_2 = "#FF9C00"
AMBER = "#FFB02E"
RED = "#FF4919"
CYAN = "#0FABD0"
CYAN_2 = "#33D4FF"
BLUE = "#00A8FF"
GREEN = "#23E59A"
YELLOW = "#FFD23F"


def _families() -> list[str]:
    available = set(QFontDatabase.families())
    preferred = [
        "Segoe UI Variable Text",
        "Segoe UI",
        "Yu Gothic UI",
        "Leelawadee UI",
        "Tahoma",
        "Arial",
    ]
    return [name for name in preferred if name in available] or ["Segoe UI"]


def body_font(size: float = 10.0, weight: QFont.Weight = QFont.Weight.Normal) -> QFont:
    font = QFont()
    families = _families()
    try:
        font.setFamilies(families)
    except Exception:
        font.setFamily(families[0])
    font.setPointSizeF(size)
    font.setWeight(weight)
    font.setStyleStrategy(QFont.StyleStrategy.PreferAntialias)
    return font


def heading_font(size: float = 20.0, weight: QFont.Weight = QFont.Weight.Black) -> QFont:
    available = set(QFontDatabase.families())
    candidates = [
        "Bahnschrift SemiBold SemiConden",
        "Bahnschrift SemiCondensed",
        "Bahnschrift",
        "Arial Narrow",
    ]
    family = next((f for f in candidates if f in available), None)
    font = body_font(size, weight)
    if family:
        font.setFamily(family)
        font.setFamilies([family] + _families())
    return font


def apply_theme(app: QApplication) -> None:
    app.setStyle("Fusion")
    palette = QPalette()
    palette.setColor(QPalette.ColorRole.Window, QColor(BG))
    palette.setColor(QPalette.ColorRole.Base, QColor(SURFACE))
    palette.setColor(QPalette.ColorRole.AlternateBase, QColor(SURFACE_2))
    palette.setColor(QPalette.ColorRole.Text, QColor(TEXT))
    palette.setColor(QPalette.ColorRole.WindowText, QColor(TEXT))
    palette.setColor(QPalette.ColorRole.Button, QColor(SURFACE_2))
    palette.setColor(QPalette.ColorRole.ButtonText, QColor(TEXT))
    palette.setColor(QPalette.ColorRole.Highlight, QColor(ORANGE))
    palette.setColor(QPalette.ColorRole.HighlightedText, QColor("#120A00"))
    palette.setColor(QPalette.ColorRole.ToolTipBase, QColor(SURFACE_2))
    palette.setColor(QPalette.ColorRole.ToolTipText, QColor(TEXT))
    app.setPalette(palette)
    app.setFont(body_font(10))
    app.setStyleSheet(QSS)


QSS = f"""
* {{
    outline: none;
}}
QWidget {{
    color: {TEXT};
    font-family: "Segoe UI", "Yu Gothic UI", "Leelawadee UI", "Tahoma";
    font-size: 13px;
}}
QMainWindow, QDialog {{
    background: transparent;
}}
#RootFrame {{
    background: {BG};
    border: 1px solid {BORDER};
    border-radius: 16px;
}}
#TitleBar {{
    background: transparent;
}}
#Sidebar {{
    background: rgba(9, 9, 12, 0.62);
    border-right: 1px solid rgba(42, 42, 51, 0.8);
}}
#ContentHost {{
    background: transparent;
}}
QScrollArea {{
    background: transparent;
    border: none;
}}
QScrollArea > QWidget > QWidget {{
    background: transparent;
}}
QScrollBar:vertical {{
    background: transparent;
    width: 10px;
    margin: 2px 1px 2px 1px;
}}
QScrollBar::handle:vertical {{
    background: #30303A;
    min-height: 30px;
    border-radius: 4px;
}}
QScrollBar::handle:vertical:hover {{
    background: #464653;
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical,
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {{
    height: 0px;
    background: transparent;
}}
QScrollBar:horizontal {{
    background: transparent;
    height: 10px;
    margin: 1px 2px 1px 2px;
}}
QScrollBar::handle:horizontal {{
    background: #30303A;
    min-width: 30px;
    border-radius: 4px;
}}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal,
QScrollBar::add-page:horizontal, QScrollBar::sub-page:horizontal {{
    width: 0px;
    background: transparent;
}}
QLineEdit {{
    background: {SURFACE};
    border: 1px solid {BORDER};
    border-radius: 10px;
    padding: 9px 12px;
    color: {TEXT};
    selection-background-color: {ORANGE};
    selection-color: #120A00;
}}
QLineEdit:hover {{
    border-color: {BORDER_HI};
}}
QLineEdit:focus {{
    border-color: {ORANGE};
    background: #15151B;
}}
QLineEdit:disabled {{
    color: {MUTED};
}}
QComboBox {{
    background: {SURFACE};
    border: 1px solid {BORDER};
    border-radius: 10px;
    padding: 8px 32px 8px 12px;
    color: {TEXT};
    min-height: 20px;
}}
QComboBox:hover {{
    border-color: {BORDER_HI};
}}
QComboBox:focus {{
    border-color: {ORANGE};
}}
QComboBox:disabled {{
    color: {MUTED};
}}
QComboBox QAbstractItemView {{
    background: {SURFACE_2};
    border: 1px solid {BORDER};
    border-radius: 10px;
    padding: 5px;
    color: {TEXT};
    selection-background-color: {ORANGE};
    selection-color: #120A00;
    outline: 0;
}}
QComboBox QAbstractItemView::item {{
    min-height: 26px;
    padding: 5px 9px;
    border-radius: 6px;
}}
QToolTip {{
    background: {SURFACE_2};
    color: {TEXT};
    border: 1px solid {BORDER_HI};
    padding: 6px 8px;
    border-radius: 6px;
}}
QProgressBar {{
    background: #1B1B22;
    border: none;
    border-radius: 4px;
    height: 7px;
    text-align: center;
    color: transparent;
}}
QProgressBar::chunk {{
    border-radius: 4px;
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
        stop:0 {ORANGE}, stop:1 {RED});
}}
QPushButton {{
    border: none;
    background: transparent;
}}
QMessageBox {{
    background: {SURFACE};
}}
QMenu {{
    background: {SURFACE_2};
    border: 1px solid {BORDER};
    border-radius: 8px;
    padding: 5px;
}}
QMenu::item {{
    padding: 7px 18px;
    border-radius: 5px;
}}
QMenu::item:selected {{
    background: {ORANGE};
    color: #120A00;
}}
"""
