"""Browse page."""

from __future__ import annotations

from datetime import datetime, timezone

from PySide6.QtCore import QThreadPool, QTimer, Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QButtonGroup,
    QHBoxLayout,
    QLabel,
    QScrollArea,
    QSizePolicy,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from .. import i18n
from ..feed import FeedError, fetch_feed
from ..util import time_ago
from . import icons
from .cards import ModCard
from .common import (
    Badge,
    ComboBox,
    EmptyState,
    FxButton,
    IconButton,
    SearchBar,
    Spinner,
    _alpha,
)
from .dialogs_extra import ModDetailsDialog
from .operations import install_feed_mod, repair_flow, uninstall_flow
from .page_base import Banner, BasePage
from .theme import BORDER, CYAN, GREEN, MUTED, ORANGE, TEXT, body_font, heading_font
from .workers import Worker


class BrowsePage(BasePage):
    def __init__(self, ctx, window) -> None:
        super().__init__(ctx, window)
        self._cards: list[ModCard] = []
        self._loading = False
        self._worker: Worker | None = None
        self._silent = False
        self._loaded_once = False

        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(170)
        self._search_timer.timeout.connect(self._rebuild_cards)

        self._auto_timer = QTimer(self)
        self._auto_timer.timeout.connect(self._auto_refresh)

        right = QWidget()
        right_layout = QHBoxLayout(right)
        right_layout.setContentsMargins(0, 4, 0, 0)
        right_layout.setSpacing(10)
        self.status_badge = Badge(i18n.tr("common_loading"), "muted")
        self.updated_label = QLabel("")
        self.updated_label.setFont(body_font(8.6))
        self.updated_label.setStyleSheet(f"color: {MUTED};")
        self.header_spinner = Spinner(size=18)
        self.header_spinner.hide()
        self.refresh_btn = IconButton(
            "refresh", self, size=36, icon_size=17, tooltip=i18n.tr("btn_refresh")
        )
        self.refresh_btn.clicked.connect(lambda: self.refresh(force=True))
        right_layout.addWidget(self.status_badge)
        right_layout.addWidget(self.updated_label)
        right_layout.addWidget(self.header_spinner)
        right_layout.addWidget(self.refresh_btn)
        self.root.addWidget(
            self.build_header(i18n.tr("browse_title"), i18n.tr("browse_subtitle"), right)
        )

        toolbar = QWidget()
        toolbar_layout = QHBoxLayout(toolbar)
        toolbar_layout.setContentsMargins(0, 0, 0, 0)
        toolbar_layout.setSpacing(10)
        self.search = SearchBar(i18n.tr("browse_search_ph"))
        self.search.textChanged.connect(lambda _t: self._search_timer.start())
        toolbar_layout.addWidget(self.search, 1)

        self.char_combo = ComboBox()
        self.char_combo.addItem(i18n.tr("browse_all_chars"), "")
        self.char_combo.setFixedWidth(210)
        self.char_combo.currentIndexChanged.connect(lambda _i: self._rebuild_cards())
        toolbar_layout.addWidget(self.char_combo)

        self.sort_combo = ComboBox()
        self.sort_combo.addItem(i18n.tr("browse_sort_newest"), "newest")
        self.sort_combo.addItem(i18n.tr("browse_sort_name"), "name")
        self.sort_combo.addItem(i18n.tr("browse_sort_size"), "size")
        self.sort_combo.setFixedWidth(150)
        self.sort_combo.currentIndexChanged.connect(lambda _i: self._rebuild_cards())
        toolbar_layout.addWidget(self.sort_combo)

        self.count_badge = Badge("0", "orange")
        toolbar_layout.addWidget(self.count_badge)
        self.root.addWidget(toolbar)

        filters = QWidget()
        filter_layout = QHBoxLayout(filters)
        filter_layout.setContentsMargins(0, 0, 0, 0)
        filter_layout.setSpacing(8)
        self.filter_group = QButtonGroup(self)
        self.filter_group.setExclusive(True)
        self.filter_buttons: dict[str, FxButton] = {}
        for key, label in (
            ("all", i18n.tr("browse_filter_all")),
            ("installed", i18n.tr("browse_filter_installed")),
            ("broken", i18n.tr("browse_filter_broken")),
        ):
            button = FxButton(label, self, variant="chip", height=29, radius=7)
            button.setCheckable(True)
            button.setFixedWidth(86 if key != "installed" else 100)
            button.clicked.connect(lambda _c=False, k=key: self._set_filter(k))
            self.filter_group.addButton(button)
            self.filter_buttons[key] = button
            filter_layout.addWidget(button)
        self.filter_buttons["all"].setChecked(True)
        filter_layout.addStretch(1)
        hint = QLabel(i18n.tr("tagline"))
        hint.setFont(body_font(8.6))
        hint.setStyleSheet(f"color: {MUTED};")
        filter_layout.addWidget(hint)
        self.root.addWidget(filters)

        self.offline_banner = Banner(i18n.tr("browse_offline"), "warning")
        self.offline_banner.hide()
        self.root.addWidget(self.offline_banner)

        self.stack = QStackedWidget()
        self.stack.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.root.addWidget(self.stack, 1)

        loading = QWidget()
        loading_layout = QVBoxLayout(loading)
        loading_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        loading_layout.setSpacing(12)
        loading_spinner = Spinner(size=42)
        loading_spinner.start()
        self._loading_spinner = loading_spinner
        loading_layout.addWidget(loading_spinner, 0, Qt.AlignmentFlag.AlignHCenter)
        loading_label = QLabel(i18n.tr("common_loading"))
        loading_label.setFont(body_font(9.8))
        loading_label.setStyleSheet(f"color: {MUTED};")
        loading_layout.addWidget(loading_label, 0, Qt.AlignmentFlag.AlignHCenter)
        self.stack.addWidget(loading)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        container = QWidget()
        container.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        from .common import FlowLayout

        self._flow_container = container
        self.flow = FlowLayout(container, margin=2, spacing=16)
        self.scroll.setWidget(container)
        self.stack.addWidget(self.scroll)

        self.message_container = QWidget()
        self.message_layout = QVBoxLayout(self.message_container)
        self.message_layout.setContentsMargins(0, 0, 0, 0)
        self.stack.addWidget(self.message_container)

        self._filter = "all"
        self._apply_visuals()

    # ------------------------------------------------------------------ data
    def on_show(self) -> None:
        if self.ctx.feed is None:
            self.refresh()
        else:
            self._rebuild_cards()

    def _auto_refresh(self) -> None:
        if self.isVisible():
            self.refresh(force=True, silent=True)

    def refresh(self, force: bool = False, silent: bool = False) -> None:
        if self._loading:
            return
        if self.ctx.feed is not None and not force:
            self._rebuild_cards()
            return
        self._loading = True
        self._silent = silent
        self.refresh_btn.setEnabled(False)
        self.header_spinner.show()
        self.header_spinner.start()
        if not silent and self.ctx.feed is None:
            self.stack.setCurrentIndex(0)
            self._loading_spinner.start()
        self.status_badge.set_kind("muted", i18n.tr("common_loading"))

        worker = Worker(lambda progress, cancel: fetch_feed(self.ctx.config))
        self._worker = worker
        self.window._workers.add(worker)
        worker.signals.finished.connect(self._on_feed)
        worker.signals.failed.connect(self._on_error)
        QThreadPool.globalInstance().start(worker)

    def _on_feed(self, data) -> None:
        self._loading = False
        self._worker = None
        self.header_spinner.stop()
        self.header_spinner.hide()
        self.refresh_btn.setEnabled(True)
        self.ctx.feed = data
        self.ctx.feed_loaded_at = datetime.now(timezone.utc)
        self._loaded_once = True
        self.offline_banner.setVisible(bool(data.offline))
        if data.offline:
            self.status_badge.set_kind("yellow", i18n.tr("common_offline"))
        else:
            self.status_badge.set_kind("green", i18n.tr("common_online"))
        when = time_ago(data.generated_at or self.ctx.feed_loaded_at, i18n.tr)
        self.updated_label.setText(i18n.tr("browse_updated", when=when))
        self._populate_characters()
        self._rebuild_cards()
        self._schedule_auto_refresh()

    def _on_error(self, message: str) -> None:
        self._loading = False
        self._worker = None
        self.header_spinner.stop()
        self.header_spinner.hide()
        self.refresh_btn.setEnabled(True)
        self.status_badge.set_kind("red", i18n.tr("common_offline"))
        if self._silent and self.ctx.feed is not None:
            return
        if self.ctx.feed is not None:
            self.window.toast(message, "error")
            self._rebuild_cards()
            return
        self._show_message(
            "alert",
            i18n.tr("browse_load_fail"),
            message,
            i18n.tr("btn_retry"),
            lambda: self.refresh(force=True),
        )

    def _schedule_auto_refresh(self) -> None:
        try:
            minutes = int(self.ctx.config.get("auto_refresh_minutes", 15) or 0)
        except Exception:
            minutes = 15
        if minutes > 0:
            self._auto_timer.start(minutes * 60 * 1000)
        else:
            self._auto_timer.stop()

    def _populate_characters(self) -> None:
        if self.ctx.feed is None:
            return
        current = self.char_combo.currentData() or ""
        characters = sorted(
            {mod.character.strip() for mod in self.ctx.feed.mods if mod.character.strip()},
            key=str.casefold,
        )
        self.char_combo.blockSignals(True)
        self.char_combo.clear()
        self.char_combo.addItem(i18n.tr("browse_all_chars"), "")
        for character in characters:
            self.char_combo.addItem(character, character)
        index = self.char_combo.findData(current)
        self.char_combo.setCurrentIndex(index if index >= 0 else 0)
        self.char_combo.blockSignals(False)

    # --------------------------------------------------------------- display
    def _set_filter(self, key: str) -> None:
        self._filter = key
        self._rebuild_cards()

    def _filtered_mods(self) -> list:
        if self.ctx.feed is None:
            return []
        text = self.search.text().strip().casefold()
        character = self.char_combo.currentData() or ""
        result = []
        for mod in self.ctx.feed.mods:
            if character and mod.character != character:
                continue
            state, _manifest, _reason = self.ctx.state_for_feed(mod)
            if self._filter == "installed" and state == "not_installed":
                continue
            if self._filter == "broken" and state != "needs_fix":
                continue
            if text:
                haystack = " ".join(
                    [
                        mod.display_title,
                        mod.character,
                        mod.author,
                        mod.description,
                        mod.notes,
                        " ".join(mod.labels),
                    ]
                ).casefold()
                if text not in haystack:
                    continue
            result.append(mod)
        sort_key = self.sort_combo.currentData() or "newest"
        if sort_key == "name":
            result.sort(key=lambda m: m.display_title.casefold())
        elif sort_key == "size":
            result.sort(key=lambda m: m.zip_size, reverse=True)
        else:
            result.sort(
                key=lambda m: (m.created_at.timestamp() if m.created_at else 0, m.id),
                reverse=True,
            )
        return result

    def _clear_cards(self) -> None:
        while self.flow.count():
            item = self.flow.takeAt(0)
            widget = item.widget() if item else None
            if widget is not None:
                widget.setParent(None)
                widget.deleteLater()
        self._cards.clear()

    def _update_flow_height(self) -> None:
        """Keep the scroll container tall enough for every wrapped row."""
        container = getattr(self, "_flow_container", None)
        if container is None:
            return
        try:
            width = max(160, self.scroll.viewport().width() - 6)
            needed = self.flow.heightForWidth(width)
            needed = max(needed, self.scroll.viewport().height())
            if container.minimumHeight() != needed:
                container.setMinimumHeight(needed)
            # Force the flow to place every card now; a layout activation while
            # an ancestor was hidden may have been skipped.
            self.flow.setGeometry(self.flow.geometry())
        except RuntimeError:
            # The page was replaced (language rebuild / window close) after a
            # queued timer fired. Nothing left to lay out.
            return

    def resizeEvent(self, event) -> None:  # noqa: N802
        super().resizeEvent(event)
        QTimer.singleShot(0, self._update_flow_height)

    def _rebuild_cards(self) -> None:
        if self.ctx.feed is None:
            return
        mods = self._filtered_mods()
        self.count_badge.set_text(i18n.tr("browse_mods_count", n=len(self._filtered_mods())))
        self._clear_cards()
        if not mods:
            if not self.ctx.feed.mods:
                self._show_message(
                    "sparkle",
                    i18n.tr("browse_empty_title"),
                    i18n.tr("browse_empty_sub"),
                )
            else:
                self._show_message(
                    "search",
                    i18n.tr("browse_no_results"),
                    i18n.tr("browse_no_results_sub"),
                )
            return
        for mod in mods:
            state, manifest, reason = self.ctx.state_for_feed(mod)
            card = ModCard(
                mod,
                self.ctx.images,
                manifest=manifest,
                state=state,
                reason=reason,
                animations=self.ctx.config.animations,
            )
            card.install_requested.connect(self._install)
            card.fix_requested.connect(self._fix)
            card.uninstall_requested.connect(self._uninstall)
            card.details_requested.connect(self._details)
            self.flow.addWidget(card)
            card.show()
            self._cards.append(card)
        self.stack.setCurrentIndex(1)
        self.flow.activate()
        QTimer.singleShot(0, self._update_flow_height)

    def _show_message(
        self,
        icon_name: str,
        title: str,
        subtitle: str,
        action_text: str = "",
        action=None,
    ) -> None:
        while self.message_layout.count():
            item = self.message_layout.takeAt(0)
            widget = item.widget() if item else None
            if widget is not None:
                widget.deleteLater()
        state = EmptyState(icon_name, title, subtitle, action_text=action_text, action=action)
        self.message_layout.addWidget(state)
        self.stack.setCurrentIndex(2)

    # --------------------------------------------------------------- actions
    def _install(self, mod) -> None:
        install_feed_mod(self.window, mod)

    def _fix(self, mod) -> None:
        manifest = self.ctx.manifest_for_feed(mod)
        if manifest is None:
            return
        repair_flow(self.window, manifest, mod)

    def _uninstall(self, mod) -> None:
        manifest = self.ctx.manifest_for_feed(mod)
        if manifest is None:
            return
        uninstall_flow(self.window, manifest)

    def _details(self, mod) -> None:
        state, manifest, _reason = self.ctx.state_for_feed(mod)
        preview = self.ctx.images.pixmap(mod.id)
        if preview is None:
            preview = self.ctx.images.placeholder(600, 600)
        dialog = ModDetailsDialog(
            self.window,
            mod,
            preview,
            state,
            manifest,
            on_install=self._install,
            on_fix=self._fix if state != "not_installed" else None,
            on_uninstall=self._uninstall if state != "not_installed" else None,
        )
        dialog.exec()

    # --------------------------------------------------------------- library
    def notify_library_changed(self) -> None:
        if self.ctx.feed is not None:
            self._rebuild_cards()

    def _apply_visuals(self) -> None:
        pass
