"""Reusable custom widgets and dialogs."""

from __future__ import annotations

import math
from typing import Callable

from PySide6.QtCore import (
    QEasingCurve,
    QPoint,
    QPointF,
    QPropertyAnimation,
    QRect,
    QRectF,
    QSize,
    Qt,
    QTimer,
    QVariantAnimation,
    Signal,
)
from PySide6.QtGui import (
    QBrush,
    QColor,
    QFont,
    QFontMetrics,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QPolygonF,
    QRadialGradient,
)
from PySide6.QtWidgets import (
    QAbstractButton,
    QComboBox,
    QDialog,
    QFrame,
    QGraphicsOpacityEffect,
    QHBoxLayout,
    QLabel,
    QLayout,
    QLineEdit,
    QPushButton,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from .. import i18n
from ..config import human_size
from . import icons
from .theme import (
    AMBER,
    BG,
    BORDER,
    BORDER_HI,
    CYAN,
    CYAN_2,
    GREEN,
    MUTED,
    ORANGE,
    ORANGE_2,
    RED,
    SURFACE,
    SURFACE_2,
    SURFACE_3,
    TEXT,
    TEXT_DIM,
    YELLOW,
    body_font,
    heading_font,
)

ANIMATIONS = True


def set_animations(enabled: bool) -> None:
    global ANIMATIONS
    ANIMATIONS = bool(enabled)


def _mix(a: str | QColor, b: str | QColor, t: float) -> QColor:
    c1 = QColor(a)
    c2 = QColor(b)
    t = max(0.0, min(1.0, t))
    return QColor(
        int(c1.red() + (c2.red() - c1.red()) * t),
        int(c1.green() + (c2.green() - c1.green()) * t),
        int(c1.blue() + (c2.blue() - c1.blue()) * t),
        int(c1.alpha() + (c2.alpha() - c1.alpha()) * t),
    )


def _alpha(color: str | QColor, alpha: int) -> QColor:
    c = QColor(color)
    c.setAlpha(alpha)
    return c


def elide(text: str, font: QFont, width: int) -> str:
    metrics = QFontMetrics(font)
    return metrics.elidedText(text, Qt.TextElideMode.ElideRight, max(10, width))


# ---------------------------------------------------------------------------
# buttons
# ---------------------------------------------------------------------------
class FxButton(QPushButton):
    """Rounded, animated button with a few visual variants."""

    VARIANTS = {
        "primary",
        "secondary",
        "ghost",
        "danger",
        "cyan",
        "chip",
        "dark",
        "binance",
        "discord",
    }

    def __init__(
        self,
        text: str = "",
        parent: QWidget | None = None,
        variant: str = "secondary",
        icon_name: str | None = None,
        height: int = 38,
        radius: int = 9,
    ) -> None:
        super().__init__(text, parent)
        self.variant = variant if variant in self.VARIANTS else "secondary"
        self.icon_name = icon_name
        self.radius = radius
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedHeight(height)
        self.setMinimumWidth(40)
        self._hover = 0.0
        self._pressed = False
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(130)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(self._on_anim)
        self.setFont(body_font(9.8, QFont.Weight.DemiBold))
        self.setCheckable(self.variant == "chip")

    def _on_anim(self, value) -> None:
        try:
            self._hover = float(value)
        except Exception:
            self._hover = 0.0
        self.update()

    def enterEvent(self, event) -> None:  # noqa: N802
        self._animate_to(1.0)
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        self._animate_to(0.0)
        super().leaveEvent(event)

    def _animate_to(self, value: float) -> None:
        if not ANIMATIONS:
            self._hover = value
            self.update()
            return
        self._anim.stop()
        self._anim.setStartValue(self._hover)
        self._anim.setEndValue(value)
        self._anim.start()

    def mousePressEvent(self, event) -> None:  # noqa: N802
        self._pressed = True
        self.update()
        super().mousePressEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        self._pressed = False
        self.update()
        super().mouseReleaseEvent(event)

    def sizeHint(self) -> QSize:  # noqa: N802
        metrics = QFontMetrics(self.font())
        width = metrics.horizontalAdvance(self.text()) + 34
        if self.icon_name:
            width += 25
        return QSize(max(width, 76), self.height())

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect()).adjusted(0.6, 0.6, -0.6, -0.6)
        enabled = self.isEnabled()
        hover = self._hover
        pressed = self._pressed

        bg: QColor
        border: QColor
        text_color: QColor
        gradient: tuple[QColor, QColor] | None = None
        icon_color: QColor

        if self.variant == "primary":
            top = _mix(ORANGE_2, "#FFC15E", hover * 0.55)
            bottom = _mix("#FF6A00", ORANGE, hover * 0.45)
            if pressed:
                top, bottom = bottom, top
            gradient = (top, bottom)
            bg = top
            border = _mix("#FF6A00", "#FFD08A", hover)
            text_color = QColor("#140A00")
            icon_color = QColor("#140A00")
        elif self.variant == "cyan":
            top = _mix(CYAN_2, "#8BEEFF", hover * 0.5)
            bottom = _mix(CYAN, "#17C4EA", hover * 0.4)
            gradient = (top, bottom)
            bg = top
            border = _mix(CYAN, "#9BEFFF", hover)
            text_color = QColor("#041014")
            icon_color = QColor("#041014")
        elif self.variant == "binance":
            top = _mix("#F7D33C", "#FFE47A", hover * 0.55)
            bottom = _mix("#EDB90A", "#F5C81F", hover * 0.45)
            if pressed:
                top, bottom = bottom, top
            gradient = (top, bottom)
            bg = top
            border = _mix("#EDB90A", "#FFF0A8", hover)
            text_color = QColor("#1A1400")
            icon_color = QColor("#1A1400")
        elif self.variant == "discord":
            top = _mix("#6F7BF7", "#8B95FF", hover * 0.5)
            bottom = _mix("#5865F2", "#6C78F7", hover * 0.4)
            gradient = (top, bottom)
            bg = top
            border = _mix("#5865F2", "#A9B1FF", hover)
            text_color = QColor("#FFFFFF")
            icon_color = QColor("#FFFFFF")
        elif self.variant == "danger":
            bg = _mix(_alpha(RED, 26), _alpha(RED, 55), hover)
            border = _mix(_alpha(RED, 120), _alpha(RED, 210), hover)
            text_color = _mix("#FF8A6B", "#FFB39E", hover)
            icon_color = text_color
        elif self.variant == "ghost":
            bg = _mix(QColor(0, 0, 0, 0), _alpha(SURFACE_3, 210), hover)
            border = _mix(_alpha(BORDER, 190), _alpha(BORDER_HI, 255), hover)
            text_color = _mix(TEXT_DIM, TEXT, hover)
            icon_color = text_color
        elif self.variant == "chip":
            if self.isChecked():
                bg = _alpha(ORANGE, 38)
                border = _alpha(ORANGE, 200)
                text_color = QColor(ORANGE_2)
                icon_color = text_color
            else:
                bg = _mix(QColor(0, 0, 0, 0), _alpha(SURFACE_3, 200), hover)
                border = _mix(_alpha(BORDER, 200), _alpha(BORDER_HI, 255), hover)
                text_color = _mix(MUTED, TEXT, hover)
                icon_color = text_color
        elif self.variant == "dark":
            bg = _mix(SURFACE_2, SURFACE_3, hover)
            border = _mix(BORDER, BORDER_HI, hover)
            text_color = QColor(TEXT)
            icon_color = QColor(TEXT_DIM)
        else:  # secondary
            bg = _mix(SURFACE_2, SURFACE_3, hover)
            border = _mix(BORDER, BORDER_HI, hover)
            text_color = QColor(TEXT)
            icon_color = QColor(TEXT_DIM)

        if not enabled:
            bg = _alpha(SURFACE_2, 150)
            border = _alpha(BORDER, 130)
            text_color = QColor(MUTED)
            icon_color = QColor(MUTED)
            gradient = None

        painter.setPen(Qt.PenStyle.NoPen)
        if gradient is not None and enabled:
            grad = QLinearGradient(rect.topLeft(), rect.bottomRight())
            grad.setColorAt(0.0, gradient[0])
            grad.setColorAt(1.0, gradient[1])
            painter.setBrush(QBrush(grad))
        else:
            painter.setBrush(QBrush(bg))
        painter.drawRoundedRect(rect, self.radius, self.radius)

        if border.alpha() > 0:
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.setPen(QPen(border, 1.0))
            painter.drawRoundedRect(rect, self.radius, self.radius)

        if self.hasFocus():
            painter.setPen(QPen(_alpha(ORANGE, 160), 1.4))
            painter.drawRoundedRect(rect.adjusted(1.6, 1.6, -1.6, -1.6), self.radius - 1, self.radius - 1)

        font = QFont(self.font())
        if self.variant in ("primary", "cyan", "binance", "discord"):
            font.setWeight(QFont.Weight.Bold)
        painter.setFont(font)
        metrics = QFontMetrics(font)
        text = self.text()
        icon_size = 15 if self.height() < 34 else 16
        gap = 7
        text_width = metrics.horizontalAdvance(text)
        total = text_width + (icon_size + gap if self.icon_name else 0)
        start_x = rect.left() + (rect.width() - total) / 2.0
        if self.icon_name:
            icon_rect = QRectF(start_x, rect.center().y() - icon_size / 2.0, icon_size, icon_size)
            icons.paint_icon(painter, self.icon_name, icon_rect, icon_color, 1.8)
            start_x += icon_size + gap
        painter.setPen(QPen(text_color))
        text_rect = QRectF(start_x, rect.top(), rect.right() - start_x - 4, rect.height())
        painter.drawText(
            text_rect,
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
            elide(text, font, int(text_rect.width())),
        )
        painter.end()

    def set_active(self, active: bool) -> None:
        self.setChecked(active)
        self.update()


class IconButton(QPushButton):
    def __init__(
        self,
        icon_name: str,
        parent: QWidget | None = None,
        size: int = 34,
        icon_size: int = 17,
        tooltip: str = "",
        color: str = TEXT_DIM,
        hover_color: str = TEXT,
        danger: bool = False,
    ) -> None:
        super().__init__(parent)
        self.icon_name = icon_name
        self._icon_size = icon_size
        self._color = color
        self._hover_color = RED if danger else hover_color
        self._danger = danger
        self._hover = 0.0
        self.setFixedSize(size, size)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        if tooltip:
            self.setToolTip(tooltip)
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(120)
        self._anim.valueChanged.connect(self._on_anim)

    def _on_anim(self, value) -> None:
        try:
            self._hover = float(value)
        except Exception:
            self._hover = 0.0
        self.update()

    def enterEvent(self, event) -> None:  # noqa: N802
        if ANIMATIONS:
            self._anim.stop()
            self._anim.setStartValue(self._hover)
            self._anim.setEndValue(1.0)
            self._anim.start()
        else:
            self._hover = 1.0
            self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        if ANIMATIONS:
            self._anim.stop()
            self._anim.setStartValue(self._hover)
            self._anim.setEndValue(0.0)
            self._anim.start()
        else:
            self._hover = 0.0
            self.update()
        super().leaveEvent(event)

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect()).adjusted(1, 1, -1, -1)
        if self._hover > 0.01:
            if self._danger:
                painter.setBrush(QBrush(_alpha(RED, int(38 * self._hover))))
            else:
                painter.setBrush(QBrush(_alpha(SURFACE_3, int(210 * self._hover))))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.drawRoundedRect(rect, 8, 8)
        color = _mix(self._color, self._hover_color, self._hover)
        pad = (rect.width() - self._icon_size) / 2.0
        icons.paint_icon(
            painter,
            self.icon_name,
            QRectF(rect.left() + pad, rect.top() + pad, self._icon_size, self._icon_size),
            color,
            1.75,
        )
        painter.end()


class NavButton(QPushButton):
    def __init__(self, text: str, icon_name: str, parent: QWidget | None = None) -> None:
        super().__init__(text, parent)
        self.icon_name = icon_name
        self._active = False
        self._hover = 0.0
        self.setFixedHeight(50)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFont(body_font(10.2, QFont.Weight.DemiBold))
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(140)
        self._anim.valueChanged.connect(self._on_anim)

    def _on_anim(self, value) -> None:
        try:
            self._hover = float(value)
        except Exception:
            self._hover = 0.0
        self.update()

    def enterEvent(self, event) -> None:  # noqa: N802
        if ANIMATIONS:
            self._anim.stop()
            self._anim.setStartValue(self._hover)
            self._anim.setEndValue(1.0)
            self._anim.start()
        else:
            self._hover = 1.0
            self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        if ANIMATIONS:
            self._anim.stop()
            self._anim.setStartValue(self._hover)
            self._anim.setEndValue(0.0)
            self._anim.start()
        else:
            self._hover = 0.0
            self.update()
        super().leaveEvent(event)

    def set_active(self, active: bool) -> None:
        if self._active != active:
            self._active = active
            self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rtl = self.layoutDirection() == Qt.LayoutDirection.RightToLeft
        w = self.width()
        h = self.height()
        skew = 10.0

        if self._active:
            poly = QPolygonF(
                [
                    QPointF(6, 2),
                    QPointF(w - 2, 2),
                    QPointF(w - 12, h - 2),
                    QPointF(0, h - 2),
                ]
                if not rtl
                else [
                    QPointF(2, 2),
                    QPointF(w - 6, 2),
                    QPointF(w, h - 2),
                    QPointF(12, h - 2),
                ]
            )
            grad = QLinearGradient(0, 0, w, 0)
            grad.setColorAt(0.0, _alpha(ORANGE, 46))
            grad.setColorAt(1.0, _alpha(ORANGE, 4))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QBrush(grad))
            painter.drawPolygon(poly)
            painter.setBrush(QBrush(QColor(ORANGE)))
            if not rtl:
                painter.drawRoundedRect(QRectF(0, 10, 3.4, h - 20), 1.7, 1.7)
            else:
                painter.drawRoundedRect(QRectF(w - 3.4, 10, 3.4, h - 20), 1.7, 1.7)
        elif self._hover > 0.01:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QBrush(_alpha(SURFACE_3, int(120 * self._hover))))
            painter.drawRoundedRect(QRectF(4, 3, w - 8, h - 6), 9, 9)

        if self._active:
            color = QColor(ORANGE_2)
        else:
            color = _mix(MUTED, TEXT, self._hover * 0.85)

        icon_size = 19
        if rtl:
            icon_x = w - 20 - icon_size
            text_rect = QRectF(16, 0, w - 20 - icon_size - 12, h)
            align = Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
        else:
            icon_x = 20
            text_rect = QRectF(icon_x + icon_size + 13, 0, w - icon_x - icon_size - 22, h)
            align = Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter

        icons.paint_icon(
            painter,
            self.icon_name,
            QRectF(icon_x, h / 2 - icon_size / 2, icon_size, icon_size),
            color,
            1.7,
        )
        font = QFont(self.font())
        font.setWeight(QFont.Weight.Bold if self._active else QFont.Weight.DemiBold)
        painter.setFont(font)
        painter.setPen(QPen(color))
        text = elide(self.text(), font, int(text_rect.width()))
        painter.drawText(text_rect, align, text)

        if self._active:
            painter.setBrush(QBrush(QColor(CYAN)))
            painter.setPen(Qt.PenStyle.NoPen)
            if rtl:
                painter.drawEllipse(QPointF(22, h / 2), 2.2, 2.2)
            else:
                painter.drawEllipse(QPointF(w - 22, h / 2), 2.2, 2.2)
        painter.end()


# ---------------------------------------------------------------------------
# toggles and chips
# ---------------------------------------------------------------------------
class ToggleSwitch(QAbstractButton):
    def __init__(self, parent: QWidget | None = None, checked: bool = False) -> None:
        super().__init__(parent)
        self.setCheckable(True)
        self.setChecked(checked)
        self.setFixedSize(46, 26)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._pos = 1.0 if checked else 0.0
        self._anim = QVariantAnimation(self)
        self._anim.setDuration(150)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(self._on_anim)
        self.toggled.connect(self._animate)

    def _on_anim(self, value) -> None:
        try:
            self._pos = float(value)
        except Exception:
            self._pos = 0.0
        self.update()

    def _animate(self, checked: bool) -> None:
        target = 1.0 if checked else 0.0
        if ANIMATIONS:
            self._anim.stop()
            self._anim.setStartValue(self._pos)
            self._anim.setEndValue(target)
            self._anim.start()
        else:
            self._pos = target
            self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(1, 3, self.width() - 2, self.height() - 6)
        track = _mix(QColor("#2C2C36"), QColor(ORANGE), self._pos)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(track))
        painter.drawRoundedRect(rect, rect.height() / 2, rect.height() / 2)
        knob_r = rect.height() / 2 - 3
        x = rect.left() + 4 + knob_r + (rect.width() - 8 - knob_r * 2) * self._pos
        painter.setBrush(QBrush(QColor("#FFFFFF")))
        painter.drawEllipse(QPointF(x, rect.center().y()), knob_r, knob_r)
        painter.end()


class SearchBar(QLineEdit):
    def __init__(self, placeholder: str = "", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setPlaceholderText(placeholder)
        self.setClearButtonEnabled(True)
        self.setMinimumHeight(38)
        self.addAction(icons.make_icon("search", MUTED, 16), QLineEdit.ActionPosition.LeadingPosition)
        self.setFont(body_font(9.8))


class ComboBox(QComboBox):
    """QComboBox with a painted chevron (QSS has no bundled arrow image)."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(38)

    def paintEvent(self, event) -> None:  # noqa: N802
        super().paintEvent(event)
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        color = QColor(TEXT_DIM) if self.isEnabled() else QColor(MUTED)
        rtl = self.layoutDirection() == Qt.LayoutDirection.RightToLeft
        x = 15 if rtl else self.width() - 23
        icons.paint_icon(painter, "chevron_down", QRectF(x, self.height() / 2 - 7, 14, 14), color, 1.7)
        painter.end()


class Badge(QWidget):
    def __init__(
        self,
        text: str = "",
        kind: str = "muted",
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self._text = text
        self._kind = kind
        self.setFont(body_font(8.2, QFont.Weight.Bold))
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.setFixedHeight(21)

    def set_kind(self, kind: str, text: str | None = None) -> None:
        self._kind = kind
        if text is not None:
            self._text = text
        self.updateGeometry()
        self.update()

    def set_text(self, text: str) -> None:
        self._text = text
        self.updateGeometry()
        self.update()

    def sizeHint(self) -> QSize:  # noqa: N802
        metrics = QFontMetrics(self.font())
        return QSize(metrics.horizontalAdvance(self._text) + 20, 21)

    def paintEvent(self, event) -> None:  # noqa: N802
        palette = {
            "orange": (ORANGE, 42),
            "green": (GREEN, 34),
            "yellow": (YELLOW, 38),
            "red": (RED, 40),
            "cyan": (CYAN, 38),
            "muted": (MUTED, 30),
            "blue": ("#00A8FF", 34),
        }
        color, alpha = palette.get(self._kind, palette["muted"])
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        painter.setPen(QPen(_alpha(color, 120), 1))
        painter.setBrush(QBrush(_alpha(color, alpha)))
        painter.drawRoundedRect(rect, 6, 6)
        painter.setPen(QPen(QColor(color)))
        painter.setFont(self.font())
        painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, self._text)
        painter.end()


# ---------------------------------------------------------------------------
# layout
# ---------------------------------------------------------------------------
class FlowLayout(QLayout):
    def __init__(self, parent: QWidget | None = None, margin: int = 0, spacing: int = 16) -> None:
        super().__init__(parent)
        self._items: list = []
        self._spacing = spacing
        self.setContentsMargins(margin, margin, margin, margin)

    def addItem(self, item) -> None:  # noqa: N802
        self._items.append(item)
        self.invalidate()

    def count(self) -> int:
        return len(self._items)

    def itemAt(self, index: int):  # noqa: N802
        if 0 <= index < len(self._items):
            return self._items[index]
        return None

    def takeAt(self, index: int):  # noqa: N802
        if 0 <= index < len(self._items):
            item = self._items.pop(index)
            self.invalidate()
            return item
        return None

    def expandingDirections(self):  # noqa: N802
        return Qt.Orientation(0)

    def hasHeightForWidth(self) -> bool:  # noqa: N802
        return True

    def heightForWidth(self, width: int) -> int:  # noqa: N802
        return self._do_layout(QRect(0, 0, width, 0), True)

    def setGeometry(self, rect: QRect) -> None:  # noqa: N802
        super().setGeometry(rect)
        self._do_layout(rect, False)

    def sizeHint(self) -> QSize:  # noqa: N802
        return self.minimumSize()

    def minimumSize(self) -> QSize:  # noqa: N802
        size = QSize()
        for item in self._items:
            size = size.expandedTo(item.minimumSize())
        margins = self.contentsMargins()
        return size + QSize(margins.left() + margins.right(), margins.top() + margins.bottom())

    def _do_layout(self, rect: QRect, test_only: bool) -> int:
        margins = self.contentsMargins()
        effective = rect.adjusted(margins.left(), margins.top(), -margins.right(), -margins.bottom())
        x = effective.x()
        y = effective.y()
        line_height = 0
        for item in self._items:
            widget = item.widget()
            # Honour explicit hide() only. isVisible() is also False when an
            # ancestor (e.g. an inactive stack page) is hidden, and skipping
            # those items leaves newly added cards unpositioned until the next
            # unrelated layout pass.
            if widget is not None and widget.isHidden():
                continue
            space_x = self._spacing
            space_y = self._spacing
            hint = item.sizeHint()
            next_x = x + hint.width() + space_x
            if next_x - space_x > effective.right() and line_height > 0:
                x = effective.x()
                y = y + line_height + space_y
                next_x = x + hint.width() + space_x
                line_height = 0
            if not test_only:
                item.setGeometry(QRect(QPoint(x, y), hint))
            x = next_x
            line_height = max(line_height, hint.height())
        return y + line_height - rect.y() + margins.bottom()


# ---------------------------------------------------------------------------
# decoration
# ---------------------------------------------------------------------------
class Spinner(QWidget):
    def __init__(self, parent: QWidget | None = None, size: int = 34, color: str = ORANGE) -> None:
        super().__init__(parent)
        self._angle = 0.0
        self._color = color
        self.setFixedSize(size, size)
        self._timer = QTimer(self)
        self._timer.setInterval(16)
        self._timer.timeout.connect(self._tick)

    def start(self) -> None:
        if ANIMATIONS:
            self._timer.start()

    def stop(self) -> None:
        self._timer.stop()

    def _tick(self) -> None:
        self._angle = (self._angle + 4.5) % 360
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect()).adjusted(4, 4, -4, -4)
        pen = QPen(_alpha(self._color, 60), 2.6)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        painter.drawArc(rect, 0, 360 * 16)
        pen.setColor(QColor(self._color))
        painter.setPen(pen)
        painter.drawArc(rect, int(-self._angle * 16), 110 * 16)
        painter.end()


class Backdrop(QWidget):
    """Animated diagonal speed lines and glows behind the content."""

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._phase = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(50)
        self._timer.timeout.connect(self._tick)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        if ANIMATIONS:
            self._timer.start()

    def set_animations(self, enabled: bool) -> None:
        if enabled and ANIMATIONS:
            self._timer.start()
        else:
            self._timer.stop()
        self.update()

    def _tick(self) -> None:
        self._phase = (self._phase + 0.8) % 1400
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w = self.width()
        h = self.height()
        if w <= 2 or h <= 2:
            return

        base = QLinearGradient(0, 0, 0, h)
        base.setColorAt(0.0, QColor("#0C0C11"))
        base.setColorAt(0.5, QColor("#09090C"))
        base.setColorAt(1.0, QColor("#08080B"))
        painter.fillRect(self.rect(), QBrush(base))

        glow = QRadialGradient(w * 0.86, h * 0.03, w * 0.62)
        glow.setColorAt(0.0, _alpha(ORANGE, 26))
        glow.setColorAt(0.45, _alpha(ORANGE, 9))
        glow.setColorAt(1.0, QColor(0, 0, 0, 0))
        painter.fillRect(self.rect(), QBrush(glow))

        glow2 = QRadialGradient(w * 0.08, h * 0.92, w * 0.55)
        glow2.setColorAt(0.0, _alpha(CYAN, 18))
        glow2.setColorAt(1.0, QColor(0, 0, 0, 0))
        painter.fillRect(self.rect(), QBrush(glow2))

        painter.save()
        painter.setClipRect(self.rect())
        span = w + h * 0.75
        for i in range(18):
            offset = (self._phase * (0.4 + (i % 5) * 0.16) + i * 97) % span
            x_bottom = offset - h * 0.42
            color = ORANGE if i % 4 == 0 else (CYAN if i % 5 == 0 else "#5A5A68")
            alpha = 18 if i % 4 == 0 else (13 if i % 5 == 0 else 9)
            pen = QPen(_alpha(color, alpha), 1.0 if i % 3 else 1.6)
            painter.setPen(pen)
            painter.drawLine(QPointF(x_bottom, h + 4), QPointF(x_bottom + h * 0.42, -4))
        painter.restore()

        watermark = heading_font(max(80, int(h * 0.24)), QFont.Weight.Black)
        watermark.setItalic(True)
        painter.setFont(watermark)
        painter.setPen(_alpha("#FFFFFF", 5))
        painter.drawText(
            QRectF(0, 0, w - 30, h - 10),
            Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignBottom,
            "OPBR",
        )

        bottom = QLinearGradient(0, h * 0.62, 0, h)
        bottom.setColorAt(0.0, QColor(0, 0, 0, 0))
        bottom.setColorAt(1.0, QColor(0, 0, 0, 90))
        painter.fillRect(self.rect(), QBrush(bottom))
        painter.end()


class LogoMark(QWidget):
    def __init__(self, size: int = 42, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFixedSize(size, size)
        self._pixmap = icons.brand_pixmap(max(size * 2, 96)).scaled(
            size * 2,
            size * 2,
            Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation,
        )
        self._pixmap.setDevicePixelRatio(2)

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.drawPixmap(0, 0, self._pixmap)
        painter.end()


class Card(QFrame):
    def __init__(
        self,
        parent: QWidget | None = None,
        radius: int = 14,
        fill: str = SURFACE,
        border: str = BORDER,
    ) -> None:
        super().__init__(parent)
        self.radius = radius
        self.fill = fill
        self.border = border
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, False)

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        painter.setPen(QPen(QColor(self.border), 1))
        painter.setBrush(QBrush(QColor(self.fill)))
        painter.drawRoundedRect(rect, self.radius, self.radius)
        painter.end()
        super().paintEvent(event)


class HLine(QFrame):
    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setFixedHeight(1)
        self.setStyleSheet(f"background: {BORDER};")


# ---------------------------------------------------------------------------
# toast
# ---------------------------------------------------------------------------
class Toast(QWidget):
    def __init__(self, parent: QWidget, message: str, kind: str = "success") -> None:
        super().__init__(parent)
        self._message = message
        self._kind = kind
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.setFont(body_font(9.6, QFont.Weight.DemiBold))
        metrics = QFontMetrics(self.font())
        width = min(max(metrics.horizontalAdvance(message) + 74, 240), 480)
        self.setFixedSize(width, 46)
        self._effect = QGraphicsOpacityEffect(self)
        self._effect.setOpacity(0.0)
        self.setGraphicsEffect(self._effect)
        self._fade = QPropertyAnimation(self._effect, b"opacity", self)
        self._fade.setDuration(180)

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        painter.setPen(QPen(_alpha(BORDER_HI, 210), 1))
        painter.setBrush(QBrush(_alpha("#15151B", 248)))
        painter.drawRoundedRect(rect, 10, 10)
        color = {"success": GREEN, "error": RED, "warning": YELLOW, "info": CYAN}.get(
            self._kind, GREEN
        )
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(QColor(color)))
        painter.drawRoundedRect(QRectF(rect.left(), rect.top() + 8, 3.6, rect.height() - 16), 1.8, 1.8)
        icon_name = {"success": "check", "error": "alert", "warning": "alert", "info": "info"}.get(
            self._kind, "check"
        )
        icons.paint_icon(painter, icon_name, QRectF(rect.left() + 16, rect.center().y() - 8, 16, 16), color, 1.8)
        painter.setPen(QPen(QColor(TEXT)))
        painter.setFont(self.font())
        painter.drawText(
            QRectF(rect.left() + 40, rect.top(), rect.width() - 52, rect.height()),
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
            elide(self._message, self.font(), int(rect.width() - 54)),
        )
        painter.end()

    def fade_in(self) -> None:
        self.show()
        self._fade.stop()
        self._fade.setStartValue(0.0)
        self._fade.setEndValue(1.0)
        self._fade.start()

    def fade_out(self, on_done: Callable | None = None) -> None:
        self._fade.stop()
        self._fade.setStartValue(1.0)
        self._fade.setEndValue(0.0)
        try:
            self._fade.finished.disconnect()
        except Exception:
            pass
        if on_done:
            self._fade.finished.connect(on_done)
        self._fade.start()


class ToastHost(QWidget):
    def __init__(self, parent: QWidget) -> None:
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self._toast: Toast | None = None
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._hide_current)

    def show_message(self, message: str, kind: str = "success", duration: int = 3200) -> None:
        self._timer.stop()
        if self._toast is not None:
            try:
                self._toast.deleteLater()
            except Exception:
                pass
            self._toast = None
        toast = Toast(self.parentWidget(), message, kind)
        self._toast = toast
        parent = self.parentWidget()
        x = max(20, parent.width() - toast.width() - 28)
        y = max(20, parent.height() - toast.height() - 28)
        toast.move(x, y + 18)
        toast.fade_in()
        if ANIMATIONS:
            anim = QPropertyAnimation(toast, b"pos", toast)
            anim.setDuration(220)
            anim.setEasingCurve(QEasingCurve.Type.OutCubic)
            anim.setStartValue(QPoint(x, y + 18))
            anim.setEndValue(QPoint(x, y))
            anim.start(QPropertyAnimation.DeletionPolicy.DeleteWhenStopped)
        else:
            toast.move(x, y)
        self._timer.start(duration)

    def _hide_current(self) -> None:
        toast = self._toast
        if toast is None:
            return
        self._toast = None
        toast.fade_out(toast.deleteLater)


# ---------------------------------------------------------------------------
# dialogs
# ---------------------------------------------------------------------------
class FxDialog(QDialog):
    def __init__(
        self,
        parent: QWidget | None = None,
        title: str = "",
        width: int = 520,
        icon_name: str | None = None,
        icon_kind: str = "orange",
    ) -> None:
        super().__init__(parent)
        self.setWindowFlags(
            Qt.WindowType.Dialog
            | Qt.WindowType.FramelessWindowHint
            | Qt.WindowType.WindowSystemMenuHint
        )
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)
        self.setModal(True)
        self._target_width = width
        outer = QVBoxLayout(self)
        outer.setContentsMargins(22, 22, 22, 22)
        self.card = Card(self, radius=16, fill="#121217", border=BORDER_HI)
        outer.addWidget(self.card)
        self.layout = QVBoxLayout(self.card)
        self.layout.setContentsMargins(26, 22, 26, 22)
        self.layout.setSpacing(16)

        header = QHBoxLayout()
        header.setSpacing(12)
        self._icon_badge: QWidget | None = None
        if icon_name:
            badge = _IconBadge(icon_name, icon_kind, 38)
            self._icon_badge = badge
            header.addWidget(badge, 0, Qt.AlignmentFlag.AlignTop)
        title_label = QLabel(title)
        title_label.setFont(heading_font(15.5, QFont.Weight.Bold))
        title_label.setWordWrap(True)
        title_label.setStyleSheet(f"color: {TEXT};")
        header.addWidget(title_label, 1)
        close_btn = IconButton("close", self, size=30, icon_size=14, tooltip=i18n.tr("btn_close"))
        close_btn.clicked.connect(self.reject)
        header.addWidget(close_btn, 0, Qt.AlignmentFlag.AlignTop)
        self.layout.addLayout(header)

        self.body = QVBoxLayout()
        self.body.setSpacing(12)
        self.layout.addLayout(self.body)

        self.buttons = QHBoxLayout()
        self.buttons.setSpacing(10)
        self.buttons.addStretch(1)
        self.layout.addLayout(self.buttons)
        self._faded = False

    def set_width(self, width: int) -> None:
        self._target_width = width
        self.setFixedWidth(width)

    def add_body(self, widget: QWidget) -> None:
        self.body.addWidget(widget)

    def add_body_layout(self, layout: QLayout) -> None:
        self.body.addLayout(layout)

    def add_button(
        self,
        text: str,
        variant: str = "secondary",
        callback: Callable | None = None,
        icon_name: str | None = None,
    ) -> FxButton:
        button = FxButton(text, self, variant=variant, icon_name=icon_name)
        button.setMinimumWidth(104)
        if callback:
            button.clicked.connect(callback)
        self.buttons.addWidget(button)
        return button

    def showEvent(self, event) -> None:  # noqa: N802
        super().showEvent(event)
        if not self._faded:
            self._faded = True
            self.setFixedWidth(self._target_width)
            self.adjustSize()
            parent = self.parentWidget()
            if parent is not None:
                geo = parent.window().geometry()
                self.move(
                    geo.center().x() - self.width() // 2,
                    geo.center().y() - self.height() // 2,
                )
            if ANIMATIONS:
                self.setWindowOpacity(0.0)
                anim = QPropertyAnimation(self, b"windowOpacity", self)
                anim.setDuration(160)
                anim.setStartValue(0.0)
                anim.setEndValue(1.0)
                anim.start(QPropertyAnimation.DeletionPolicy.DeleteWhenStopped)

    def keyPressEvent(self, event) -> None:  # noqa: N802
        if event.key() == Qt.Key.Key_Escape:
            self.reject()
            return
        super().keyPressEvent(event)


class _IconBadge(QWidget):
    def __init__(self, icon_name: str, kind: str, size: int = 38) -> None:
        super().__init__()
        self._icon = icon_name
        self._kind = kind
        self.setFixedSize(size, size)

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        color = {
            "orange": ORANGE,
            "red": RED,
            "green": GREEN,
            "yellow": YELLOW,
            "cyan": CYAN,
        }.get(self._kind, ORANGE)
        rect = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        painter.setPen(QPen(_alpha(color, 110), 1))
        painter.setBrush(QBrush(_alpha(color, 30)))
        painter.drawRoundedRect(rect, rect.width() / 2, rect.width() / 2)
        icons.paint_icon(
            painter,
            self._icon,
            rect.adjusted(10, 10, -10, -10),
            color,
            1.9,
        )
        painter.end()


class ConfirmDialog(FxDialog):
    def __init__(
        self,
        parent: QWidget | None,
        title: str,
        message: str,
        confirm_text: str,
        cancel_text: str,
        *,
        kind: str = "warning",
        danger: bool = False,
        extra: str = "",
        confirm_anyway: bool = False,
    ) -> None:
        icon = "alert" if kind in ("warning", "danger") else "info"
        super().__init__(parent, title, width=560, icon_name=icon, icon_kind=kind)
        self._confirmed = False

        label = QLabel(message)
        label.setWordWrap(True)
        label.setFont(body_font(9.9))
        label.setStyleSheet(f"color: {TEXT_DIM}; line-height: 150%;")
        self.add_body(label)
        if extra:
            extra_label = QLabel(extra)
            extra_label.setWordWrap(True)
            extra_label.setFont(body_font(9.2, QFont.Weight.DemiBold))
            extra_label.setStyleSheet(
                f"color: {YELLOW if not danger else '#FF8A6B'};"
                f"background: rgba(255, 210, 63, 0.07);"
                f"border: 1px solid rgba(255, 210, 63, 0.22);"
                f"border-radius: 8px; padding: 9px 11px;"
            )
            self.add_body(extra_label)

        cancel = self.add_button(cancel_text, "secondary", self.reject)
        cancel.setMinimumWidth(100)
        self._confirm = self.add_button(
            confirm_text,
            "danger" if danger else "primary",
            self._accept,
            icon_name="trash" if danger else "check",
        )
        self._confirm.setMinimumWidth(120)
        if confirm_anyway:
            self._confirm.setText(confirm_text)

    def _accept(self) -> None:
        self._confirmed = True
        self.accept()

    @classmethod
    def ask(
        cls,
        parent: QWidget | None,
        title: str,
        message: str,
        confirm_text: str,
        cancel_text: str | None = None,
        **kwargs,
    ) -> bool:
        dialog = cls(
            parent,
            title,
            message,
            confirm_text,
            cancel_text or i18n.tr("btn_cancel"),
            **kwargs,
        )
        return dialog.exec() == QDialog.DialogCode.Accepted and dialog._confirmed


class AlertDialog(FxDialog):
    def __init__(
        self,
        parent: QWidget | None,
        title: str,
        message: str,
        *,
        kind: str = "error",
        detail: str = "",
    ) -> None:
        icon = {"error": "alert", "warning": "alert", "info": "info", "success": "check"}.get(kind, "info")
        super().__init__(parent, title, width=540, icon_name=icon, icon_kind=kind)
        label = QLabel(message)
        label.setWordWrap(True)
        label.setFont(body_font(9.9))
        label.setStyleSheet(f"color: {TEXT_DIM}; line-height: 150%;")
        self.add_body(label)
        if detail:
            detail_label = QLabel(detail)
            detail_label.setWordWrap(True)
            detail_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            detail_label.setFont(body_font(8.8))
            detail_label.setStyleSheet(
                f"color: {MUTED}; background: #0E0E13; border: 1px solid {BORDER};"
                "border-radius: 8px; padding: 9px 11px;"
            )
            self.add_body(detail_label)
        button = self.add_button(i18n.tr("btn_close"), "primary", self.accept)
        button.setMinimumWidth(110)

    @classmethod
    def show_error(cls, parent, title: str, message: str, detail: str = "") -> None:
        AlertDialog(parent, title, message, kind="error", detail=detail).exec()


class ProgressDialog(FxDialog):
    def __init__(
        self,
        parent: QWidget | None,
        title: str,
        status: str = "",
        cancel_text: str | None = None,
        on_cancel: Callable | None = None,
    ) -> None:
        super().__init__(parent, title, width=500, icon_name="download", icon_kind="orange")
        self._on_cancel = on_cancel
        self._done = False
        self.status_label = QLabel(status)
        self.status_label.setFont(body_font(9.7))
        self.status_label.setStyleSheet(f"color: {TEXT_DIM};")
        self.status_label.setWordWrap(True)
        self.add_body(self.status_label)

        from PySide6.QtWidgets import QProgressBar

        self.bar = QProgressBar()
        self.bar.setRange(0, 100)
        self.bar.setValue(0)
        self.bar.setFixedHeight(7)
        self.bar.setTextVisible(False)
        self.add_body(self.bar)

        self.percent_label = QLabel("0%")
        self.percent_label.setFont(body_font(8.5, QFont.Weight.DemiBold))
        self.percent_label.setStyleSheet(f"color: {MUTED};")
        self.percent_label.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.add_body(self.percent_label)

        self.cancel_btn = self.add_button(
            cancel_text or i18n.tr("btn_cancel"), "secondary", self._cancel
        )
        self.cancel_btn.setMinimumWidth(100)

    def _cancel(self) -> None:
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.setText(i18n.tr("common_working"))
        self.status_label.setText(i18n.tr("common_working"))
        if self._on_cancel:
            self._on_cancel()

    def set_progress(self, value: float | None, text: str | None = None) -> None:
        if value is None:
            self.bar.setRange(0, 0)
            self.percent_label.setText("")
        else:
            self.bar.setRange(0, 100)
            percent = max(0, min(100, int(round(value * 100))))
            self.bar.setValue(percent)
            self.percent_label.setText(f"{percent}%")
        if text:
            self.status_label.setText(text)

    def finish(self) -> None:
        self._done = True
        self.cancel_btn.setEnabled(False)
        self.accept()

    def closeEvent(self, event) -> None:  # noqa: N802
        if not self._done:
            event.ignore()
            self._cancel()
            return
        super().closeEvent(event)

    def keyPressEvent(self, event) -> None:  # noqa: N802
        if event.key() == Qt.Key.Key_Escape:
            self._cancel()
            return
        super().keyPressEvent(event)


class EmptyState(QWidget):
    def __init__(
        self,
        icon_name: str,
        title: str,
        subtitle: str,
        parent: QWidget | None = None,
        action_text: str = "",
        action: Callable | None = None,
    ) -> None:
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 40, 20, 40)
        layout.setSpacing(8)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        badge = _IconBadge(icon_name, "orange", 62)
        layout.addWidget(badge, 0, Qt.AlignmentFlag.AlignHCenter)
        layout.addSpacing(8)
        title_label = QLabel(title)
        title_label.setFont(heading_font(15.5, QFont.Weight.Bold))
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label.setStyleSheet(f"color: {TEXT};")
        layout.addWidget(title_label)
        sub_label = QLabel(subtitle)
        sub_label.setFont(body_font(9.6))
        sub_label.setWordWrap(True)
        sub_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub_label.setStyleSheet(f"color: {MUTED};")
        sub_label.setMaximumWidth(480)
        layout.addWidget(sub_label, 0, Qt.AlignmentFlag.AlignHCenter)
        if action_text and action:
            layout.addSpacing(10)
            button = FxButton(action_text, self, variant="primary")
            button.setMinimumWidth(150)
            button.clicked.connect(action)
            layout.addWidget(button, 0, Qt.AlignmentFlag.AlignHCenter)


def human_bytes(size: int) -> str:
    return human_size(size)


def section_label(text: str) -> QLabel:
    label = QLabel(text)
    label.setFont(body_font(8.4, QFont.Weight.Bold))
    label.setStyleSheet(f"color: {MUTED}; letter-spacing: 1.2px;")
    return label
