"""Manual install page with drag & drop archive analysis."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import (
    QBrush,
    QColor,
    QFont,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
)
from PySide6.QtWidgets import (
    QFileDialog,
    QHBoxLayout,
    QLabel,
    QScrollArea,
    QSizePolicy,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

from .. import i18n
from ..config import human_size
from ..install import Analysis, cleanup_analysis, owned_targets, prepare_archive
from ..util import ModError, safe_name
from . import icons
from .common import (
    Badge,
    FxButton,
    IconButton,
    _alpha,
    _mix,
    section_label,
)
from .operations import manual_install_flow
from .page_base import Banner, BasePage, ensure_game_assets, run_operation
from .theme import (
    BORDER,
    BORDER_HI,
    CYAN,
    GREEN,
    MUTED,
    ORANGE,
    ORANGE_2,
    RED,
    SURFACE,
    SURFACE_2,
    SURFACE_3,
    TEXT,
    TEXT_DIM,
    YELLOW,
    body_font,
    heading_font,
)


class DropZone(QWidget):
    file_dropped = Signal(str)
    clicked = Signal()

    def __init__(self, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._hover = 0.0
        self._drag = False
        self.setAcceptDrops(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(230)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self._anim_value = 0.0
        self._timer = QTimer(self)
        self._timer.setInterval(40)
        self._timer.timeout.connect(self._tick)

    def _tick(self) -> None:
        target = 1.0 if self._drag else 0.0
        self._hover += (target - self._hover) * 0.2
        if abs(target - self._hover) < 0.01:
            self._hover = target
            self._timer.stop()
        self.update()

    def _animate(self, target: float) -> None:
        self._drag = target > 0.5
        if not self._timer.isActive():
            self._timer.start()

    def dragEnterEvent(self, event) -> None:  # noqa: N802
        if event.mimeData().hasUrls():
            urls = event.mimeData().urls()
            if any(u.toLocalFile().lower().endswith(".zip") for u in urls):
                event.acceptProposedAction()
                self._animate(1.0)
                return
        event.ignore()

    def dragLeaveEvent(self, event) -> None:  # noqa: N802
        self._animate(0.0)
        super().dragLeaveEvent(event)

    def dropEvent(self, event) -> None:  # noqa: N802
        self._animate(0.0)
        for url in event.mimeData().urls():
            path = url.toLocalFile()
            if path.lower().endswith(".zip"):
                self.file_dropped.emit(path)
                event.acceptProposedAction()
                return
        event.ignore()

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton and self.rect().contains(event.position().toPoint()):
            self.clicked.emit()
        super().mouseReleaseEvent(event)

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect()).adjusted(1.2, 1.2, -1.2, -1.2)

        if self._hover > 0.01:
            glow = QLinearGradient(0, 0, rect.width(), rect.height())
            glow.setColorAt(0.0, _alpha(ORANGE, int(20 + 26 * self._hover)))
            glow.setColorAt(1.0, _alpha(CYAN, int(10 + 16 * self._hover)))
            painter.setBrush(QBrush(glow))
        else:
            painter.setBrush(QBrush(QColor(SURFACE)))
        color = _mix(_alpha(BORDER_HI, 200), QColor(ORANGE), self._hover)
        pen = QPen(color, 1.6)
        pen.setStyle(Qt.PenStyle.DashLine)
        pen.setDashPattern([7, 5])
        painter.setPen(pen)
        painter.drawRoundedRect(rect, 16, 16)

        # icon
        icon_size = 58
        center_x = rect.center().x()
        icon_rect = QRectF(center_x - icon_size / 2, rect.top() + 42, icon_size, icon_size)
        painter.setPen(QPen(_alpha(_mix(MUTED, ORANGE, self._hover), 110), 1))
        painter.setBrush(QBrush(_alpha(_mix(MUTED, ORANGE, self._hover), 20)))
        painter.drawRoundedRect(icon_rect.adjusted(-12, -12, 12, 12), 34, 34)
        icons.paint_icon(
            painter,
            "download",
            icon_rect,
            _mix(TEXT_DIM, ORANGE_2, self._hover),
            1.7,
        )

        title = heading_font(14.5, QFont.Weight.Bold)
        painter.setFont(title)
        painter.setPen(QPen(QColor(TEXT)))
        painter.drawText(
            QRectF(rect.left(), icon_rect.bottom() + 22, rect.width(), 28),
            Qt.AlignmentFlag.AlignCenter,
            i18n.tr("manual_drop_title"),
        )
        sub = body_font(9.2)
        painter.setFont(sub)
        painter.setPen(QPen(QColor(MUTED)))
        painter.drawText(
            QRectF(rect.left(), icon_rect.bottom() + 50, rect.width(), 22),
            Qt.AlignmentFlag.AlignCenter,
            i18n.tr("manual_drop_sub"),
        )
        hint = body_font(8.4)
        painter.setFont(hint)
        painter.setPen(QPen(_alpha(MUTED, 180)))
        painter.drawText(
            QRectF(rect.left(), rect.bottom() - 34, rect.width(), 20),
            Qt.AlignmentFlag.AlignCenter,
            i18n.tr("manual_drop_hint"),
        )
        painter.end()


class FileRow(QWidget):
    def __init__(self, rel: str, size: int, original: bool, parent=None) -> None:
        super().__init__(parent)
        self.setFixedHeight(34)
        self.rel = rel
        self.size = size
        self.original = original

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect())
        if self.original:
            color = CYAN
        else:
            color = ORANGE
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(_alpha(color, 24)))
        painter.drawRoundedRect(QRectF(rect.left(), rect.top() + 4, 3, rect.height() - 8), 1.5, 1.5)
        icons.paint_icon(
            painter, "box", QRectF(rect.left() + 13, rect.center().y() - 7, 14, 14), color, 1.6
        )
        font = body_font(9.0)
        painter.setFont(font)
        painter.setPen(QPen(QColor(TEXT_DIM)))
        text_rect = QRectF(rect.left() + 36, rect.top(), rect.width() - 110, rect.height())
        painter.drawText(
            text_rect,
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
            self.rel,
        )
        painter.setPen(QPen(QColor(MUTED)))
        painter.setFont(body_font(8.6))
        painter.drawText(
            QRectF(rect.right() - 78, rect.top(), 66, rect.height()),
            Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter,
            human_size(self.size),
        )
        painter.end()


class ManualPage(BasePage):
    def __init__(self, ctx, window) -> None:
        super().__init__(ctx, window)
        self.analysis: Analysis | None = None
        self._preview: QPixmap | None = None
        self._selected_zip: Path | None = None

        right = QWidget()
        right_layout = QHBoxLayout(right)
        right_layout.setContentsMargins(0, 4, 0, 0)
        right_layout.setSpacing(9)
        self.change_btn = FxButton(
            i18n.tr("manual_change_file"), self, variant="ghost", height=36, icon_name="folder"
        )
        self.change_btn.clicked.connect(self._pick_file)
        self.change_btn.hide()
        right_layout.addWidget(self.change_btn)
        self.root.addWidget(
            self.build_header(
                i18n.tr("manual_title"), i18n.tr("manual_subtitle"), right
            )
        )

        self.stack = QStackedWidget()
        self.stack.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.root.addWidget(self.stack, 1)

        # --- drop page
        drop_page = QWidget()
        drop_layout = QVBoxLayout(drop_page)
        drop_layout.setContentsMargins(0, 0, 0, 0)
        drop_layout.setSpacing(14)
        self.drop_zone = DropZone()
        self.drop_zone.file_dropped.connect(self.load_zip)
        self.drop_zone.clicked.connect(self._pick_file)
        drop_layout.addWidget(self.drop_zone)
        choose_row = QHBoxLayout()
        choose_row.addStretch(1)
        choose = FxButton(
            i18n.tr("manual_select"), self, variant="primary", height=40, icon_name="folder"
        )
        choose.setMinimumWidth(170)
        choose.clicked.connect(self._pick_file)
        choose_row.addWidget(choose)
        choose_row.addStretch(1)
        drop_layout.addLayout(choose_row)
        drop_layout.addWidget(Banner(i18n.tr("settings_warning"), "warning"))
        drop_layout.addStretch(1)
        self.stack.addWidget(drop_page)

        # --- analysis page
        analysis_page = QWidget()
        analysis_layout = QVBoxLayout(analysis_page)
        analysis_layout.setContentsMargins(0, 0, 0, 0)
        analysis_layout.setSpacing(14)

        self.summary_card = SummaryCard()
        analysis_layout.addWidget(self.summary_card)

        self.restore_banner = Banner(i18n.tr("manual_restore_warning"), "warning")
        self.restore_banner.hide()
        analysis_layout.addWidget(self.restore_banner)
        self.conflict_banner = Banner("", "warning")
        self.conflict_banner.hide()
        analysis_layout.addWidget(self.conflict_banner)
        self.missing_banner = Banner("", "warning")
        self.missing_banner.hide()
        analysis_layout.addWidget(self.missing_banner)

        files_head = QHBoxLayout()
        files_head.addWidget(section_label(i18n.tr("manual_payload_title")))
        self.files_count = QLabel("")
        self.files_count.setFont(body_font(8.8, QFont.Weight.DemiBold))
        self.files_count.setStyleSheet(f"color: {MUTED};")
        files_head.addWidget(self.files_count)
        files_head.addStretch(1)
        analysis_layout.addLayout(files_head)

        self.file_scroll = QScrollArea()
        self.file_scroll.setWidgetResizable(True)
        self.file_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.file_scroll.setStyleSheet(
            f"QScrollArea {{ background: {SURFACE}; border: 1px solid {BORDER}; border-radius: 11px; }}"
        )
        self.file_holder = QWidget()
        self.file_list = QVBoxLayout(self.file_holder)
        self.file_list.setContentsMargins(8, 8, 8, 8)
        self.file_list.setSpacing(2)
        self.file_list.addStretch(1)
        self.file_scroll.setWidget(self.file_holder)
        analysis_layout.addWidget(self.file_scroll, 1)

        actions = QHBoxLayout()
        actions.setSpacing(10)
        self.back_to_drop = FxButton(
            i18n.tr("btn_back"), self, variant="ghost", height=40, icon_name="arrow_left"
        )
        self.back_to_drop.clicked.connect(self._reset)
        actions.addWidget(self.back_to_drop)
        actions.addStretch(1)
        self.install_btn = FxButton(
            i18n.tr("btn_install"), self, variant="primary", height=42, icon_name="download"
        )
        self.install_btn.setMinimumWidth(180)
        self.install_btn.clicked.connect(self._install)
        actions.addWidget(self.install_btn)
        analysis_layout.addLayout(actions)
        self.stack.addWidget(analysis_page)

        # --- loading page
        loading_page = QWidget()
        loading_layout = QVBoxLayout(loading_page)
        loading_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        loading_layout.setSpacing(14)
        from .common import Spinner

        self.spinner = Spinner(size=44)
        loading_layout.addWidget(self.spinner, 0, Qt.AlignmentFlag.AlignHCenter)
        loading_label = QLabel(i18n.tr("manual_analyzing"))
        loading_label.setFont(body_font(9.8))
        loading_label.setStyleSheet(f"color: {MUTED};")
        loading_layout.addWidget(loading_label, 0, Qt.AlignmentFlag.AlignHCenter)
        self.stack.addWidget(loading_page)
        self._loading_label = loading_label

    # ------------------------------------------------------------------ nav
    def on_show(self) -> None:
        pass

    def _reset(self) -> None:
        if self.analysis is not None:
            cleanup_analysis(self.analysis)
            self.analysis = None
        self._preview = None
        self._selected_zip = None
        self.change_btn.hide()
        self.stack.setCurrentIndex(0)

    def _pick_file(self) -> None:
        chosen, _ = QFileDialog.getOpenFileName(
            self.window,
            i18n.tr("manual_select"),
            str(Path.home()),
            "Mod archives (*.zip)",
        )
        if chosen:
            self.load_zip(chosen)

    # ------------------------------------------------------------- analysis
    def load_zip(self, path: str | Path) -> None:
        zip_path = Path(path)
        if not zip_path.is_file() or zip_path.suffix.lower() != ".zip":
            self.window.toast(i18n.tr("manual_invalid_zip"), "error")
            return
        if not ensure_game_assets(self.window):
            return
        assets = self.ctx.assets_root()
        if assets is None:
            return
        self._selected_zip = zip_path
        self._loading_label.setText(i18n.tr("manual_analyzing"))
        self.stack.setCurrentIndex(2)
        self.spinner.start()

        def job(progress, cancel):
            return prepare_archive(
                zip_path,
                assets,
                self.ctx.config.ensure_temp(),
                conflicts=owned_targets(self.ctx.config.mods_dir),
                progress=progress,
                cancel=cancel,
            )

        def done(analysis: Analysis) -> None:
            self.spinner.stop()
            self.analysis = analysis
            self._show_analysis(analysis)

        def failed(message: str) -> None:
            self.spinner.stop()
            self.stack.setCurrentIndex(0)
            self.window.toast(
                message if len(message) < 300 else i18n.tr("manual_analyze_fail"),
                "error",
            )

        run_operation(
            self.window,
            i18n.tr("manual_analyzing"),
            job,
            on_done=done,
            on_error=failed,
            initial_status=i18n.tr("stage_analyze"),
        )

    def _show_analysis(self, analysis: Analysis) -> None:
        preview = None
        if analysis.preview_bytes:
            pixmap = QPixmap()
            if pixmap.loadFromData(analysis.preview_bytes):
                preview = pixmap
        self._preview = preview

        original = analysis.original_mode
        self.summary_card.set_data(
            title=analysis.title_guess,
            subtitle=(
                i18n.tr("manual_restore_mode")
                if original
                else i18n.tr("manual_ready")
            ),
            preview=preview,
            file_count=len(analysis.items),
            total_size=human_size(analysis.total_size),
            original=original,
        )
        self.restore_banner.setVisible(original)
        self.conflict_banner.setVisible(bool(analysis.conflicts))
        if analysis.conflicts:
            owners = sorted({owner for _target, owner in analysis.conflicts})
            self.conflict_banner.set_text(
                i18n.tr("manual_conflict_note", n=len(analysis.conflicts))
                + "  "
                + ", ".join(owners)
            )
        self.missing_banner.setVisible(bool(analysis.missing))
        if analysis.missing:
            names = ", ".join(str(name) for name in analysis.missing[:6])
            if len(analysis.missing) > 6:
                names += f" (+{len(analysis.missing) - 6})"
            self.missing_banner.set_text(
                i18n.tr("manual_missing_note", n=len(analysis.missing))
            )
            self.missing_banner.setToolTip(names)

        while self.file_list.count() > 1:
            item = self.file_list.takeAt(0)
            widget = item.widget() if item else None
            if widget is not None:
                widget.deleteLater()
        for entry in analysis.items[:400]:
            row = FileRow(entry.target_rel, entry.size, original)
            self.file_list.insertWidget(self.file_list.count() - 1, row)
        if len(analysis.items) > 400:
            more = QLabel(i18n.tr("common_more", n=len(analysis.items) - 400))
            more.setFont(body_font(8.6, QFont.Weight.Bold))
            more.setStyleSheet(f"color: {ORANGE}; padding-left: 8px;")
            self.file_list.insertWidget(self.file_list.count() - 1, more)

        self.files_count.setText(
            i18n.tr(
                "manual_payload_count",
                n=len(analysis.items),
                size=human_size(analysis.total_size),
            )
        )
        if original:
            self.install_btn.setText(i18n.tr("btn_restore"))
            self.install_btn.icon_name = "refresh"
            self.install_btn.variant = "cyan"
        else:
            self.install_btn.setText(i18n.tr("btn_install"))
            self.install_btn.icon_name = "download"
            self.install_btn.variant = "primary"
        self.install_btn.update()
        self.change_btn.show()
        self.stack.setCurrentIndex(1)

    # --------------------------------------------------------------- install
    def _install(self) -> None:
        analysis = self.analysis
        if analysis is None:
            return
        self.analysis = None
        manual_install_flow(self.window, analysis, analysis.title_guess)
        QTimer.singleShot(400, self._reset_if_needed)

    def _reset_if_needed(self) -> None:
        if self.analysis is None:
            self._preview = None
            self.change_btn.hide()
            self.stack.setCurrentIndex(0)


class SummaryCard(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setFixedHeight(150)
        self._title = ""
        self._subtitle = ""
        self._preview: QPixmap | None = None
        self._count = 0
        self._size = ""
        self._original = False

    def set_data(
        self,
        title: str,
        subtitle: str,
        preview: QPixmap | None,
        file_count: int,
        total_size: str,
        original: bool,
    ) -> None:
        self._title = title
        self._subtitle = subtitle
        self._preview = preview
        self._count = file_count
        self._size = total_size
        self._original = original
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        rect = QRectF(self.rect()).adjusted(0.6, 0.6, -0.6, -0.6)
        accent = CYAN if self._original else ORANGE
        painter.setPen(QPen(_alpha(accent, 90), 1))
        painter.setBrush(QBrush(QColor(SURFACE)))
        painter.drawRoundedRect(rect, 14, 14)

        thumb = QRectF(rect.left() + 14, rect.top() + 14, 122, 122)
        clip = QPainterPath()
        clip.addRoundedRect(thumb, 10, 10)
        painter.setClipPath(clip)
        if self._preview is not None and not self._preview.isNull():
            scaled = self._preview.scaled(
                int(thumb.width() * self.devicePixelRatioF()),
                int(thumb.height() * self.devicePixelRatioF()),
                Qt.AspectRatioMode.KeepAspectRatioByExpanding,
                Qt.TransformationMode.SmoothTransformation,
            )
            scaled.setDevicePixelRatio(self.devicePixelRatioF())
            x = thumb.left() - (scaled.width() / scaled.devicePixelRatioF() - thumb.width()) / 2
            y = thumb.top() - (scaled.height() / scaled.devicePixelRatioF() - thumb.height()) / 2
            painter.drawPixmap(QPointF(x, y), scaled)
        else:
            grad = QLinearGradient(thumb.topLeft(), thumb.bottomRight())
            grad.setColorAt(0, QColor("#1B1B23"))
            grad.setColorAt(1, QColor("#0F0F14"))
            painter.fillRect(thumb, QBrush(grad))
            painter.setPen(QColor("#3A3A45"))
            painter.setFont(heading_font(19, QFont.Weight.Black))
            painter.drawText(thumb, Qt.AlignmentFlag.AlignCenter, "OPBR")
        painter.setClipping(False)
        painter.setPen(QPen(_alpha(accent, 70), 1))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRoundedRect(thumb, 10, 10)

        text_x = thumb.right() + 20
        width = rect.right() - text_x - 16

        tag = i18n.tr("manual_original_tag") if self._original else i18n.tr("manual_mod_tag")
        tag_font = body_font(7.8, QFont.Weight.Bold)
        painter.setFont(tag_font)
        metrics = painter.fontMetrics()
        tag_w = metrics.horizontalAdvance(tag) + 18
        tag_rect = QRectF(text_x, rect.top() + 18, tag_w, 21)
        painter.setPen(QPen(_alpha(accent, 120), 1))
        painter.setBrush(QBrush(_alpha(accent, 30)))
        painter.drawRoundedRect(tag_rect, 6, 6)
        painter.setPen(QPen(QColor(accent)))
        painter.drawText(tag_rect, Qt.AlignmentFlag.AlignCenter, tag)

        painter.setFont(heading_font(15.5, QFont.Weight.Bold))
        painter.setPen(QPen(QColor(TEXT)))
        title_rect = QRectF(text_x, tag_rect.bottom() + 10, width, 26)
        painter.drawText(
            title_rect,
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
            _elide(painter, self._title, title_rect.width()),
        )

        painter.setFont(body_font(9.0, QFont.Weight.DemiBold))
        painter.setPen(QPen(QColor(accent)))
        painter.drawText(
            QRectF(text_x, title_rect.bottom() + 2, width, 20),
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
            self._subtitle,
        )

        painter.setFont(body_font(8.9))
        painter.setPen(QPen(QColor(MUTED)))
        painter.drawText(
            QRectF(text_x, title_rect.bottom() + 26, width, 20),
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
            f"{i18n.tr('manual_files_total')}: {self._count}   ·   {self._size}",
        )
        painter.end()


def _elide(painter: QPainter, text: str, width: float) -> str:
    from PySide6.QtGui import QFontMetrics

    return QFontMetrics(painter.font()).elidedText(
        text, Qt.TextElideMode.ElideRight, int(max(10, width))
    )
