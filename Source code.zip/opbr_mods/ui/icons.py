"""Vector icons drawn with QPainter (no image assets required)."""

from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import (
    QBrush,
    QColor,
    QFont,
    QIcon,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
    QPolygonF,
)

from .theme import AMBER, BG, CYAN, ORANGE, RED, SURFACE, heading_font

_ICON_CACHE: dict[tuple, QIcon] = {}


def paint_icon(
    painter: QPainter,
    name: str,
    rect: QRectF,
    color: str | QColor = "#FFFFFF",
    stroke: float = 1.7,
) -> None:
    painter.save()
    painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    painter.translate(rect.left(), rect.top())
    scale = min(rect.width(), rect.height()) / 24.0
    painter.scale(scale, scale)
    pen = QPen(QColor(color), stroke, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap, Qt.PenJoinStyle.RoundJoin)
    painter.setPen(pen)
    painter.setBrush(Qt.BrushStyle.NoBrush)

    if name == "search":
        painter.drawEllipse(QRectF(4.2, 4.2, 11.4, 11.4))
        painter.drawLine(QPointF(14.6, 14.6), QPointF(20.0, 20.0))
    elif name == "refresh":
        painter.drawArc(QRectF(4.2, 4.2, 15.6, 15.6), 40 * 16, 275 * 16)
        painter.setBrush(QBrush(QColor(color)))
        painter.drawPolygon(
            QPolygonF([QPointF(17.4, 3.4), QPointF(20.4, 8.4), QPointF(14.8, 8.1)])
        )
    elif name == "close":
        painter.drawLine(QPointF(6.4, 6.4), QPointF(17.6, 17.6))
        painter.drawLine(QPointF(17.6, 6.4), QPointF(6.4, 17.6))
    elif name == "minimize":
        painter.drawLine(QPointF(6.0, 12.0), QPointF(18.0, 12.0))
    elif name == "maximize":
        painter.drawRoundedRect(QRectF(6.2, 6.2, 11.6, 11.6), 1.4, 1.4)
    elif name == "restore":
        painter.drawRoundedRect(QRectF(4.6, 8.0, 10.2, 10.2), 1.3, 1.3)
        painter.drawPolyline(
            QPolygonF(
                [
                    QPointF(8.2, 6.2),
                    QPointF(18.0, 6.2),
                    QPointF(18.0, 15.8),
                ]
            )
        )
    elif name == "chevron_down":
        painter.drawPolyline(QPolygonF([QPointF(7, 9.6), QPointF(12, 14.6), QPointF(17, 9.6)]))
    elif name == "chevron_right":
        painter.drawPolyline(QPolygonF([QPointF(9.6, 6.6), QPointF(14.8, 12), QPointF(9.6, 17.4)]))
    elif name == "arrow_left":
        painter.drawLine(QPointF(19, 12), QPointF(5, 12))
        painter.drawPolyline(QPolygonF([QPointF(10.4, 6.4), QPointF(4.8, 12), QPointF(10.4, 17.6)]))
    elif name == "arrow_right":
        painter.drawLine(QPointF(5, 12), QPointF(19, 12))
        painter.drawPolyline(QPolygonF([QPointF(13.6, 6.4), QPointF(19.2, 12), QPointF(13.6, 17.6)]))
    elif name == "gamepad":
        path = QPainterPath()
        path.moveTo(7.2, 7.0)
        path.lineTo(16.8, 7.0)
        path.cubicTo(20.8, 7.0, 22.2, 11.2, 21.2, 16.1)
        path.cubicTo(20.6, 19.2, 18.2, 19.7, 16.3, 17.6)
        path.lineTo(14.9, 16.0)
        path.lineTo(9.1, 16.0)
        path.lineTo(7.7, 17.6)
        path.cubicTo(5.8, 19.7, 3.4, 19.2, 2.8, 16.1)
        path.cubicTo(1.8, 11.2, 3.2, 7.0, 7.2, 7.0)
        painter.drawPath(path)
        painter.drawLine(QPointF(7.0, 10.1), QPointF(7.0, 13.5))
        painter.drawLine(QPointF(5.3, 11.8), QPointF(8.7, 11.8))
        painter.setBrush(QBrush(QColor(color)))
        painter.drawEllipse(QRectF(15.7, 9.9, 1.7, 1.7))
        painter.drawEllipse(QRectF(17.9, 12.0, 1.7, 1.7))
    elif name == "folder":
        path = QPainterPath()
        path.moveTo(3.2, 6.4)
        path.lineTo(9.0, 6.4)
        path.lineTo(11.0, 8.6)
        path.lineTo(20.4, 8.6)
        path.lineTo(20.4, 18.8)
        path.lineTo(3.2, 18.8)
        path.closeSubpath()
        painter.drawPath(path)
        painter.drawLine(QPointF(3.4, 11.2), QPointF(20.2, 11.2))
    elif name == "download":
        painter.drawLine(QPointF(12, 3.6), QPointF(12, 14.4))
        painter.drawPolyline(
            QPolygonF([QPointF(7.4, 10.2), QPointF(12, 14.8), QPointF(16.6, 10.2)])
        )
        painter.drawPolyline(
            QPolygonF([QPointF(4.4, 15.0), QPointF(4.4, 20.0), QPointF(19.6, 20.0), QPointF(19.6, 15.0)])
        )
    elif name == "trash":
        painter.drawLine(QPointF(3.6, 6.8), QPointF(20.4, 6.8))
        painter.drawLine(QPointF(9.4, 3.8), QPointF(14.6, 3.8))
        painter.drawPolyline(
            QPolygonF(
                [
                    QPointF(5.6, 7.2),
                    QPointF(6.8, 20.2),
                    QPointF(17.2, 20.2),
                    QPointF(18.4, 7.2),
                ]
            )
        )
        painter.drawLine(QPointF(10.0, 10.6), QPointF(10.4, 16.8))
        painter.drawLine(QPointF(14.0, 10.6), QPointF(13.6, 16.8))
    elif name == "wrench":
        painter.drawLine(QPointF(5.0, 19.2), QPointF(13.8, 10.4))
        painter.drawArc(QRectF(12.2, 3.4, 8.4, 8.4), 35 * 16, 285 * 16)
        painter.drawLine(QPointF(17.8, 9.6), QPointF(20.4, 12.2))
        painter.drawLine(QPointF(13.2, 5.0), QPointF(15.8, 7.6))
    elif name == "check":
        painter.drawPolyline(
            QPolygonF([QPointF(4.4, 12.6), QPointF(9.4, 17.4), QPointF(19.8, 6.6)])
        )
    elif name == "alert":
        path = QPainterPath()
        path.moveTo(12.0, 3.4)
        path.lineTo(21.4, 20.0)
        path.lineTo(2.6, 20.0)
        path.closeSubpath()
        painter.drawPath(path)
        painter.drawLine(QPointF(12.0, 8.8), QPointF(12.0, 13.8))
        painter.setBrush(QBrush(QColor(color)))
        painter.drawEllipse(QRectF(11.2, 15.9, 1.6, 1.6))
    elif name == "external":
        painter.drawPolyline(
            QPolygonF(
                [
                    QPointF(13.4, 4.4),
                    QPointF(19.6, 4.4),
                    QPointF(19.6, 10.6),
                ]
            )
        )
        painter.drawLine(QPointF(19.2, 4.8), QPointF(11.4, 12.6))
        painter.drawPolyline(
            QPolygonF(
                [
                    QPointF(17.0, 13.2),
                    QPointF(17.0, 19.8),
                    QPointF(4.4, 19.8),
                    QPointF(4.4, 7.2),
                    QPointF(11.0, 7.2),
                ]
            )
        )
    elif name == "copy":
        painter.drawRoundedRect(QRectF(8.2, 8.2, 11.4, 11.4), 2.0, 2.0)
        painter.drawPolyline(
            QPolygonF(
                [
                    QPointF(5.4, 15.8),
                    QPointF(4.4, 15.8),
                    QPointF(4.4, 4.4),
                    QPointF(15.8, 4.4),
                    QPointF(15.8, 5.4),
                ]
            )
        )
    elif name == "info":
        painter.drawEllipse(QRectF(3.4, 3.4, 17.2, 17.2))
        painter.drawLine(QPointF(12, 10.6), QPointF(12, 17.0))
        painter.setBrush(QBrush(QColor(color)))
        painter.drawEllipse(QRectF(11.2, 6.8, 1.6, 1.6))
    elif name == "box":
        painter.drawRoundedRect(QRectF(3.4, 5.6, 17.2, 4.6), 1.2, 1.2)
        painter.drawPolyline(
            QPolygonF(
                [
                    QPointF(5.0, 10.4),
                    QPointF(5.0, 19.6),
                    QPointF(19.0, 19.6),
                    QPointF(19.0, 10.4),
                ]
            )
        )
        painter.drawLine(QPointF(9.4, 14.6), QPointF(14.6, 14.6))
    elif name == "globe":
        painter.drawEllipse(QRectF(3.2, 3.2, 17.6, 17.6))
        painter.drawEllipse(QRectF(8.2, 3.2, 7.6, 17.6))
        painter.drawLine(QPointF(3.6, 12.0), QPointF(20.4, 12.0))
        painter.drawArc(QRectF(3.4, 7.2, 17.2, 9.6), 0, 180 * 16)
    elif name == "play":
        path = QPainterPath()
        path.moveTo(8.2, 4.6)
        path.lineTo(19.6, 12.0)
        path.lineTo(8.2, 19.4)
        path.closeSubpath()
        painter.setBrush(QBrush(QColor(color)))
        painter.drawPath(path)
    elif name == "clock":
        painter.drawEllipse(QRectF(3.2, 3.2, 17.6, 17.6))
        painter.drawLine(QPointF(12, 7.2), QPointF(12, 12.4))
        painter.drawLine(QPointF(12, 12.4), QPointF(15.6, 14.4))
    elif name == "sparkle":
        path = QPainterPath()
        path.moveTo(12, 2.8)
        path.lineTo(14.1, 9.0)
        path.lineTo(20.4, 11.1)
        path.lineTo(14.1, 13.2)
        path.lineTo(12, 19.6)
        path.lineTo(9.9, 13.2)
        path.lineTo(3.6, 11.1)
        path.lineTo(9.9, 9.0)
        path.closeSubpath()
        painter.drawPath(path)
    elif name == "shield":
        path = QPainterPath()
        path.moveTo(12, 3.0)
        path.lineTo(20.0, 6.4)
        path.lineTo(20.0, 11.6)
        path.cubicTo(20.0, 16.6, 16.4, 19.8, 12, 21.2)
        path.cubicTo(7.6, 19.8, 4.0, 16.6, 4.0, 11.6)
        path.lineTo(4.0, 6.4)
        path.closeSubpath()
        painter.drawPath(path)
        painter.drawPolyline(
            QPolygonF([QPointF(8.4, 12.0), QPointF(11.2, 14.8), QPointF(15.8, 9.4)])
        )
    elif name == "gear":
        path = QPainterPath()
        teeth = 8
        for i in range(teeth * 2):
            angle = (math.pi / teeth) * i - math.pi / 2
            radius = 9.6 if i % 2 == 0 else 7.2
            point = QPointF(12 + math.cos(angle) * radius, 12 + math.sin(angle) * radius)
            if i == 0:
                path.moveTo(point)
            else:
                path.lineTo(point)
        path.closeSubpath()
        painter.drawPath(path)
        painter.drawEllipse(QRectF(8.4, 8.4, 7.2, 7.2))
    elif name == "compass":
        painter.drawEllipse(QRectF(3.2, 3.2, 17.6, 17.6))
        painter.setBrush(QBrush(QColor(color)))
        painter.drawPolygon(
            QPolygonF([QPointF(15.8, 7.4), QPointF(13.2, 13.2), QPointF(8.2, 16.6), QPointF(10.8, 10.8)])
        )
    elif name == "grid":
        painter.drawRoundedRect(QRectF(4.0, 4.0, 6.4, 6.4), 1.2, 1.2)
        painter.drawRoundedRect(QRectF(13.6, 4.0, 6.4, 6.4), 1.2, 1.2)
        painter.drawRoundedRect(QRectF(4.0, 13.6, 6.4, 6.4), 1.2, 1.2)
        painter.drawRoundedRect(QRectF(13.6, 13.6, 6.4, 6.4), 1.2, 1.2)
    elif name == "image":
        painter.drawRoundedRect(QRectF(3.4, 4.6, 17.2, 14.8), 2.0, 2.0)
        painter.setBrush(QBrush(QColor(color)))
        painter.drawEllipse(QRectF(7.0, 8.0, 2.4, 2.4))
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawPolyline(
            QPolygonF(
                [
                    QPointF(4.6, 17.0),
                    QPointF(9.2, 12.4),
                    QPointF(12.4, 15.2),
                    QPointF(15.0, 12.8),
                    QPointF(19.4, 17.0),
                ]
            )
        )
    elif name == "link":
        painter.drawRoundedRect(QRectF(3.0, 9.0, 8.0, 6.0), 3.0, 3.0)
        painter.drawRoundedRect(QRectF(13.0, 9.0, 8.0, 6.0), 3.0, 3.0)
        painter.drawLine(QPointF(10.4, 12.0), QPointF(13.6, 12.0))
    elif name == "plus":
        painter.drawLine(QPointF(12, 5), QPointF(12, 19))
        painter.drawLine(QPointF(5, 12), QPointF(19, 12))
    elif name == "minus":
        painter.drawLine(QPointF(5, 12), QPointF(19, 12))
    elif name == "star":
        path = QPainterPath()
        for i in range(10):
            angle = -math.pi / 2 + i * math.pi / 5
            radius = 9.2 if i % 2 == 0 else 4.2
            point = QPointF(12 + math.cos(angle) * radius, 12 + math.sin(angle) * radius)
            if i == 0:
                path.moveTo(point)
            else:
                path.lineTo(point)
        path.closeSubpath()
        painter.drawPath(path)
    elif name == "heart":
        path = QPainterPath()
        path.moveTo(12, 20.2)
        path.cubicTo(5.6, 15.6, 3.0, 12.0, 3.0, 8.7)
        path.cubicTo(3.0, 6.1, 5.0, 4.1, 7.5, 4.1)
        path.cubicTo(9.4, 4.1, 11.0, 5.2, 12.0, 6.9)
        path.cubicTo(13.0, 5.2, 14.6, 4.1, 16.5, 4.1)
        path.cubicTo(19.0, 4.1, 21.0, 6.1, 21.0, 8.7)
        path.cubicTo(21.0, 12.0, 18.4, 15.6, 12, 20.2)
        path.closeSubpath()
        painter.setBrush(QBrush(QColor(color)))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawPath(path)
    elif name == "binance":
        painter.setBrush(QBrush(QColor(color)))
        painter.setPen(Qt.PenStyle.NoPen)
        for cx, cy, r in (
            (12.0, 12.0, 4.6),
            (12.0, 3.3, 2.4),
            (20.7, 12.0, 2.4),
            (12.0, 20.7, 2.4),
            (3.3, 12.0, 2.4),
        ):
            painter.save()
            painter.translate(cx, cy)
            painter.rotate(45)
            painter.drawRect(QRectF(-r / 1.414, -r / 1.414, r * 1.414, r * 1.414))
            painter.restore()
    elif name == "discord":
        path = QPainterPath()
        path.moveTo(7.0, 7.4)
        path.cubicTo(10.2, 5.8, 13.8, 5.8, 17.0, 7.4)
        path.cubicTo(19.6, 10.6, 20.1, 14.2, 18.7, 16.9)
        path.cubicTo(16.8, 18.4, 14.4, 19.2, 12.0, 19.2)
        path.cubicTo(9.6, 19.2, 7.2, 18.4, 5.3, 16.9)
        path.cubicTo(3.9, 14.2, 4.4, 10.6, 7.0, 7.4)
        path.closeSubpath()
        painter.drawPath(path)
        painter.setBrush(QBrush(QColor(color)))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawEllipse(QRectF(8.4, 10.6, 2.6, 3.0))
        painter.drawEllipse(QRectF(13.0, 10.6, 2.6, 3.0))
    else:
        painter.drawEllipse(QRectF(5, 5, 14, 14))
    painter.restore()


def make_icon(name: str, color: str = "#FFFFFF", size: int = 20, stroke: float = 1.7) -> QIcon:
    key = (name, color, size, stroke)
    cached = _ICON_CACHE.get(key)
    if cached is not None:
        return cached
    ratio = 2
    pixmap = QPixmap(size * ratio, size * ratio)
    pixmap.fill(Qt.GlobalColor.transparent)
    pixmap.setDevicePixelRatio(ratio)
    painter = QPainter(pixmap)
    paint_icon(painter, name, QRectF(0, 0, size, size), color, stroke)
    painter.end()
    icon = QIcon(pixmap)
    _ICON_CACHE[key] = icon
    return icon


def app_pixmap(size: int = 256) -> QPixmap:
    """The app artwork (assets/app.png), falling back to a painted mark."""
    try:
        from ..config import resource_path

        source = QPixmap(str(resource_path("assets", "app.png")))
        if not source.isNull():
            return source.scaled(
                size,
                size,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
    except Exception:
        pass
    return brand_pixmap(size)


def brand_pixmap(size: int = 256) -> QPixmap:
    """Crisp in-app brand mark (the vector OPBR tile)."""
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    rect = QRectF(0, 0, size, size)
    radius = size * 0.22
    clip = QPainterPath()
    clip.addRoundedRect(rect.adjusted(1, 1, -1, -1), radius, radius)
    painter.setClipPath(clip)

    grad = QLinearGradient(0, 0, size, size)
    grad.setColorAt(0.0, QColor("#17171E"))
    grad.setColorAt(0.55, QColor("#0B0B0F"))
    grad.setColorAt(1.0, QColor("#101017"))
    painter.fillRect(rect, QBrush(grad))

    # Orange speed stripe.
    stripe = QPolygonF(
        [
            QPointF(size * 0.02, size * 0.74),
            QPointF(size * 0.68, size * 0.02),
            QPointF(size * 0.92, size * 0.02),
            QPointF(size * 0.26, size * 0.98),
            QPointF(size * 0.02, size * 0.98),
        ]
    )
    painter.setPen(Qt.PenStyle.NoPen)
    painter.setBrush(QBrush(QColor(ORANGE)))
    painter.drawPolygon(stripe)

    # Cyan slash.
    slash = QPolygonF(
        [
            QPointF(size * 0.34, size * 0.98),
            QPointF(size * 0.98, size * 0.28),
            QPointF(size * 0.98, size * 0.46),
            QPointF(size * 0.46, size * 0.98),
        ]
    )
    painter.setBrush(QBrush(QColor(CYAN)))
    painter.drawPolygon(slash)

    font = heading_font(size * 0.46, QFont.Weight.Black)
    font.setItalic(True)
    painter.setFont(font)
    painter.setPen(QColor("#0A0A0D"))
    painter.drawText(
        QRectF(size * 0.04, size * 0.16, size * 0.86, size * 0.62),
        Qt.AlignmentFlag.AlignCenter,
        "OP",
    )
    painter.setPen(QColor("#FFFFFF"))
    small = heading_font(size * 0.105, QFont.Weight.Bold)
    small.setItalic(True)
    small.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, size * 0.006)
    painter.setFont(small)
    painter.drawText(
        QRectF(size * 0.18, size * 0.66, size * 0.64, size * 0.18),
        Qt.AlignmentFlag.AlignCenter,
        "MODS",
    )

    painter.setClipping(False)
    painter.setPen(QPen(QColor("#2E2E38"), max(1.0, size * 0.008)))
    painter.setBrush(Qt.BrushStyle.NoBrush)
    painter.drawRoundedRect(rect.adjusted(1, 1, -1, -1), radius, radius)
    painter.end()
    return pixmap


def app_icon() -> QIcon:
    try:
        from ..config import resource_path

        path = resource_path("assets", "app.ico")
        if path.is_file():
            icon = QIcon(str(path))
            if not icon.isNull():
                return icon
    except Exception:
        pass
    icon = QIcon()
    for size in (16, 24, 32, 48, 64, 128, 256):
        icon.addPixmap(app_pixmap(size))
    return icon
