"""Shared page scaffolding and background operation runner."""

from __future__ import annotations

from typing import Callable

from PySide6.QtCore import QThreadPool, QTimer, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QVBoxLayout,
    QWidget,
)

from .. import i18n
from ..util import game_running
from . import icons
from .common import (
    AlertDialog,
    Badge,
    FxButton,
    ProgressDialog,
    _alpha,
    _IconBadge,
    section_label,
)
from .theme import (
    BORDER,
    CYAN,
    GREEN,
    MUTED,
    ORANGE,
    RED,
    SURFACE_2,
    TEXT,
    TEXT_DIM,
    YELLOW,
    body_font,
    heading_font,
)
from .workers import Worker


class BasePage(QWidget):
    def __init__(self, ctx, window: QWidget) -> None:
        super().__init__(window)
        self.ctx = ctx
        self.window = window
        self.root = QVBoxLayout(self)
        self.root.setContentsMargins(30, 24, 30, 24)
        self.root.setSpacing(16)

    def build_header(self, title: str, subtitle: str, right: QWidget | None = None) -> QWidget:
        header = QWidget()
        layout = QHBoxLayout(header)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(14)

        accent = QWidget()
        accent.setFixedSize(4, 42)
        accent.setStyleSheet(
            f"background: qlineargradient(y1:0, y2:1, stop:0 {ORANGE}, stop:1 {RED});"
            "border-radius: 2px;"
        )
        layout.addWidget(accent, 0, Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignTop)

        text_box = QVBoxLayout()
        text_box.setSpacing(3)
        title_label = QLabel(title)
        title_label.setFont(heading_font(21.5, QFont.Weight.Black))
        title_label.setStyleSheet(f"color: {TEXT};")
        text_box.addWidget(title_label)
        sub_label = QLabel(subtitle)
        sub_label.setFont(body_font(9.5))
        sub_label.setStyleSheet(f"color: {MUTED};")
        sub_label.setWordWrap(True)
        text_box.addWidget(sub_label)
        layout.addLayout(text_box, 1)
        if right is not None:
            layout.addWidget(right, 0, Qt.AlignmentFlag.AlignTop)
        return header

    def toast(self, message: str, kind: str = "success") -> None:
        self.window.toast(message, kind)


def run_operation(
    window,
    title: str,
    job: Callable,
    on_done: Callable | None = None,
    on_error: Callable[[str], None] | None = None,
    on_cancel: Callable | None = None,
    initial_status: str | None = None,
) -> None:
    """Run job(progress, cancel) with a modal progress dialog."""
    dialog = ProgressDialog(
        window,
        title,
        initial_status or i18n.tr("common_working"),
        on_cancel=lambda: worker.cancel(),
    )
    worker = Worker(job)
    window._workers.add(worker)

    def cleanup() -> None:
        try:
            window._workers.discard(worker)
        except Exception:
            pass

    def handle_progress(value, stage) -> None:
        label = i18n.tr(stage) if stage else None
        dialog.set_progress(value, label)

    def handle_done(result) -> None:
        cleanup()
        dialog.finish()
        if on_done:
            QTimer.singleShot(0, lambda: on_done(result))

    def handle_error(message: str) -> None:
        cleanup()
        dialog.finish()
        if on_error:
            QTimer.singleShot(0, lambda: on_error(message))
        else:
            QTimer.singleShot(
                0,
                lambda: AlertDialog.show_error(
                    window, i18n.tr("dlg_error_title"), message
                ),
            )

    def handle_cancel() -> None:
        cleanup()
        dialog.finish()
        if on_cancel:
            QTimer.singleShot(0, on_cancel)

    worker.signals.progress.connect(handle_progress)
    worker.signals.finished.connect(handle_done)
    worker.signals.failed.connect(handle_error)
    worker.signals.cancelled.connect(handle_cancel)
    QThreadPool.globalInstance().start(worker)
    dialog.exec()


def ensure_game_assets(window) -> bool:
    if window.ctx.assets_root() is not None:
        return True
    AlertDialog(
        window,
        i18n.tr("dlg_assets_missing_title"),
        i18n.tr("dlg_assets_missing_body"),
        kind="warning",
    ).exec()
    window.navigate("settings")
    return False


def ensure_game_closed(window) -> bool:
    try:
        running = game_running()
    except Exception:
        running = False
    if not running:
        return True
    AlertDialog(
        window,
        i18n.tr("dlg_game_running_title"),
        i18n.tr("dlg_game_running_body"),
        kind="warning",
    ).exec()
    return False


class Banner(QWidget):
    def __init__(self, text: str, kind: str = "warning", parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self._text = text
        self._kind = kind
        self._icon = "alert" if kind in ("warning", "error") else "info"
        self.setFont(body_font(9.0, QFont.Weight.DemiBold))
        self.setFixedHeight(38)

    def set_text(self, text: str) -> None:
        self._text = text
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        color = {
            "warning": YELLOW,
            "error": RED,
            "info": CYAN,
            "success": GREEN,
        }.get(self._kind, YELLOW)
        rect = self.rect().adjusted(0, 0, -1, -1)
        painter.setPen(QPen(_alpha(color, 60), 1))
        painter.setBrush(QColor(_alpha(color, 16)))
        painter.drawRoundedRect(rect, 8, 8)
        icons.paint_icon(
            painter, self._icon, rect.adjusted(12, 11, -rect.width() + 25, -11), color, 1.7
        )
        painter.setPen(QPen(_alpha(color, 235)))
        painter.setFont(self.font())
        painter.drawText(
            rect.adjusted(34, 0, -12, 0),
            Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
            self._text,
        )
        painter.end()


def preview_pixmap(data: bytes | None) -> QPixmap | None:
    if not data:
        return None
    pixmap = QPixmap()
    if pixmap.loadFromData(data):
        return pixmap
    return None


def details_row(label: str, value: str, parent: QWidget | None = None) -> QWidget:
    row = QWidget(parent)
    layout = QHBoxLayout(row)
    layout.setContentsMargins(0, 0, 0, 0)
    layout.setSpacing(12)
    key = QLabel(label)
    key.setFixedWidth(108)
    key.setFont(body_font(8.8, QFont.Weight.Bold))
    key.setStyleSheet(f"color: {MUTED};")
    layout.addWidget(key, 0, Qt.AlignmentFlag.AlignTop)
    val = QLabel(value)
    val.setWordWrap(True)
    val.setFont(body_font(9.4))
    val.setStyleSheet(f"color: {TEXT_DIM};")
    val.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
    layout.addWidget(val, 1)
    return row
