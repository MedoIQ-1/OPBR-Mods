"""Browse and installed mod cards."""

from __future__ import annotations

from datetime import timedelta
from typing import Callable

from PySide6.QtCore import (
    QEasingCurve,
    QPointF,
    QRectF,
    Qt,
    QVariantAnimation,
    Signal,
)
from PySide6.QtGui import (
    QBrush,
    QColor,
    QFont,
    QFontMetrics,
    QLinearGradient,
    QPainter,
    QPainterPath,
    QPen,
    QPixmap,
)
from PySide6.QtWidgets import (
    QFrame,
    QGraphicsDropShadowEffect,
    QHBoxLayout,
    QLabel,
    QSizePolicy,
    QVBoxLayout,
    QWidget,
)

from .. import i18n
from ..config import human_size
from ..feed import FeedMod
from ..install import Manifest
from ..util import time_ago, utcnow
from . import icons
from . import common as _common
from .common import Badge, FxButton, IconButton, _alpha, _mix, elide
from .images import ImageService
from .theme import (
    AMBER,
    BORDER,
    BORDER_HI,
    CYAN,
    GREEN,
    MUTED,
    ORANGE,
    ORANGE_2,
    RED,
    SURFACE,
    SURFACE_2,
    SURFACE_3,
    TEXT,
    TEXT_DIM,
    YELLOW,
    body_font,
    heading_font,
)


class ElidedLabel(QLabel):
    def __init__(self, text: str = "", parent: QWidget | None = None) -> None:
        super().__init__(text, parent)
        self._full = text
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.setToolTip(text)

    def setText(self, text: str) -> None:  # noqa: N802
        self._full = text
        self.setToolTip(text)
        super().setText(text)

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setFont(self.font())
        painter.setPen(QPen(self.palette().color(self.foregroundRole())))
        rect = QRectF(self.rect())
        text = elide(self._full, self.font(), int(rect.width()))
        align = self.alignment()
        painter.drawText(rect, align | Qt.AlignmentFlag.AlignVCenter, text)
        painter.end()


class ThumbView(QWidget):
    clicked = Signal()

    def __init__(
        self,
        images: ImageService,
        key: str,
        url: str,
        fallback_url: str,
        cache_path,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.images = images
        self.key = key
        self.url = url
        self.fallback_url = fallback_url
        self.cache_path = cache_path
        self._pixmap: QPixmap | None = None
        self._scaled: QPixmap | None = None
        self._state = "none"
        self._new = False
        self._reason = ""
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(180)
        self.images.ready.connect(self._on_ready)
        self.images.request(key, url, cache_path, fallback_url)

    def _on_ready(self, key: str) -> None:
        if key != self.key:
            return
        pixmap = self.images.pixmap(self.key)
        if pixmap is not None:
            self._pixmap = pixmap
            self._scaled = None
            self.update()

    def set_state(self, state: str, new: bool = False, reason: str = "") -> None:
        self._state = state
        self._new = new
        self._reason = reason
        self.update()

    def _cover(self) -> QPixmap:
        source = self._pixmap or self.images.placeholder(600, 420)
        if self._scaled is not None:
            return self._scaled
        w = max(20, self.width())
        h = max(20, self.height())
        scaled = source.scaled(
            int(w * self.devicePixelRatioF()),
            int(h * self.devicePixelRatioF()),
            Qt.AspectRatioMode.KeepAspectRatioByExpanding,
            Qt.TransformationMode.SmoothTransformation,
        )
        scaled.setDevicePixelRatio(self.devicePixelRatioF())
        self._scaled = scaled
        return scaled

    def resizeEvent(self, event) -> None:  # noqa: N802
        self._scaled = None
        super().resizeEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # noqa: N802
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit()
        super().mouseReleaseEvent(event)

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        w = self.width()
        h = self.height()
        clip = QPainterPath()
        radius = 13.0
        clip.moveTo(0, radius)
        clip.quadTo(0, 0, radius, 0)
        clip.lineTo(w - radius, 0)
        clip.quadTo(w, 0, w, radius)
        clip.lineTo(w, h)
        clip.lineTo(0, h)
        clip.closeSubpath()
        painter.setClipPath(clip)

        cover = self._cover()
        x = (w - cover.width() / cover.devicePixelRatioF()) / 2.0
        y = (h - cover.height() / cover.devicePixelRatioF()) / 2.0
        painter.drawPixmap(QPointF(x, y), cover)

        overlay = QLinearGradient(0, h * 0.55, 0, h)
        overlay.setColorAt(0.0, QColor(0, 0, 0, 0))
        overlay.setColorAt(1.0, QColor(0, 0, 0, 150))
        painter.fillRect(QRectF(0, 0, w, h), QBrush(overlay))

        # status ribbon
        state = self._state
        if state in ("needs_fix", "installed", "update") or self._new:
            if state == "needs_fix":
                label, color = i18n.tr("status_needs_fix"), YELLOW
            elif state == "update":
                label, color = i18n.tr("status_update"), CYAN
            elif self._new and state == "not_installed":
                label, color = i18n.tr("status_new"), ORANGE
            elif state == "installed":
                label, color = i18n.tr("status_installed"), GREEN
            else:
                label, color = "", ORANGE
            if label:
                font = body_font(8.0, QFont.Weight.Bold)
                metrics = QFontMetrics(font)
                tw = metrics.horizontalAdvance(label)
                box = QRectF(12, 12, tw + (30 if state == "needs_fix" else 20), 23)
                painter.setPen(QPen(_alpha(color, 130), 1))
                painter.setBrush(QBrush(_alpha("#0B0B0F", 215)))
                painter.drawRoundedRect(box, 6, 6)
                if state == "needs_fix":
                    icons.paint_icon(
                        painter, "alert", QRectF(box.left() + 7, box.top() + 5, 13, 13), color, 1.7
                    )
                    text_x = box.left() + 24
                else:
                    text_x = box.left() + 10
                painter.setFont(font)
                painter.setPen(QPen(color))
                painter.drawText(
                    QRectF(text_x, box.top(), box.right() - text_x - 6, box.height()),
                    Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter,
                    label,
                )

        if self._new and state not in ("needs_fix", "update"):
            # small diagonal NEW tag on the right
            pass
        painter.end()


class ModCard(QFrame):
    install_requested = Signal(object)
    fix_requested = Signal(object)
    uninstall_requested = Signal(object)
    details_requested = Signal(object)

    WIDTH = 304

    def __init__(
        self,
        feed_mod: FeedMod,
        images: ImageService,
        manifest: Manifest | None = None,
        state: str = "not_installed",
        reason: str = "",
        parent: QWidget | None = None,
        animations: bool = True,
    ) -> None:
        super().__init__(parent)
        self.feed_mod = feed_mod
        self.manifest = manifest
        self.state = state
        self.reason = reason
        self._hover = 0.0
        self._busy = False
        self._progress = -1.0
        self.setFixedSize(self.WIDTH, 372)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, False)
        self.setMouseTracking(True)

        self._shadow = QGraphicsDropShadowEffect(self)
        self._shadow.setBlurRadius(26)
        self._shadow.setOffset(0, 9)
        self._shadow.setColor(QColor(0, 0, 0, 135))
        self.setGraphicsEffect(self._shadow)

        self._anim = QVariantAnimation(self)
        self._anim.setDuration(160)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.valueChanged.connect(self._on_hover)
        self._anim_enabled = animations

        layout = QVBoxLayout(self)
        layout.setContentsMargins(1, 1, 1, 1)
        layout.setSpacing(0)

        cache_name = f"{feed_mod.id}.img"
        self.thumb = ThumbView(
            images,
            feed_mod.id,
            feed_mod.image_url,
            feed_mod.preview_proxy_url if feed_mod.image_url != feed_mod.preview_proxy_url else "",
            images.config.thumbs_dir / cache_name,
        )
        self.thumb.setFixedHeight(188)
        self.thumb.clicked.connect(lambda: self.details_requested.emit(self.feed_mod))
        new = False
        if feed_mod.created_at is not None:
            try:
                new = (utcnow() - feed_mod.created_at) < timedelta(days=7)
            except Exception:
                new = False
        self.thumb.set_state(state, new, reason)
        layout.addWidget(self.thumb)

        body = QVBoxLayout()
        body.setContentsMargins(15, 12, 15, 14)
        body.setSpacing(5)
        self.title_label = ElidedLabel(feed_mod.display_title)
        self.title_label.setFont(heading_font(12.2, QFont.Weight.Bold))
        self.title_label.setStyleSheet(f"color: {TEXT};")
        body.addWidget(self.title_label)

        self.character_label = ElidedLabel(feed_mod.character_text)
        self.character_label.setFont(body_font(9.3, QFont.Weight.DemiBold))
        self.character_label.setStyleSheet(f"color: {ORANGE_2};")
        body.addWidget(self.character_label)

        meta = f"{feed_mod.size_text}  ·  {time_ago(feed_mod.created_at, i18n.tr)}"
        self.meta_label = ElidedLabel(meta)
        self.meta_label.setFont(body_font(8.6))
        self.meta_label.setStyleSheet(f"color: {MUTED};")
        body.addWidget(self.meta_label)

        body.addStretch(1)

        row = QHBoxLayout()
        row.setSpacing(7)
        self.install_btn = FxButton(
            i18n.tr("btn_install"),
            self,
            variant="primary",
            height=34,
            icon_name="download" if state == "not_installed" else "refresh",
        )
        self.install_btn.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        self.install_btn.clicked.connect(lambda: self.install_requested.emit(self.feed_mod))
        row.addWidget(self.install_btn, 1)

        self.fix_btn = FxButton(i18n.tr("btn_fix"), self, variant="ghost", height=34, icon_name="wrench")
        self.fix_btn.setFixedWidth(72)
        self.fix_btn.clicked.connect(lambda: self.fix_requested.emit(self.feed_mod))
        row.addWidget(self.fix_btn)

        self.trash_btn = IconButton(
            "trash",
            self,
            size=34,
            icon_size=16,
            tooltip=i18n.tr("btn_uninstall"),
            danger=True,
        )
        self.trash_btn.clicked.connect(lambda: self.uninstall_requested.emit(self.feed_mod))
        row.addWidget(self.trash_btn)
        body.addLayout(row)

        layout.addLayout(body)
        self._apply_state()

    def _on_hover(self, value) -> None:
        try:
            self._hover = float(value)
        except Exception:
            self._hover = 0.0
        blur = 26 + 18 * self._hover
        self._shadow.setBlurRadius(blur)
        self._shadow.setColor(QColor(0, 0, 0, int(135 + 40 * self._hover)))
        self.update()

    def enterEvent(self, event) -> None:  # noqa: N802
        if self._anim_enabled and _common.ANIMATIONS:
            self._anim.stop()
            self._anim.setStartValue(self._hover)
            self._anim.setEndValue(1.0)
            self._anim.start()
        else:
            self._hover = 1.0
            self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        if self._anim_enabled and _common.ANIMATIONS:
            self._anim.stop()
            self._anim.setStartValue(self._hover)
            self._anim.setEndValue(0.0)
            self._anim.start()
        else:
            self._hover = 0.0
            self.update()
        super().leaveEvent(event)

    def set_state(self, state: str, manifest: Manifest | None, reason: str = "") -> None:
        self.state = state
        self.manifest = manifest
        self.reason = reason
        new = False
        if self.feed_mod.created_at is not None:
            try:
                new = (utcnow() - self.feed_mod.created_at) < timedelta(days=7)
            except Exception:
                new = False
        self.thumb.set_state(state, new, reason)
        self._apply_state()

    def _apply_state(self) -> None:
        installed = self.state in ("installed", "needs_fix", "update")
        if self.state == "installed":
            self.install_btn.setText(i18n.tr("btn_reinstall"))
            self.install_btn.icon_name = "refresh"
        elif self.state == "update":
            self.install_btn.setText(i18n.tr("btn_update"))
            self.install_btn.icon_name = "download"
        elif self.state == "needs_fix":
            self.install_btn.setText(i18n.tr("btn_reinstall"))
            self.install_btn.icon_name = "refresh"
        else:
            self.install_btn.setText(i18n.tr("btn_install"))
            self.install_btn.icon_name = "download"
        self.fix_btn.setEnabled(installed)
        self.trash_btn.setEnabled(installed)
        if self.state == "needs_fix":
            self.fix_btn.variant = "chip"
            self.fix_btn.setChecked(True)
        else:
            self.fix_btn.variant = "ghost"
            self.fix_btn.setChecked(False)
        self.fix_btn.update()
        self.install_btn.update()
        self.trash_btn.setToolTip(
            i18n.tr("btn_uninstall") if installed else i18n.tr("status_not_installed")
        )
        self.setToolTip(self.reason if self.reason else "")
        self.update()

    def set_busy(self, busy: bool, progress: float = -1.0, text: str = "") -> None:
        self._busy = busy
        self._progress = progress
        for button in (self.install_btn, self.fix_btn, self.trash_btn):
            button.setEnabled(not busy)
        if busy:
            self.install_btn.setText(text or i18n.tr("common_working"))
        else:
            self._apply_state()
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect()).adjusted(0.7, 0.7, -0.7, -0.7)
        if self.state == "needs_fix":
            border = _alpha(YELLOW, 190)
        elif self.state == "update":
            border = _alpha(CYAN, 150)
        elif self.state == "installed":
            border = _mix(BORDER, _alpha(GREEN, 90), self._hover)
        else:
            border = _mix(BORDER, _alpha(ORANGE, 210), self._hover)
        painter.setPen(QPen(border, 1.2 if self.state == "needs_fix" else 1.0))
        painter.setBrush(QBrush(QColor("#131318")))
        painter.drawRoundedRect(rect, 14, 14)

        if self.state == "needs_fix":
            painter.setPen(QPen(_alpha(YELLOW, 80), 4))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawRoundedRect(rect.adjusted(2.5, 2.5, -2.5, -2.5), 12, 12)

        if self._busy and self._progress >= 0:
            width = (self.width() - 28) * max(0.0, min(1.0, self._progress))
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QBrush(QColor(ORANGE)))
            painter.drawRoundedRect(QRectF(14, self.height() - 7, max(4.0, width), 3), 1.5, 1.5)
        elif self._busy:
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QBrush(_alpha(ORANGE, 180)))
            painter.drawRoundedRect(QRectF(14, self.height() - 7, self.width() - 28, 3), 1.5, 1.5)
        painter.end()


class InstalledCard(QFrame):
    fix_requested = Signal(object)
    uninstall_requested = Signal(object)
    purge_requested = Signal(object)
    details_requested = Signal(object)

    def __init__(
        self,
        manifest: Manifest,
        images: ImageService,
        needs_fix: bool = False,
        reason: str = "",
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.manifest = manifest
        self.needs_fix = needs_fix
        self.reason = reason
        self._hover = 0.0
        self._busy = False
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, False)
        self.setMinimumHeight(122)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        self._anim = QVariantAnimation(self)
        self._anim.setDuration(150)
        self._anim.valueChanged.connect(self._on_hover)

        layout = QHBoxLayout(self)
        layout.setContentsMargins(16, 14, 16, 14)
        layout.setSpacing(14)

        self.thumb = ThumbView(
            images,
            f"installed_{manifest.id}",
            "",
            "",
            manifest.preview_path,
        )
        self.thumb.setFixedSize(94, 94)
        self.thumb.clicked.connect(lambda: self.details_requested.emit(self.manifest))
        layout.addWidget(self.thumb, 0, Qt.AlignmentFlag.AlignVCenter)

        info = QVBoxLayout()
        info.setSpacing(4)
        title = ElidedLabel(manifest.title)
        title.setFont(heading_font(12.4, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {TEXT};")
        info.addWidget(title)

        sub = manifest.character or "—"
        char = ElidedLabel(sub)
        char.setFont(body_font(9.2, QFont.Weight.DemiBold))
        char.setStyleSheet(f"color: {ORANGE_2};")
        info.addWidget(char)

        installed = time_ago(manifest.installed_dt, i18n.tr)
        meta = f"{i18n.tr('installed_files_count', n=len(manifest.files))}  ·  {manifest.size_text}  ·  {installed}"
        meta_label = ElidedLabel(meta)
        meta_label.setFont(body_font(8.7))
        meta_label.setStyleSheet(f"color: {MUTED};")
        info.addWidget(meta_label)

        chips = QHBoxLayout()
        chips.setSpacing(6)
        state_kind = "yellow" if needs_fix else "green"
        state_text = i18n.tr("status_needs_fix") if needs_fix else i18n.tr("status_installed")
        chips.addWidget(Badge(state_text, state_kind))
        game_key = "installed_game_" + (manifest.game_mode if manifest.game_mode in ("global", "jp") else "custom")
        chips.addWidget(Badge(i18n.tr(game_key), "muted"))
        if manifest.source == "browse":
            chips.addWidget(Badge("FEED", "cyan"))
        chips.addStretch(1)
        info.addLayout(chips)
        layout.addLayout(info, 1)

        actions = QHBoxLayout()
        actions.setSpacing(7)
        self.fix_btn = FxButton(i18n.tr("btn_fix"), self, variant="secondary", height=34, icon_name="wrench")
        self.fix_btn.setFixedWidth(86)
        self.fix_btn.clicked.connect(lambda: self.fix_requested.emit(self.manifest))
        actions.addWidget(self.fix_btn)

        self.uninstall_btn = FxButton(
            i18n.tr("btn_uninstall"), self, variant="ghost", height=34, icon_name="trash"
        )
        self.uninstall_btn.setMinimumWidth(116)
        self.uninstall_btn.clicked.connect(lambda: self.uninstall_requested.emit(self.manifest))
        actions.addWidget(self.uninstall_btn)

        self.purge_btn = IconButton(
            "alert",
            self,
            size=34,
            icon_size=15,
            tooltip=i18n.tr("btn_purge"),
            danger=True,
        )
        self.purge_btn.clicked.connect(lambda: self.purge_requested.emit(self.manifest))
        actions.addWidget(self.purge_btn)

        layout.addLayout(actions, 0)
        self.setToolTip(reason)

    def _on_hover(self, value) -> None:
        try:
            self._hover = float(value)
        except Exception:
            self._hover = 0.0
        self.update()

    def enterEvent(self, event) -> None:  # noqa: N802
        if _common.ANIMATIONS:
            self._anim.stop()
            self._anim.setStartValue(self._hover)
            self._anim.setEndValue(1.0)
            self._anim.start()
        else:
            self._hover = 1.0
            self.update()
        super().enterEvent(event)

    def leaveEvent(self, event) -> None:  # noqa: N802
        if _common.ANIMATIONS:
            self._anim.stop()
            self._anim.setStartValue(self._hover)
            self._anim.setEndValue(0.0)
            self._anim.start()
        else:
            self._hover = 0.0
            self.update()
        super().leaveEvent(event)

    def set_busy(self, busy: bool) -> None:
        self._busy = busy
        for button in (self.fix_btn, self.uninstall_btn, self.purge_btn):
            button.setEnabled(not busy)
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        rect = QRectF(self.rect()).adjusted(0.6, 0.6, -0.6, -0.6)
        if self.needs_fix:
            border = _mix(_alpha(YELLOW, 150), _alpha(YELLOW, 230), self._hover)
        else:
            border = _mix(BORDER, BORDER_HI, self._hover)
        painter.setPen(QPen(border, 1.2 if self.needs_fix else 1.0))
        painter.setBrush(QBrush(_mix(SURFACE, SURFACE_2, self._hover * 0.6)))
        painter.drawRoundedRect(rect, 13, 13)
        painter.setPen(Qt.PenStyle.NoPen)
        painter.setBrush(QBrush(_alpha(YELLOW if self.needs_fix else GREEN, 190)))
        painter.drawRoundedRect(QRectF(rect.left(), rect.top() + 16, 3, rect.height() - 32), 1.5, 1.5)
        painter.end()
