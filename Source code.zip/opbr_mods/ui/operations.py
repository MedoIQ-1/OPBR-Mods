"""High-level operations shared by Browse, Installed and Manual pages."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import QFileDialog, QWidget

from .. import i18n
from ..config import human_size
from ..feed import FeedMod, download_file, fetch_feed
from ..install import (
    Analysis,
    Manifest,
    VerifyResult,
    cleanup_analysis,
    install_analysis,
    owned_targets,
    prepare_archive,
    restore_analysis,
    shared_with,
    uninstall_manifest,
)
from ..util import CancelledError, ModError, safe_name
from .common import AlertDialog, ConfirmDialog
from .page_base import ensure_game_assets, ensure_game_closed, run_operation
from .theme import MUTED, TEXT_DIM


def _temp_download_path(window, filename: str) -> Path:
    folder = window.ctx.config.ensure_temp() / "downloads"
    folder.mkdir(parents=True, exist_ok=True)
    return folder / (safe_name(filename or "mod") + ("" if filename.lower().endswith(".zip") else ".zip"))


def _is_temp_file(window, path: Path) -> bool:
    try:
        path.resolve().relative_to(window.ctx.config.temp_root.resolve())
        return True
    except Exception:
        return False


def _cleanup_zip(window, path: Path | None) -> None:
    if path is None:
        return
    if window.ctx.config.auto_clear_temp and _is_temp_file(window, path):
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass


def _flush_temp(window) -> None:
    """Auto-clear the whole session temp folder after a successful install."""
    if not window.ctx.config.auto_clear_temp:
        return
    config = window.ctx.config
    try:
        config.clear_temp()
    except Exception:
        pass


def basic_install_confirm(
    window, mod: FeedMod, existing: Manifest | None
) -> bool:
    is_update = False
    if existing is not None and mod.updated_at and existing.feed_updated_at:
        from ..util import parse_iso

        old = parse_iso(existing.feed_updated_at)
        if old and mod.updated_at > old:
            is_update = True
    if is_update:
        title = i18n.tr("dlg_update_title", name=mod.display_title)
        message = i18n.tr("dlg_update_body")
    elif existing is not None:
        title = i18n.tr("dlg_install_title", name=mod.display_title)
        message = i18n.tr("dlg_install_body") + "\n\n" + i18n.tr("dlg_install_reinstall")
    else:
        title = i18n.tr("dlg_install_title", name=mod.display_title)
        message = i18n.tr("dlg_install_body")
    assets = window.ctx.assets_root()
    extra = i18n.tr("dlg_install_files", n="?", size=mod.size_text)
    if assets:
        extra += f"\n{assets}"
    return ConfirmDialog.ask(
        window,
        title,
        message,
        i18n.tr("btn_install") if not is_update else i18n.tr("btn_update"),
        i18n.tr("btn_cancel"),
        kind="info",
        extra=extra,
    )


def install_feed_mod(window, mod: FeedMod) -> None:
    ctx = window.ctx
    if not ensure_game_assets(window) or not ensure_game_closed(window):
        return
    existing = ctx.manifest_for_feed(mod)
    if not basic_install_confirm(window, mod, existing):
        return
    assets = ctx.assets_root()
    assert assets is not None

    def job(progress, cancel):
        work = ctx.config.ensure_temp()
        zip_path = _temp_download_path(window, mod.zip_name or f"{mod.id}.zip")
        fresh = mod
        try:
            feed = fetch_feed(ctx.config)
            for item in feed.mods:
                if item.id == mod.id:
                    fresh = item
                    break
        except Exception:
            pass
        download_file(
            fresh.download_url,
            zip_path,
            progress,
            cancel,
            fresh.zip_proxy_url if fresh.zip_proxy_url != fresh.download_url else "",
        )
        progress(None, "stage_extract")
        analysis = prepare_archive(
            zip_path,
            assets,
            work,
            conflicts=owned_targets(ctx.config.mods_dir),
            progress=progress,
            cancel=cancel,
        )
        analysis.feed_mod = fresh  # type: ignore[attr-defined]
        return analysis

    def prepared(analysis: Analysis) -> None:
        fresh = getattr(analysis, "feed_mod", mod)
        if analysis.conflicts:
            owners = sorted({owner for _target, owner in analysis.conflicts})
            text = i18n.tr(
                "dlg_install_conflict",
                n=len(analysis.conflicts),
                mods=", ".join(owners),
            )
            if not ConfirmDialog.ask(
                window,
                i18n.tr("common_warning"),
                text,
                i18n.tr("dlg_continue_anyway"),
                i18n.tr("btn_cancel"),
                kind="warning",
                extra=i18n.tr("dlg_install_reinstall"),
            ):
                cleanup_analysis(analysis)
                _cleanup_zip(window, analysis.zip_path)
                return
        _install_prepared(window, analysis, fresh, existing)

    def failed(message: str) -> None:
        AlertDialog.show_error(window, i18n.tr("dlg_error_title"), message)

    run_operation(
        window,
        i18n.tr("status_downloading"),
        job,
        on_done=prepared,
        on_error=failed,
    )


def _install_prepared(
    window,
    analysis: Analysis,
    mod: FeedMod,
    existing: Manifest | None,
) -> None:
    ctx = window.ctx
    assets = analysis.assets_root

    def job(progress, cancel):
        return install_analysis(
            analysis,
            ctx.config.mods_dir,
            ctx.config.changelog_path,
            title=mod.display_title,
            character=mod.character,
            author=mod.author,
            description=mod.description,
            notes=mod.notes,
            gameplay_url=mod.gameplay_url,
            message_url=mod.message_url,
            feed_id=mod.id,
            feed_updated_at=mod.updated_at.isoformat() if mod.updated_at else "",
            source="browse",
            source_zip="",
            game_mode=ctx.config.game_mode,
            existing=existing,
            auto_clear=ctx.config.auto_clear_temp,
            progress=progress,
            cancel=cancel,
        )

    def done(manifest: Manifest) -> None:
        ctx.reload_installed()
        ctx.verification[manifest.id] = VerifyResult(manifest.id, [], len(manifest.files))
        _cleanup_zip(window, analysis.zip_path)
        window.notify_library_changed()
        if analysis.missing:
            window.toast(
                i18n.tr(
                    "toast_installed_skipped",
                    name=manifest.title,
                    n=len(analysis.missing),
                ),
                "warning",
            )
        else:
            window.toast(i18n.tr("toast_installed", name=manifest.title))

    def failed(message: str) -> None:
        AlertDialog.show_error(window, i18n.tr("dlg_error_title"), message)

    run_operation(
        window,
        i18n.tr("status_installing"),
        job,
        on_done=done,
        on_error=failed,
    )


def uninstall_flow(window, manifest: Manifest, force: bool = False) -> None:
    ctx = window.ctx
    if not force and not ensure_game_closed(window):
        return
    shared = shared_with(manifest, ctx.installed)
    if force:
        title = i18n.tr("dlg_purge_title", name=manifest.title)
        message = i18n.tr("dlg_purge_body")
        extra = i18n.tr("dlg_purge_warning")
        if shared:
            extra += "\n" + i18n.tr("dlg_conflict_owned", name=manifest.title, mods=", ".join(shared))
        ok = ConfirmDialog.ask(
            window,
            title,
            message,
            i18n.tr("btn_purge"),
            i18n.tr("btn_cancel"),
            kind="danger",
            danger=True,
            extra=extra,
        )
    else:
        title = i18n.tr("dlg_uninstall_title", name=manifest.title)
        message = i18n.tr(
            "dlg_uninstall_body", n=len(manifest.files)
        )
        extra = i18n.tr("dlg_uninstall_warning")
        if shared:
            extra += "\n" + i18n.tr(
                "dlg_conflict_owned", name=manifest.title, mods=", ".join(shared)
            )
        ok = ConfirmDialog.ask(
            window,
            title,
            message,
            i18n.tr("btn_uninstall"),
            i18n.tr("btn_cancel"),
            kind="warning",
            danger=True,
            extra=extra,
        )
    if not ok:
        return

    def job(progress, cancel):
        return uninstall_manifest(
            manifest,
            ctx.config.mods_dir,
            ctx.config.changelog_path,
            force=force,
            progress=progress,
            cancel=cancel,
        )

    def done(deleted: int) -> None:
        ctx.reload_installed()
        ctx.verification.pop(manifest.id, None)
        window.notify_library_changed()
        window.toast(i18n.tr("toast_uninstalled", name=manifest.title))

    def failed(message: str) -> None:
        if force:
            # Even if some files were locked, try to remove the record.
            try:
                uninstall_manifest(
                    manifest,
                    ctx.config.mods_dir,
                    ctx.config.changelog_path,
                    force=True,
                )
            except Exception:
                pass
            ctx.reload_installed()
            window.notify_library_changed()
        AlertDialog.show_error(window, i18n.tr("dlg_error_title"), message)

    run_operation(
        window,
        i18n.tr("status_uninstalling"),
        job,
        on_done=done,
        on_error=failed,
    )


def repair_flow(window, manifest: Manifest, feed_mod: FeedMod | None = None) -> None:
    ctx = window.ctx
    if not ensure_game_assets(window) or not ensure_game_closed(window):
        return

    if feed_mod is None and ctx.feed is not None and manifest.feed_id:
        for item in ctx.feed.mods:
            if item.id == manifest.feed_id:
                feed_mod = item
                break

    source = Path(manifest.source_zip) if manifest.source_zip else None
    needs_picker = feed_mod is None and not (source and source.is_file())
    if needs_picker:
        AlertDialog(
            window,
            i18n.tr("dlg_fix_title", name=manifest.title),
            i18n.tr("dlg_no_feed_fix"),
            kind="info",
        ).exec()
        chosen, _ = QFileDialog.getOpenFileName(
            window,
            i18n.tr("dlg_locate_zip"),
            str(Path.home()),
            "Mod archives (*.zip)",
        )
        if not chosen:
            return
        source = Path(chosen)

    if not ConfirmDialog.ask(
        window,
        i18n.tr("dlg_fix_title", name=manifest.title),
        i18n.tr("dlg_fix_body"),
        i18n.tr("btn_fix"),
        i18n.tr("btn_cancel"),
        kind="warning",
        extra=ctx.reason_text(ctx.issues_for(manifest)),
    ):
        return

    assets = ctx.assets_root()
    assert assets is not None

    def job(progress, cancel):
        work = ctx.config.ensure_temp()
        zip_path: Path | None = None
        downloaded = False
        fresh = feed_mod
        if fresh is None and manifest.feed_id:
            try:
                feed = fetch_feed(ctx.config)
                for item in feed.mods:
                    if item.id == manifest.feed_id:
                        fresh = item
                        break
            except Exception:
                fresh = None
        if fresh is not None:
            target = _temp_download_path(window, fresh.zip_name or f"{fresh.id}.zip")
            try:
                download_file(
                    fresh.download_url,
                    target,
                    progress,
                    cancel,
                    fresh.zip_proxy_url if fresh.zip_proxy_url != fresh.download_url else "",
                )
                zip_path = target
                downloaded = True
            except CancelledError:
                raise
            except Exception:
                zip_path = None
        if zip_path is None and source is not None and source.is_file():
            zip_path = source
        if zip_path is None:
            raise ModError(i18n.tr("dlg_zip_missing"))

        progress(None, "stage_extract")
        analysis = prepare_archive(
            zip_path,
            assets,
            work,
            conflicts=owned_targets(ctx.config.mods_dir),
            progress=progress,
            cancel=cancel,
        )
        manifest_out = install_analysis(
            analysis,
            ctx.config.mods_dir,
            ctx.config.changelog_path,
            title=manifest.title,
            character=manifest.character,
            author=manifest.author,
            description=manifest.description,
            notes=manifest.notes,
            gameplay_url=manifest.gameplay_url,
            message_url=manifest.message_url,
            feed_id=manifest.feed_id,
            feed_updated_at=(fresh.updated_at.isoformat() if fresh and fresh.updated_at else manifest.feed_updated_at),
            source=manifest.source,
            source_zip=manifest.source_zip if zip_path == source else "",
            game_mode=ctx.config.game_mode,
            existing=manifest,
            auto_clear=ctx.config.auto_clear_temp,
            progress=progress,
            cancel=cancel,
        )
        if downloaded and ctx.config.auto_clear_temp:
            try:
                zip_path.unlink(missing_ok=True)
            except OSError:
                pass
        return manifest_out

    def done(updated: Manifest) -> None:
        ctx.reload_installed()
        ctx.verification[updated.id] = VerifyResult(updated.id, [], len(updated.files))
        window.notify_library_changed()
        window.toast(i18n.tr("toast_fixed", name=updated.title))

    def failed(message: str) -> None:
        AlertDialog.show_error(window, i18n.tr("dlg_error_title"), message)

    run_operation(
        window,
        i18n.tr("btn_fix"),
        job,
        on_done=done,
        on_error=failed,
    )


def manual_install_flow(window, analysis: Analysis, title: str, original_mode_label: str = "") -> None:
    ctx = window.ctx
    if not ensure_game_closed(window):
        cleanup_analysis(analysis)
        return
    assets = analysis.assets_root

    if analysis.original_mode:
        if not ConfirmDialog.ask(
            window,
            i18n.tr("btn_restore"),
            i18n.tr("dlg_install_restore"),
            i18n.tr("btn_restore"),
            i18n.tr("btn_cancel"),
            kind="warning",
            extra=i18n.tr("dlg_restore_body", n=len(analysis.items)),
        ):
            cleanup_analysis(analysis)
            return

        def restore_job(progress, cancel):
            return restore_analysis(
                analysis,
                ctx.config.mods_dir,
                ctx.config.changelog_path,
                auto_clear=ctx.config.auto_clear_temp,
                progress=progress,
                cancel=cancel,
            )

        def restored(count: int) -> None:
            ctx.reload_installed()
            window.notify_library_changed()
            window.toast(i18n.tr("toast_restored"))

        def restore_failed(message: str) -> None:
            AlertDialog.show_error(window, i18n.tr("dlg_error_title"), message)

        run_operation(
            window,
            i18n.tr("btn_restore"),
            restore_job,
            on_done=restored,
            on_error=restore_failed,
        )
        return

    # normal manual install. A manual archive has no stable identity, so it must
    # never adopt another mod's manifest: overwriting shared files would make
    # uninstalling it delete the other mod's files too. Instead we only warn.
    existing = None
    if analysis.conflicts:
        owners = sorted({owner for _target, owner in analysis.conflicts})
        if not ConfirmDialog.ask(
            window,
            i18n.tr("common_warning"),
            i18n.tr(
                "dlg_install_conflict",
                n=len(analysis.conflicts),
                mods=", ".join(owners),
            ),
            i18n.tr("dlg_continue_anyway"),
            i18n.tr("btn_cancel"),
            kind="warning",
        ):
            cleanup_analysis(analysis)
            return
    if not ConfirmDialog.ask(
        window,
        i18n.tr("dlg_install_title", name=title or analysis.title_guess),
        i18n.tr("dlg_install_body"),
        i18n.tr("btn_install"),
        i18n.tr("btn_cancel"),
        kind="info",
        extra=(
            i18n.tr(
                "dlg_install_files",
                n=len(analysis.items),
                size=human_size(analysis.total_size),
            )
            + f"\n{assets}"
        ),
    ):
        cleanup_analysis(analysis)
        return

    def job(progress, cancel):
        return install_analysis(
            analysis,
            ctx.config.mods_dir,
            ctx.config.changelog_path,
            title=title or analysis.title_guess,
            source="manual",
            source_zip=str(analysis.zip_path),
            game_mode=ctx.config.game_mode,
            existing=existing,
            auto_clear=ctx.config.auto_clear_temp,
            progress=progress,
            cancel=cancel,
        )

    def done(manifest: Manifest) -> None:
        ctx.reload_installed()
        ctx.verification[manifest.id] = VerifyResult(manifest.id, [], len(manifest.files))
        window.notify_library_changed()
        if analysis.missing:
            window.toast(
                i18n.tr(
                    "toast_installed_skipped",
                    name=manifest.title,
                    n=len(analysis.missing),
                ),
                "warning",
            )
        else:
            window.toast(i18n.tr("toast_installed", name=manifest.title))

    def failed(message: str) -> None:
        AlertDialog.show_error(window, i18n.tr("dlg_error_title"), message)

    run_operation(
        window,
        i18n.tr("status_installing"),
        job,
        on_done=done,
        on_error=failed,
    )
