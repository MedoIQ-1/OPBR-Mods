"""Steam helpers."""

from __future__ import annotations

import os
import re
from pathlib import Path

from .constants import STEAM_APP_ID


def launch_game(app_id: str | None = None) -> None:
    app = str(app_id or STEAM_APP_ID).strip()
    if not re.fullmatch(r"\d{3,12}", app):
        raise ValueError("Invalid Steam App ID")
    os.startfile(f"steam://rungameid/{app}")  # type: ignore[attr-defined]


def steam_install_path() -> Path | None:
    """Try to locate Steam through the registry (optional, best effort)."""
    try:
        import winreg

        for hive, key in (
            (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam"),
        ):
            try:
                with winreg.OpenKey(hive, key) as handle:
                    value, _ = winreg.QueryValueEx(handle, "SteamExe")
                    path = Path(str(value))
                    if path.is_file():
                        return path
            except OSError:
                continue
    except Exception:
        pass
    return None
