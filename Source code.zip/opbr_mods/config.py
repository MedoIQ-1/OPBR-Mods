"""Persistent configuration and user-data locations."""

from __future__ import annotations

import ctypes
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any

from .constants import (
    APP_VERSION,
    FEED_URL,
    GLOBAL_GAME_DIR,
    JP_GAME_DIR,
    LANGUAGES,
    STEAM_APP_ID,
)

APP_DIR_NAME = "OPBRModsInstaller"


def _roaming_appdata() -> Path:
    base = os.environ.get("APPDATA")
    if base:
        return Path(base)
    return Path.home() / "AppData" / "Roaming"


def default_language() -> str:
    """Best-effort Windows UI language detection (no Qt needed)."""
    try:
        langid = ctypes.windll.kernel32.GetUserDefaultUILanguage()
        primary = langid & 0x3FF
        mapping = {
            0x01: "ar",
            0x0A: "es",
            0x0C: "fr",
            0x11: "ja",
            0x1E: "th",
        }
        if primary in mapping:
            return mapping[primary]
    except Exception:
        pass
    try:
        import locale

        code = (locale.getlocale()[0] or locale.getdefaultlocale()[0] or "en").lower()
        for lang in LANGUAGES:
            if code.startswith(lang):
                return lang
    except Exception:
        pass
    return "en"


def detect_system_language() -> str:
    return default_language()


class Config:
    """Small JSON-backed settings store with atomic writes."""

    def __init__(self) -> None:
        self.root = _roaming_appdata() / "MedoIQ" / APP_DIR_NAME
        self.root.mkdir(parents=True, exist_ok=True)
        self.mods_dir = self.root / "mods"
        self.mods_dir.mkdir(parents=True, exist_ok=True)
        self.backup_dir = self.root / "backups"
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        self.logs_dir = self.root / "logs"
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        self.cache_dir = self.root / "cache"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.thumbs_dir = self.cache_dir / "thumbs"
        self.thumbs_dir.mkdir(parents=True, exist_ok=True)
        self.feed_cache = self.cache_dir / "feed.json"
        self.path = self.root / "config.json"
        self.changelog_path = self.logs_dir / "changelog.jsonl"
        self.app_log_path = self.logs_dir / "app.log"
        self.temp_root = Path(tempfile.gettempdir()) / APP_DIR_NAME

        self.data: dict[str, Any] = {
            "schema": 1,
            "version": APP_VERSION,
            "language": "en",
            "language_chosen": False,
            "first_run": True,
            "game_mode": "global",
            "custom_assets": "",
            "detected": {},
            "auto_clear_temp": True,
            "animations": True,
            "steam_app_id": STEAM_APP_ID,
            "feed_url": FEED_URL,
            "window": {"w": 1320, "h": 860},
            "auto_refresh_minutes": 15,
        }
        self.load()
        self.prime_default_detection()

    # ------------------------------------------------------------------ io
    def load(self) -> None:
        try:
            if self.path.exists():
                raw = json.loads(self.path.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    for key, value in raw.items():
                        self.data[key] = value
        except Exception:
            # A broken config should never stop the app from opening.
            pass
        if self.data.get("language") not in LANGUAGES:
            self.data["language"] = "en"

    def save(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(
                json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            os.replace(tmp, self.path)
        except Exception:
            pass

    # ------------------------------------------------------------- accessors
    def get(self, key: str, default: Any = None) -> Any:
        return self.data.get(key, default)

    def set(self, key: str, value: Any, save: bool = True) -> None:
        self.data[key] = value
        if save:
            self.save()

    @property
    def language(self) -> str:
        lang = self.data.get("language", "en")
        return lang if lang in LANGUAGES else "en"

    @language.setter
    def language(self, value: str) -> None:
        self.set("language", value if value in LANGUAGES else "en")

    @property
    def animations(self) -> bool:
        return bool(self.data.get("animations", True))

    @property
    def auto_clear_temp(self) -> bool:
        return bool(self.data.get("auto_clear_temp", True))

    @property
    def steam_app_id(self) -> str:
        value = str(self.data.get("steam_app_id") or STEAM_APP_ID).strip()
        return value or STEAM_APP_ID

    @property
    def feed_url(self) -> str:
        return str(self.data.get("feed_url") or FEED_URL)

    # ------------------------------------------------------------ game paths
    def detected(self) -> dict[str, str]:
        value = self.data.get("detected")
        return value if isinstance(value, dict) else {}

    def set_detected(self, results: dict[str, str]) -> None:
        merged = dict(self.detected())
        merged.update({k: str(v) for k, v in results.items() if v})
        self.set("detected", merged)

    @property
    def game_mode(self) -> str:
        mode = self.data.get("game_mode", "global")
        return mode if mode in ("global", "jp", "custom") else "global"

    def known_assets_path(self, mode: str | None = None) -> Path | None:
        mode = mode or self.game_mode
        if mode == "custom":
            raw = str(self.data.get("custom_assets") or "").strip()
            if raw:
                path = Path(raw)
                if path.is_dir():
                    return path
            return None
        detected = self.detected().get(mode)
        if detected and Path(detected).is_dir():
            return Path(detected)
        return None

    def assets_root(self) -> Path | None:
        """Currently selected assets folder, if it is usable."""
        path = self.known_assets_path()
        if path and path.is_dir():
            return path
        return None

    def game_label(self, mode: str | None = None) -> str:
        mode = mode or self.game_mode
        return {"global": "Global", "jp": "Japanese", "custom": "Custom"}.get(
            mode, "Global"
        )

    def default_assets_for_mode(self, mode: str) -> Path:
        game = GLOBAL_GAME_DIR if mode == "global" else JP_GAME_DIR
        local_low = Path(os.environ.get("USERPROFILE", str(Path.home()))) / "AppData" / "LocalLow"
        return local_low / "Bandai Namco Entertainment Inc_" / game / "StreamingAssets" / "assets"

    def prime_default_detection(self) -> dict[str, str]:
        """Remember the standard LocalLow folders that already exist.

        This makes the app usable on first launch without pressing "Detect" in
        Settings. Existing user choices are never overwritten: a path is only
        filled in when it has not been detected yet, and the selected mode is
        switched only when the current one is unavailable.
        """
        found: dict[str, str] = {}
        for mode in ("global", "jp"):
            try:
                path = self.default_assets_for_mode(mode)
                if path.is_dir():
                    found[mode] = str(path)
            except OSError:
                continue
        if not found:
            return found

        merged = dict(self.detected())
        changed = False
        for mode, value in found.items():
            if not merged.get(mode):
                merged[mode] = value
                changed = True
        if changed:
            self.set("detected", merged)

        mode = self.game_mode
        if mode in ("global", "jp") and not self.known_assets_path(mode):
            fallback = "global" if "global" in found else "jp"
            self.set("game_mode", fallback)
        return found

    # ------------------------------------------------------------------ temp
    def ensure_temp(self) -> Path:
        self.temp_root.mkdir(parents=True, exist_ok=True)
        return self.temp_root

    def temp_size(self) -> int:
        return _dir_size(self.temp_root)

    def cache_size(self) -> int:
        return _dir_size(self.thumbs_dir)

    def clear_temp(self) -> None:
        _clear_dir(self.temp_root)
        self.temp_root.mkdir(parents=True, exist_ok=True)

    def clear_thumb_cache(self) -> None:
        _clear_dir(self.thumbs_dir)
        self.thumbs_dir.mkdir(parents=True, exist_ok=True)

    # --------------------------------------------------------------- helpers
    def window_size(self) -> tuple[int, int]:
        win = self.data.get("window") or {}
        try:
            w = int(win.get("w", 1320))
            h = int(win.get("h", 860))
        except Exception:
            w, h = 1320, 860
        return max(1100, w), max(720, h)

    def set_window_size(self, w: int, h: int) -> None:
        self.set("window", {"w": int(w), "h": int(h)})


def _dir_size(root: Path) -> int:
    total = 0
    if not root.exists():
        return 0
    try:
        for item in root.rglob("*"):
            try:
                if item.is_file():
                    total += item.stat().st_size
            except OSError:
                continue
    except OSError:
        pass
    return total


def _clear_dir(root: Path) -> None:
    import shutil

    if not root.exists():
        return
    try:
        for item in root.iterdir():
            try:
                if item.is_dir():
                    shutil.rmtree(item, ignore_errors=True)
                else:
                    item.unlink(missing_ok=True)
            except OSError:
                continue
    except OSError:
        pass


def human_size(size: int | float) -> str:
    try:
        size = float(size)
    except Exception:
        return "0 B"
    units = ["B", "KB", "MB", "GB", "TB"]
    idx = 0
    while size >= 1024 and idx < len(units) - 1:
        size /= 1024.0
        idx += 1
    if idx == 0:
        return f"{int(size)} B"
    if size >= 100:
        return f"{size:.0f} {units[idx]}"
    if size >= 10:
        return f"{size:.1f} {units[idx]}"
    return f"{size:.2f} {units[idx]}"


def app_base_dir() -> Path:
    """Folder containing the exe (or the source checkout in dev mode)."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def resource_path(*parts: str) -> Path:
    base = Path(getattr(sys, "_MEIPASS", app_base_dir()))
    return base.joinpath(*parts)
