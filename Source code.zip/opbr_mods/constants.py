"""Application-wide constants."""

APP_NAME = "OPBR Skin Mods Installer"
APP_SHORT = "OPBR MODS"
APP_VERSION = "1.0.0"
AUTHOR = "MedoIQ"
DISCORD_NAME = "@medoiq"
DISCORD_INVITE = "https://discord.gg/s42FR9pabQ"

# Donations (Binance Pay). The QR poster is bundled as assets/binance_qr.png.
BINANCE_ID = "1273526111"
BINANCE_PAY_NAME = "MedoIQ-OPBR"

FEED_URL = "https://riot232294.ai.studio/api/skin-mods/feed.json"

STEAM_APP_ID = "2918150"

BANDAl_DIR = "Bandai Namco Entertainment Inc_"
GLOBAL_GAME_DIR = "ONE PIECE BountyRush"
JP_GAME_DIR = "ONE PIECE BountyRush JP"

GAME_MODES = ("global", "jp", "custom")

ASSET_EXTENSIONS = {
    ".unity3d",
    ".bundle",
    ".assets",
    ".ress",
    ".resource",
    ".resS",
    ".ab",
    ".bytes",
    ".dat",
}

PREVIEW_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp", ".bmp"}
PREVIEW_NAMES = ("preview", "thumbnail", "thumb", "preview_image", "cover")

USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36 OPBRModsInstaller/1.0"
)

# Languages shown in the app. Auto-detection maps system locales onto these.
LANGUAGES = ("en", "ja", "es", "fr", "th", "ar")

LANGUAGE_NAMES = {
    "en": "English",
    "ja": "日本語",
    "es": "Español",
    "fr": "Français",
    "th": "ไทย",
    "ar": "العربية",
}

LANGUAGE_FLAGS = {
    "en": "EN",
    "ja": "JP",
    "es": "ES",
    "fr": "FR",
    "th": "TH",
    "ar": "AR",
}
