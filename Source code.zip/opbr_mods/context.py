"""Shared runtime state for pages."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path

from .config import Config
from .feed import FeedData, FeedMod
from .install import Manifest, VerifyResult, load_manifests
from .ui.images import ImageService
from .util import parse_iso


class AppContext:
    def __init__(self, config: Config) -> None:
        self.config = config
        self.images = ImageService(config)
        self.installed: dict[str, Manifest] = {}
        self.verification: dict[str, VerifyResult] = {}
        self.feed: FeedData | None = None
        self.feed_loaded_at: datetime | None = None
        self.reload_installed()

    def reload_installed(self) -> None:
        self.installed = load_manifests(self.config.mods_dir)
        for key in list(self.verification.keys()):
            if key not in self.installed:
                self.verification.pop(key, None)

    def assets_root(self) -> Path | None:
        return self.config.assets_root()

    def manifest_for_feed(self, feed_mod: FeedMod) -> Manifest | None:
        for manifest in self.installed.values():
            if manifest.id == feed_mod.id or manifest.feed_id == feed_mod.id:
                return manifest
        return None

    def issues_for(self, manifest: Manifest | None) -> list:
        if manifest is None:
            return []
        result = self.verification.get(manifest.id)
        return list(result.issues) if result else []

    def state_for_feed(self, mod: FeedMod) -> tuple[str, Manifest | None, str]:
        manifest = self.manifest_for_feed(mod)
        if manifest is None:
            return "not_installed", None, ""
        issues = self.issues_for(manifest)
        if issues:
            return "needs_fix", manifest, self.reason_text(issues)
        if mod.updated_at and manifest.feed_updated_at:
            try:
                feed_dt = mod.updated_at
                installed_dt = parse_iso(manifest.feed_updated_at)
                if installed_dt and feed_dt > installed_dt:
                    return "update", manifest, ""
            except Exception:
                pass
        return "installed", manifest, ""

    @staticmethod
    def reason_text(issues: list) -> str:
        from . import i18n

        names = []
        for issue in issues:
            key = "reason_" + issue.reason
            text = i18n.tr(key)
            rel = Path(issue.rel).name if issue.rel else ""
            entry = f"{text}: {rel}" if rel else text
            if entry not in names:
                names.append(entry)
        if len(names) > 4:
            names = names[:4] + [f"+{len(names) - 4}"]
        return " · ".join(names)
