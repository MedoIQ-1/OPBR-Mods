"""Locating the game's StreamingAssets folder, even on other drives."""

from __future__ import annotations

import os
import string
from pathlib import Path
from typing import Callable, Iterable

from .constants import BANDAl_DIR, GLOBAL_GAME_DIR, JP_GAME_DIR

GAME_FOLDERS = {"global": GLOBAL_GAME_DIR, "jp": JP_GAME_DIR}


def _local_low(profile: Path) -> Path:
    return profile / "AppData" / "LocalLow"


def _profile_candidates() -> list[Path]:
    profiles: list[Path] = []
    seen: set[str] = set()

    def add(path: Path | None) -> None:
        if not path:
            return
        try:
            key = str(path.resolve()).lower()
        except OSError:
            key = str(path).lower()
        if key not in seen and path.is_dir():
            seen.add(key)
            profiles.append(path)

    add(Path(os.environ.get("USERPROFILE", str(Path.home()))))
    local_appdata = os.environ.get("LOCALAPPDATA")
    if local_appdata:
        # C:\Users\<name>\AppData\Local -> C:\Users\<name>
        try:
            add(Path(local_appdata).parent.parent)
        except Exception:
            pass

    for letter in string.ascii_uppercase:
        drive = Path(f"{letter}:\\")
        try:
            if not drive.exists():
                continue
        except OSError:
            continue
        users = drive / "Users"
        if not users.is_dir():
            continue
        try:
            for entry in users.iterdir():
                try:
                    if entry.is_dir() and entry.name.lower() not in ("public", "default", "default user", "all users"):
                        add(entry)
                except OSError:
                    continue
        except OSError:
            continue
    return profiles


def _assets_for(profile: Path, game_dir: str) -> Path:
    return (
        _local_low(profile)
        / BANDAl_DIR
        / game_dir
        / "StreamingAssets"
        / "assets"
    )


def detect_games(
    progress: Callable[[str], None] | None = None,
) -> dict[str, str]:
    """Return {"global": path, "jp": path} for every version found."""
    found: dict[str, str] = {}
    profiles = _profile_candidates()
    for idx, profile in enumerate(profiles):
        if progress:
            try:
                progress(profile.name)
            except Exception:
                pass
        for mode, folder in GAME_FOLDERS.items():
            if mode in found:
                continue
            candidate = _assets_for(profile, folder)
            try:
                if candidate.is_dir():
                    # Prefer a folder that actually contains assets, but accept
                    # a fresh install where the game has not downloaded yet.
                    found[mode] = str(candidate)
            except OSError:
                continue
        if len(found) == len(GAME_FOLDERS):
            break

    # Also honour the current environment directly (fast path).
    if "global" not in found or "jp" not in found:
        profile = Path(os.environ.get("USERPROFILE", str(Path.home())))
        for mode, folder in GAME_FOLDERS.items():
            if mode not in found:
                candidate = _assets_for(profile, folder)
                if candidate.is_dir():
                    found[mode] = str(candidate)
    return found


def default_assets_for(mode: str) -> Path:
    profile = Path(os.environ.get("USERPROFILE", str(Path.home())))
    folder = GAME_FOLDERS.get(mode, GLOBAL_GAME_DIR)
    return _assets_for(profile, folder)


def normalize_assets_path(raw: str | Path) -> Path | None:
    """Accept a game folder, StreamingAssets folder or assets folder."""
    if not raw:
        return None
    path = Path(str(raw).strip().strip('"'))
    if not path.exists() or not path.is_dir():
        return None

    candidates: list[Path] = [path]
    name = path.name.lower()
    if name == "streamingassets":
        candidates.insert(0, path / "assets")
    if name in ("one piece bounty rush", "one piece bounty rush jp"):
        candidates.insert(0, path / "StreamingAssets" / "assets")
    if name in (BANDAl_DIR.lower(), BANDAl_DIR.rstrip("_").lower()):
        for folder in GAME_FOLDERS.values():
            candidates.insert(0, path / folder / "StreamingAssets" / "assets")
    candidates += [
        path / "assets",
        path / "StreamingAssets" / "assets",
        path / "ONE PIECE BountyRush" / "StreamingAssets" / "assets",
        path / "ONE PIECE BountyRush JP" / "StreamingAssets" / "assets",
    ]

    for candidate in candidates:
        try:
            if candidate.is_dir() and _looks_like_assets(candidate):
                return candidate
        except OSError:
            continue
    return None


def _looks_like_assets(path: Path) -> bool:
    try:
        if path.name.lower() != "assets":
            return False
        # If it has any subfolder or unity file it's clearly the assets root.
        for entry in path.iterdir():
            if entry.is_dir():
                return True
            if entry.suffix.lower() in (".unity3d", ".bundle", ".assets"):
                return True
    except OSError:
        return False
    # Empty but correctly named folder -> accept.
    return True


def is_valid_assets(path: Path | None) -> bool:
    return bool(path and path.is_dir() and _looks_like_assets(path))


def asset_files(root: Path) -> Iterable[Path]:
    for dirpath, _dirnames, filenames in os.walk(root):
        for name in filenames:
            yield Path(dirpath) / name
