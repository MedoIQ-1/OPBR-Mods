"""Small shared helpers (no Qt imports)."""

from __future__ import annotations

import datetime as _dt
import os
import re
import subprocess
from pathlib import Path
from typing import Callable


class CancelToken:
    def __init__(self) -> None:
        self.cancelled = False

    def cancel(self) -> None:
        self.cancelled = True

    def check(self) -> None:
        if self.cancelled:
            raise CancelledError()


class CancelledError(Exception):
    pass


class ModError(Exception):
    """User-facing error with a readable message."""

    pass


def open_in_explorer(path: Path | str) -> None:
    target = Path(path)
    try:
        if target.is_file():
            subprocess.Popen(["explorer", "/select,", str(target)])
        else:
            os.startfile(str(target))  # type: ignore[attr-defined]
    except Exception:
        try:
            os.startfile(str(target))  # type: ignore[attr-defined]
        except Exception:
            pass


def open_url(url: str) -> bool:
    if not url:
        return False
    try:
        os.startfile(url)  # type: ignore[attr-defined]
        return True
    except Exception:
        return False


def safe_name(value: str, fallback: str = "mod") -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._ -]+", "_", value or "").strip(" ._")
    cleaned = re.sub(r"\s+", "_", cleaned)
    return (cleaned[:80] or fallback)


def parse_iso(value: str | None) -> _dt.datetime | None:
    if not value:
        return None
    text = str(value).strip()
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = _dt.datetime.fromisoformat(text)
    except ValueError:
        try:
            dt = _dt.datetime.fromisoformat(text[:19])
        except ValueError:
            return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=_dt.timezone.utc)
    return dt


def utcnow() -> _dt.datetime:
    return _dt.datetime.now(_dt.timezone.utc)


def time_ago(dt: _dt.datetime | None, tr: Callable[..., str]) -> str:
    if dt is None:
        return tr("common_never")
    now = utcnow()
    try:
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=_dt.timezone.utc)
        delta = now - dt
    except Exception:
        return tr("common_unknown")
    seconds = int(delta.total_seconds())
    if seconds < 60:
        return tr("common_just_now")
    minutes = seconds // 60
    if minutes < 60:
        return tr("common_min_ago", n=minutes)
    hours = minutes // 60
    if hours < 24:
        return tr("common_hour_ago", n=hours)
    days = hours // 24
    if days < 30:
        return tr("common_day_ago", n=days)
    return dt.astimezone().strftime("%Y-%m-%d")


def format_date(dt: _dt.datetime | None) -> str:
    if dt is None:
        return "—"
    try:
        return dt.astimezone().strftime("%Y-%m-%d %H:%M")
    except Exception:
        return "—"


def game_running() -> bool:
    """Best-effort check for the OPBR process."""
    try:
        result = subprocess.run(
            ["tasklist", "/FO", "CSV", "/NH"],
            capture_output=True,
            text=True,
            timeout=6,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
        text = (result.stdout or "").lower()
    except Exception:
        return False
    needles = ("bountyrush", "bounty rush", "onepiece", "opbr")
    for line in text.splitlines():
        name = line.split('","')[0].strip('"').lower()
        if any(n in name for n in needles) and "installer" not in name:
            return True
    return False


def sha256_file(path: Path, cancel: CancelToken | None = None) -> str:
    import hashlib

    h = hashlib.sha256()
    with open(path, "rb") as fh:
        while True:
            if cancel is not None:
                cancel.check()
            chunk = fh.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()
