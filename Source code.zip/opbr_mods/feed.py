"""Community feed fetching, parsing, caching and downloads."""

from __future__ import annotations

import json
import os
import shutil
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Callable

from .config import Config
from .constants import USER_AGENT
from .util import CancelToken, ModError, parse_iso

ProgressFn = Callable[[float | None, str], None]


@dataclass
class FeedMod:
    id: str
    title: str
    mod_name: str = ""
    character: str = ""
    description: str = ""
    author: str = ""
    notes: str = ""
    gameplay_url: str = ""
    message_url: str = ""
    labels: list[str] = field(default_factory=list)
    zip_name: str = ""
    zip_size: int = 0
    zip_size_text: str = ""
    zip_url: str = ""
    zip_proxy_url: str = ""
    preview_url: str = ""
    preview_proxy_url: str = ""
    preview_name: str = ""
    created_at: datetime | None = None
    updated_at: datetime | None = None

    @property
    def display_title(self) -> str:
        return self.title or self.mod_name or self.zip_name or "Unnamed mod"

    @property
    def character_text(self) -> str:
        return self.character or "—"

    @property
    def author_text(self) -> str:
        return self.author or "—"

    @property
    def image_url(self) -> str:
        return self.preview_url or self.preview_proxy_url

    @property
    def download_url(self) -> str:
        return self.zip_url or self.zip_proxy_url

    @property
    def size_text(self) -> str:
        if self.zip_size_text:
            return self.zip_size_text
        from .config import human_size

        return human_size(self.zip_size)


@dataclass
class FeedData:
    mods: list[FeedMod]
    generated_at: datetime | None
    total: int
    offline: bool = False
    error: str = ""


class FeedError(Exception):
    pass


def _pick_image(mod: dict) -> dict:
    images = mod.get("preview_images") or []
    if isinstance(images, dict):
        images = [images]
    usable = []
    for image in images:
        if not isinstance(image, dict):
            continue
        if (image.get("content_type") or "").startswith("image/"):
            usable.append(image)
        elif str(image.get("filename", "")).lower().endswith(
            (".png", ".jpg", ".jpeg", ".webp", ".gif")
        ):
            usable.append(image)
    if not usable:
        for att in mod.get("all_attachments") or []:
            if isinstance(att, dict) and str(att.get("content_type", "")).startswith("image/"):
                usable.append(att)
                break
    return usable[0] if usable else {}


def _parse_mod(raw: dict) -> FeedMod | None:
    if not isinstance(raw, dict):
        return None
    zip_file = raw.get("zip_file") or {}
    if not isinstance(zip_file, dict):
        zip_file = {}
    title = str(raw.get("title") or zip_file.get("title") or "").strip()
    mod_name = str(raw.get("mod_name") or "").strip()
    zip_name = str(zip_file.get("filename") or "").strip()
    if not (title or mod_name or zip_name):
        return None
    image = _pick_image(raw)
    labels = raw.get("labels") or []
    if not isinstance(labels, list):
        labels = []
    mod = FeedMod(
        id=str(raw.get("id") or zip_file.get("id") or zip_name),
        title=title or mod_name or Path(zip_name).stem,
        mod_name=mod_name or title,
        character=str(raw.get("character") or "").strip(),
        description=str(raw.get("description") or "").strip(),
        author=str(raw.get("author_name") or (raw.get("author") or {}).get("global_name", "") or "").strip(),
        notes=str(raw.get("notes") or "").strip(),
        gameplay_url=str(raw.get("gameplay_url") or "").strip(),
        message_url=str(raw.get("message_url") or "").strip(),
        labels=[str(x) for x in labels],
        zip_name=zip_name,
        zip_size=int(zip_file.get("size") or 0),
        zip_size_text=str(zip_file.get("size_formatted") or ""),
        zip_url=str(zip_file.get("url") or "").strip(),
        zip_proxy_url=str(zip_file.get("proxy_url") or "").strip(),
        preview_url=str(image.get("url") or "").strip(),
        preview_proxy_url=str(image.get("proxy_url") or "").strip(),
        preview_name=str(image.get("filename") or "").strip(),
        created_at=parse_iso(raw.get("created_at")),
        updated_at=parse_iso(raw.get("updated_at") or raw.get("edited_at")),
    )
    if not mod.download_url:
        return None
    return mod


def parse_feed(payload: dict) -> FeedData:
    mods_raw = payload.get("mods") or []
    mods: list[FeedMod] = []
    if isinstance(mods_raw, list):
        for raw in mods_raw:
            mod = _parse_mod(raw)
            if mod is not None:
                mods.append(mod)
    mods.sort(
        key=lambda m: (m.created_at.timestamp() if m.created_at else 0, m.id),
        reverse=True,
    )
    total = int(payload.get("total_mods") or len(mods))
    generated = parse_iso(payload.get("generated_at") or payload.get("stats", {}).get("next_hourly_refresh"))
    return FeedData(mods=mods, generated_at=generated, total=total)


def _request(url: str, timeout: float = 25.0) -> urllib.request.Request:
    return urllib.request.Request(
        url,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "application/json,text/plain,*/*",
            "Cache-Control": "no-cache",
        },
    )


def fetch_feed(config: Config, timeout: float = 25.0) -> FeedData:
    url = config.feed_url
    try:
        with urllib.request.urlopen(_request(url, timeout), timeout=timeout) as response:
            data = response.read()
        payload = json.loads(data.decode("utf-8", "replace"))
        if not isinstance(payload, dict):
            raise ValueError("Feed is not a JSON object")
        if payload.get("maintenance") is True:
            raise FeedError("The mod feed is currently under maintenance.")
        feed = parse_feed(payload)
        try:
            tmp = config.feed_cache.with_suffix(".tmp")
            tmp.write_bytes(data)
            os.replace(tmp, config.feed_cache)
        except OSError:
            pass
        return feed
    except Exception as exc:
        cached = load_cached_feed(config)
        if cached is not None:
            cached.offline = True
            cached.error = str(exc)
            return cached
        raise FeedError(str(exc)) from exc


def load_cached_feed(config: Config) -> FeedData | None:
    try:
        if config.feed_cache.exists():
            payload = json.loads(config.feed_cache.read_text(encoding="utf-8", errors="replace"))
            feed = parse_feed(payload)
            feed.offline = True
            return feed
    except Exception:
        return None
    return None


def download_file(
    url: str,
    dest: Path,
    progress: ProgressFn | None = None,
    cancel: CancelToken | None = None,
    fallback_url: str = "",
) -> Path:
    if not url:
        raise ModError("This mod has no download link.")
    dest.parent.mkdir(parents=True, exist_ok=True)
    urls = [u for u in (url, fallback_url) if u]
    last_error: Exception | None = None
    for index, candidate in enumerate(urls):
        try:
            _download_one(candidate, dest, progress, cancel)
            return dest
        except Exception as exc:
            last_error = exc
            try:
                dest.unlink(missing_ok=True)
            except OSError:
                pass
            if index + 1 >= len(urls):
                break
    raise ModError(_friendly_download_error(last_error))


def _download_one(
    url: str,
    dest: Path,
    progress: ProgressFn | None,
    cancel: CancelToken | None,
) -> None:
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "*/*",
            "Referer": "https://discord.com/",
        },
    )
    with urllib.request.urlopen(request, timeout=45) as response:
        total = 0
        try:
            total = int(response.headers.get("Content-Length") or 0)
        except Exception:
            total = 0
        downloaded = 0
        tmp = dest.with_suffix(dest.suffix + ".part")
        with open(tmp, "wb") as fh:
            while True:
                if cancel is not None:
                    cancel.check()
                chunk = response.read(256 * 1024)
                if not chunk:
                    break
                fh.write(chunk)
                downloaded += len(chunk)
                if progress:
                    fraction = (downloaded / total) if total else None
                    progress(fraction, "stage_download")
        try:
            os.replace(tmp, dest)
        except OSError:
            shutil.move(str(tmp), str(dest))


def _friendly_download_error(exc: Exception | None) -> str:
    if isinstance(exc, urllib.error.HTTPError):
        if exc.code in (401, 403, 404, 410):
            return (
                "The download link has expired. Refresh the feed and try again."
            )
        return f"Download failed (HTTP {exc.code})."
    if isinstance(exc, urllib.error.URLError):
        return "Could not reach the download server. Check your connection."
    if exc is None:
        return "Download failed."
    return str(exc)
