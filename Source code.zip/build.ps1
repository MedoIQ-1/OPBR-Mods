param(
    [switch]$InstallDeps,
    [switch]$Console
)

$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot

$python = "python"
if (-not (Get-Command $python -ErrorAction SilentlyContinue)) {
    throw "Python was not found on PATH. Install Python 3.11+ and try again."
}

if ($InstallDeps) {
    & $python -m pip install --upgrade pip
    & $python -m pip install -r requirements.txt
}

$icon = Join-Path $PSScriptRoot "assets\app.ico"
$assets = Join-Path $PSScriptRoot "assets"

if (-not (Test-Path -LiteralPath $icon)) {
    throw "Missing assets\app.ico. Run: python tools\make_assets.py"
}

Write-Host "Cleaning previous build..." -ForegroundColor DarkGray
$running = Get-Process -Name "OPBR Skin Mods Installer" -ErrorAction SilentlyContinue
if ($running) {
    throw "Close the running OPBR Skin Mods Installer before building (PID: $($running.Id -join ', '))."
}
Remove-Item -Recurse -Force -ErrorAction SilentlyContinue "build", "dist", "OPBR Skin Mods Installer.spec"
if (Test-Path -LiteralPath "dist") {
    throw "Could not remove dist. Close any running copy of the app and try again."
}

$arguments = @(
    "-m", "PyInstaller",
    "--noconfirm",
    "--clean",
    "--onefile",
    "--name", "OPBR Skin Mods Installer",
    "--icon", $icon,
    "--add-data", "$assets;assets",
    "--exclude-module", "PySide6.QtWebEngineCore",
    "--exclude-module", "PySide6.QtWebEngineWidgets",
    "--exclude-module", "PySide6.QtMultimedia",
    "--exclude-module", "PySide6.QtQml",
    "--exclude-module", "PySide6.QtQuick"
)

if ($Console) {
    Write-Host "Building with a console window for diagnostics." -ForegroundColor Yellow
} else {
    $arguments += "--windowed"
}

$arguments += "run.py"

Write-Host "Building OPBR Skin Mods Installer..." -ForegroundColor Cyan
& $python @arguments
if ($LASTEXITCODE -ne 0) {
    throw "PyInstaller failed with exit code $LASTEXITCODE. See the log above."
}

$exe = Join-Path $PSScriptRoot "dist\OPBR Skin Mods Installer.exe"
if (-not (Test-Path -LiteralPath $exe)) {
    throw "Build finished but $exe was not produced."
}

$size = (Get-Item -LiteralPath $exe).Length / 1MB
Write-Host ""
Write-Host ("Done: {0} ({1:N1} MB)" -f $exe, $size) -ForegroundColor Green
