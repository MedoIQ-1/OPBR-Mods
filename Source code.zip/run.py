"""Launcher used both in development and by the packaged executable."""

from __future__ import annotations

import sys
from pathlib import Path

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parent))

from opbr_mods.main import main

if __name__ == "__main__":
    raise SystemExit(main())
