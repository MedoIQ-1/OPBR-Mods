"""Headless smoke test: builds the UI, renders pages, and exercises the engine.

Run with:  set QT_QPA_PLATFORM=offscreen && python tools/smoke_test.py
"""

from __future__ import annotations

import json
import os
import shutil
import sys
import tempfile
import traceback
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

WORK = Path(tempfile.mkdtemp(prefix="opbr_smoke_"))
os.environ["APPDATA"] = str(WORK / "appdata")
os.environ["QT_QPA_PLATFORM"] = "offscreen"
SHOTS = WORK / "shots"
SHOTS.mkdir(parents=True, exist_ok=True)

from PySide6.QtCore import Qt  # noqa: E402
from PySide6.QtGui import QColor, QPixmap  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from opbr_mods import i18n  # noqa: E402
from opbr_mods.config import Config  # noqa: E402
from opbr_mods.feed import parse_feed  # noqa: E402
from opbr_mods.install import (  # noqa: E402
    cleanup_analysis,
    install_analysis,
    load_manifests,
    prepare_archive,
    uninstall_manifest,
    verify_manifest,
)
from opbr_mods.ui.common import set_animations  # noqa: E402
from opbr_mods.ui.theme import apply_theme  # noqa: E402

SAMPLE_FEED = {
    "generated_at": "2026-11-02T15:04:13.418Z",
    "total_mods": 2,
    "mods": [
        {
            "id": "111111111111111111",
            "title": "Kiuske Urahara (Winner Island Trafalgar Law)",
            "mod_name": "Kiuske Urahara",
            "character": "Winner Island Trafalgar Law",
            "description": "Replacing the model & textures",
            "author_name": "MedoIQ",
            "notes": "Enjoy ;)",
            "gameplay_url": "https://youtu.be/6imk7EN0bCk",
            "message_url": "https://discord.com/channels/1/2/3",
            "labels": ["Kiuske Urahara", "Law"],
            "zip_file": {
                "filename": "Kiuske Urahara.zip",
                "size": 7409383,
                "size_formatted": "7.07 MB",
                "url": "https://example.com/a.zip",
                "proxy_url": "",
            },
            "preview_images": [
                {"url": "https://example.com/a.png", "proxy_url": "", "filename": "preview.png"}
            ],
            "created_at": "2026-10-30T10:00:00Z",
            "updated_at": "2026-11-01T10:00:00Z",
        },
        {
            "id": "222222222222222222",
            "title": "Onigashima Zoro",
            "mod_name": "Onigashima Zoro",
            "character": "Roronoa Zoro",
            "description": "Dark suit variant",
            "author_name": "MedoIQ",
            "labels": ["Zoro"],
            "zip_file": {
                "filename": "zoro.zip",
                "size": 3400000,
                "size_formatted": "3.24 MB",
                "url": "https://example.com/b.zip",
            },
            "preview_images": [],
            "created_at": "2026-10-20T10:00:00Z",
            "updated_at": "2026-10-21T10:00:00Z",
        },
    ],
}

failures: list[str] = []


def check(name: str, condition: bool, detail: str = "") -> None:
    print(("PASS " if condition else "FAIL ") + name + (f"  [{detail}]" if detail else ""))
    if not condition:
        failures.append(name)


def make_png(path: Path, color: str = "#FF8A00") -> None:
    pix = QPixmap(480, 320)
    pix.fill(QColor("#101015"))
    from PySide6.QtGui import QPainter, QLinearGradient, QBrush, QFont

    painter = QPainter(pix)
    grad = QLinearGradient(0, 0, 480, 320)
    grad.setColorAt(0, QColor(color))
    grad.setColorAt(1, QColor("#0FABD0"))
    painter.fillRect(0, 0, 480, 320, QBrush(grad))
    painter.setPen(QColor("#FFFFFF"))
    font = QFont("Segoe UI", 44)
    font.setBold(True)
    painter.setFont(font)
    painter.drawText(pix.rect(), Qt.AlignmentFlag.AlignCenter, "PREVIEW")
    painter.end()
    pix.save(str(path))


def build_fake_game() -> Path:
    assets = WORK / "game" / "StreamingAssets" / "assets"
    (assets / "characters" / "law").mkdir(parents=True)
    (assets / "characters" / "law" / "model.unity3d").write_bytes(b"ORIGINAL-LAW" * 100)
    (assets / "characters" / "law" / "tex.unity3d").write_bytes(b"ORIGINAL-TEX" * 100)
    (assets / "characters" / "zoro" / "model.unity3d").parent.mkdir(parents=True)
    (assets / "characters" / "zoro" / "model.unity3d").write_bytes(b"ORIGINAL-ZORO" * 100)
    return assets


def build_fake_zip(assets: Path) -> Path:
    preview = WORK / "preview.png"
    make_png(preview)
    zip_path = WORK / "fake_mod.zip"
    with zipfile.ZipFile(zip_path, "w") as archive:
        archive.writestr("mod/characters/law/model.unity3d", b"MODDED-LAW" * 100)
        archive.writestr("mod/characters/law/tex.unity3d", b"MODDED-TEX" * 120)
        archive.writestr("preview.png", preview.read_bytes())
    return zip_path


def engine_test(assets: Path) -> None:
    config = Config()
    zip_path = build_fake_zip(assets)
    analysis = prepare_archive(zip_path, assets, config.ensure_temp())
    check("zip: nested mod folder detected", not analysis.original_mode)
    check("zip: 2 payload files", len(analysis.items) == 2, str(len(analysis.items)))
    check("zip: preview found", bool(analysis.preview_bytes))

    # A live mod once shipped a stray "- Copy.unity3d" file. Files that do not
    # exist in the game must be skipped instead of aborting the whole install.
    partial_zip = WORK / "partial_mod.zip"
    with zipfile.ZipFile(partial_zip, "w") as archive:
        archive.writestr("mod/characters/law/model.unity3d", b"PARTIAL-LAW" * 100)
        archive.writestr(
            "mod/characters/law/model - Copy.unity3d", b"STRAY-COPY" * 100
        )
    partial = prepare_archive(partial_zip, assets, config.ensure_temp())
    check(
        "zip: unmatched files are skipped",
        len(partial.items) == 1 and partial.missing == ["characters/law/model - Copy.unity3d"],
        f"items={len(partial.items)} missing={partial.missing}",
    )
    cleanup_analysis(partial)

    manifest = install_analysis(
        analysis,
        config.mods_dir,
        config.changelog_path,
        title="Smoke Test Mod",
        character="Trafalgar Law",
        author="MedoIQ",
        source="manual",
        source_zip=str(zip_path),
        game_mode="custom",
        auto_clear=False,
    )
    check("install: manifest written", Path(manifest.manifest_path).is_file())
    check(
        "install: target replaced",
        (assets / "characters" / "law" / "model.unity3d").read_bytes().startswith(b"MODDED-LAW"),
    )
    check("install: preview saved", bool(manifest.preview_path))

    result = verify_manifest(manifest)
    check("verify: clean install ok", result.ok, str([(i.rel, i.reason) for i in result.issues]))

    # Tamper with a file, verify detects it.
    target = assets / "characters" / "law" / "model.unity3d"
    target.write_bytes(b"EDITED-BY-USER" * 200)
    os.utime(target, None)
    result = verify_manifest(manifest)
    check("verify: tampering detected", not result.ok)
    check(
        "verify: reason is size/hash",
        any(i.reason in ("size", "hash", "date", "modified") for i in result.issues),
        str([(i.rel, i.reason) for i in result.issues]),
    )

    # Delete a file, verify reports missing.
    target.unlink()
    result = verify_manifest(manifest)
    check(
        "verify: missing detected",
        any(i.reason == "missing" for i in result.issues),
    )

    # Uninstall removes recorded files and manifest.
    deleted = uninstall_manifest(manifest, config.mods_dir, config.changelog_path)
    check("uninstall: at least one file removed", deleted >= 1, str(deleted))
    check("uninstall: manifest removed", not Path(manifest.manifest_path).exists())
    check("uninstall: other mod untouched", (assets / "characters" / "zoro" / "model.unity3d").is_file())

    # Restore archive.
    original_zip = WORK / "original.zip"
    with zipfile.ZipFile(original_zip, "w") as archive:
        archive.writestr("original/characters/law/model.unity3d", b"ORIGINAL-LAW" * 100)
    analysis = prepare_archive(original_zip, assets, config.ensure_temp())
    check("restore: original folder detected", analysis.original_mode)


def ui_test(assets: Path) -> None:
    app = QApplication.instance() or QApplication(sys.argv)
    config = Config()
    config.set("first_run", False)
    config.set("language_chosen", True)
    config.set("language", "en")
    config.set("game_mode", "custom")
    config.set("custom_assets", str(assets))
    config.set("animations", False)
    set_animations(False)
    i18n.set_language("en")
    apply_theme(app)

    for code in ("en", "ja", "es", "fr", "th", "ar"):
        i18n.set_language(code)
        label = i18n.tr("sidebar_donate")
        check(f"i18n: {code} donation strings", bool(label) and label != "sidebar_donate")
    i18n.set_language("en")

    from opbr_mods.config import resource_path

    check("assets: app icon", resource_path("assets", "app.ico").is_file())
    check("assets: binance qr", resource_path("assets", "binance_qr.png").is_file())

    from opbr_mods.main_window import MainWindow
    from opbr_mods.ui import page_browse

    # Keep the UI test offline: a real feed fetch would replace the sample
    # data asynchronously and make assertions timing-dependent.
    page_browse.fetch_feed = lambda _config: parse_feed(SAMPLE_FEED)

    window = MainWindow(config)
    window.resize(1320, 860)
    window.show()
    app.processEvents()

    feed = parse_feed(SAMPLE_FEED)
    check("feed: parsed 2 mods", len(feed.mods) == 2, str(len(feed.mods)))
    window.ctx.feed = feed
    browse = window._page_widgets["browse"]
    browse._on_feed(feed)
    app.processEvents()

    check("browse: cards created", len(browse._cards) == 2, str(len(browse._cards)))

    for key in ("browse", "installed", "manual", "settings"):
        window.navigate(key)
        for _ in range(6):
            app.processEvents()
        page = window._page_widgets[key]
        window.content.pages.setCurrentWidget(page)
        app.processEvents()
        shot = SHOTS / f"{key}.png"
        window.grab().save(str(shot))
        check(f"ui: {key} page rendered", shot.is_file() and shot.stat().st_size > 5000)

    # Search filter works.
    browse.search.setText("zoro")
    browse._rebuild_cards()
    app.processEvents()
    check(
        "browse: search filters",
        len(browse._cards) == 1,
        f"{len(browse._cards)} q={browse.search.text()!r} filter={browse._filter!r} "
        f"char={browse.char_combo.currentData()!r} feed={len(browse.ctx.feed.mods) if browse.ctx.feed else None} "
        f"matches={len(browse._filtered_mods())}",
    )
    browse.search.setText("")
    browse._rebuild_cards()
    app.processEvents()

    # Manual page warns about archive files that will be skipped.
    manual = window._page_widgets["manual"]
    window.navigate("manual")
    partial = prepare_archive(WORK / "partial_mod.zip", assets, config.ensure_temp())
    manual._show_analysis(partial)
    for _ in range(4):
        app.processEvents()
    check(
        "ui: manual missing-files banner",
        manual.missing_banner.isVisible() and bool(manual.missing_banner.toolTip()),
        f"visible={manual.missing_banner.isVisible()} tip={manual.missing_banner.toolTip()!r}",
    )
    window.grab().save(str(SHOTS / "manual_missing.png"))
    cleanup_analysis(partial)
    manual._reset()
    app.processEvents()

    # Arabic RTL rebuild.
    window.apply_language("ar")
    for _ in range(10):
        app.processEvents()
    check(
        "ui: arabic is RTL",
        app.layoutDirection() == Qt.LayoutDirection.RightToLeft,
    )
    window.grab().save(str(SHOTS / "arabic.png"))
    window.apply_language("ja")
    for _ in range(10):
        app.processEvents()
    window.grab().save(str(SHOTS / "japanese.png"))

    window.close()
    app.processEvents()


def detection_test() -> None:
    """The standard LocalLow folder is picked up without pressing Detect."""
    profile = WORK / "fake_profile"
    assets = (
        profile
        / "AppData"
        / "LocalLow"
        / "Bandai Namco Entertainment Inc_"
        / "ONE PIECE BountyRush"
        / "StreamingAssets"
        / "assets"
    )
    (assets / "characters").mkdir(parents=True)
    old_profile = os.environ.get("USERPROFILE")
    old_appdata = os.environ.get("APPDATA")
    os.environ["USERPROFILE"] = str(profile)
    os.environ["APPDATA"] = str(WORK / "detect_appdata")
    try:
        config = Config()
        check(
            "config: standard game folder auto-detected",
            config.assets_root() == assets,
            f"mode={config.game_mode} detected={config.detected()}",
        )
    finally:
        os.environ["USERPROFILE"] = old_profile
        os.environ["APPDATA"] = old_appdata
        shutil.rmtree(WORK / "detect_appdata", ignore_errors=True)


def main() -> int:
    # A QGuiApplication is required before any QPixmap is constructed (the
    # engine test builds a real preview image).
    app = QApplication.instance() or QApplication(sys.argv)
    assets = build_fake_game()
    try:
        engine_test(assets)
    except Exception:
        failures.append("engine_test crashed")
        traceback.print_exc()
    # engine_test uninstalls; wipe config for a clean UI run.
    shutil.rmtree(WORK / "appdata" / "MedoIQ", ignore_errors=True)
    try:
        detection_test()
    except Exception:
        failures.append("detection_test crashed")
        traceback.print_exc()
    shutil.rmtree(WORK / "appdata" / "MedoIQ", ignore_errors=True)
    try:
        ui_test(assets)
    except Exception:
        failures.append("ui_test crashed")
        traceback.print_exc()

    print()
    print(f"Screenshots: {SHOTS}")
    if failures:
        print(f"FAILURES ({len(failures)}): " + ", ".join(failures))
        return 1
    print("ALL SMOKE TESTS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
