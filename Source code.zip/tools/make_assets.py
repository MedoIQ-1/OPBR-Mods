﻿"""Regenerate bundled assets from the source artwork.

Usage: python tools/make_assets.py

Reads IMG_20261103_060938.jpg (app artwork) and
binance-1793673662477.png (Binance Pay poster) from the project root and
writes assets/app.png, assets/app.ico and assets/binance_qr.png.
"""

from __future__ import annotations

from pathlib import Path

from PIL import Image
import numpy as np

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / "assets"
ASSETS.mkdir(exist_ok=True)

art = Image.open(ROOT / "IMG_20261103_060938.jpg").convert("RGB")
width, height = art.size
side = min(width, height)
art = art.crop(
    ((width - side) // 2, (height - side) // 2, (width + side) // 2, (height + side) // 2)
)
art = art.resize((512, 512), Image.LANCZOS)
art.save(ASSETS / "app.png", optimize=True)
art.resize((256, 256), Image.LANCZOS).save(
    ASSETS / "app.ico",
    format="ICO",
    sizes=[(256, 256), (128, 128), (64, 64), (48, 48), (32, 32), (16, 16)],
)

poster = Image.open(ROOT / "binance-1793673662477.png").convert("RGB")
pixels = np.asarray(poster)
white = (pixels[:, :, 0] > 245) & (pixels[:, :, 1] > 245) & (pixels[:, :, 2] > 245)
rows = white.sum(axis=1)
row_ids = [y for y in range(poster.height) if rows[y] >= 650]
columns = white[row_ids[0] : row_ids[-1] + 1].sum(axis=0)
column_ids = [x for x in range(poster.width) if columns[x] >= 600]
box = (column_ids[0], row_ids[0], column_ids[-1] + 1, row_ids[-1] + 1)
poster.crop(box).save(ASSETS / "binance_qr.png", optimize=True)

print(f"app.png + app.ico written, QR crop {box}")
