"""Render real screenshots using the native Windows platform.

Usage: python tools/render_shots.py [outdir]
"""

from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

OUT = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "screenshots"
OUT.mkdir(parents=True, exist_ok=True)
os.environ["APPDATA"] = str(Path(tempfile.mkdtemp(prefix="opbr_shots_")) / "appdata")

from PySide6.QtCore import QTimer, Qt  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from opbr_mods import i18n  # noqa: E402
from opbr_mods.config import Config  # noqa: E402
from opbr_mods.feed import parse_feed  # noqa: E402
from opbr_mods.main_window import MainWindow  # noqa: E402
from opbr_mods.ui.common import set_animations  # noqa: E402
from opbr_mods.ui.icons import app_pixmap  # noqa: E402
from opbr_mods.ui.theme import apply_theme  # noqa: E402

SAMPLE = {
    "generated_at": "2026-11-02T15:04:13.418Z",
    "total_mods": 3,
    "mods": [
        {
            "id": "111111111111111111",
            "title": "Kiuske Urahara (Winner Island Trafalgar Law)",
            "mod_name": "Kiuske Urahara",
            "character": "Winner Island Trafalgar Law",
            "description": "Replacing the model & textures",
            "author_name": "MedoIQ",
            "notes": "Enjoy ;)",
            "gameplay_url": "https://youtu.be/6imk7EN0bCk",
            "message_url": "https://discord.com/channels/1/2/3",
            "labels": ["Kiuske Urahara", "Law"],
            "zip_file": {
                "filename": "Kiuske Urahara.zip",
                "size": 7409383,
                "size_formatted": "7.07 MB",
                "url": "https://example.com/a.zip",
            },
            "preview_images": [{"url": "https://example.com/a.png", "filename": "preview.png"}],
            "created_at": "2026-10-30T10:00:00Z",
            "updated_at": "2026-11-01T10:00:00Z",
        },
        {
            "id": "222222222222222222",
            "title": "Onigashima Zoro",
            "mod_name": "Onigashima Zoro",
            "character": "Roronoa Zoro",
            "description": "Dark suit variant",
            "author_name": "MedoIQ",
            "labels": ["Zoro"],
            "zip_file": {
                "filename": "zoro.zip",
                "size": 3400000,
                "size_formatted": "3.24 MB",
                "url": "https://example.com/b.zip",
            },
            "preview_images": [],
            "created_at": "2026-10-20T10:00:00Z",
        },
        {
            "id": "333333333333333333",
            "title": "Wano Sanji",
            "mod_name": "Wano Sanji",
            "character": "Vinsmoke Sanji",
            "description": "Raid suit colours",
            "author_name": "MedoIQ",
            "labels": ["Sanji"],
            "zip_file": {
                "filename": "sanji.zip",
                "size": 5200000,
                "size_formatted": "4.96 MB",
                "url": "https://example.com/c.zip",
            },
            "preview_images": [],
            "created_at": "2026-10-12T10:00:00Z",
        },
    ],
}


def main() -> int:
    app = QApplication(sys.argv)
    config = Config()
    config.set("first_run", False)
    config.set("language_chosen", True)
    config.set("language", "en")
    config.set("animations", False)
    set_animations(False)
    i18n.set_language("en")
    apply_theme(app)
    app.setWindowIcon(app_pixmap(64))

    from opbr_mods.ui import page_browse

    page_browse.fetch_feed = lambda _config: parse_feed(SAMPLE)

    window = MainWindow(config)
    window.resize(1400, 900)
    window.show()
    for _ in range(20):
        app.processEvents()

    feed = parse_feed(SAMPLE)
    window.ctx.feed = feed
    browse = window._page_widgets["browse"]
    browse._on_feed(feed)
    for _ in range(20):
        app.processEvents()

    def shot(name: str) -> None:
        for _ in range(20):
            app.processEvents()
        path = OUT / f"{name}.png"
        window.grab().save(str(path))
        print("saved", path)

    for key in ("browse", "installed", "manual", "settings"):
        window.navigate(key)
        shot(key)

    # Arabic + Japanese
    window.apply_language("ar")
    for _ in range(30):
        app.processEvents()
    window.navigate("browse")
    shot("browse_arabic")
    window.navigate("settings")
    shot("settings_arabic")

    from opbr_mods.ui.dialogs_extra import DonateDialog

    dialog = DonateDialog(window)
    dialog.show()
    for _ in range(30):
        app.processEvents()
    dialog.grab().save(str(OUT / "donate_arabic.png"))
    print("saved", OUT / "donate_arabic.png")
    dialog.close()

    window.apply_language("ja")
    for _ in range(30):
        app.processEvents()
    window.navigate("browse")
    shot("browse_japanese")
    window.navigate("settings")
    shot("settings_japanese")

    # Manual analysis screen
    window.apply_language("en")
    for _ in range(30):
        app.processEvents()
    window.navigate("manual")
    shot("manual_empty")

    # Manual analysis with a file that will be skipped (not in the game).
    import zipfile

    from opbr_mods.install import cleanup_analysis, prepare_archive

    shot_root = Path(tempfile.mkdtemp(prefix="opbr_shot_game_"))
    game_assets = shot_root / "assets"
    (game_assets / "characters" / "law").mkdir(parents=True)
    (game_assets / "characters" / "law" / "model.unity3d").write_bytes(b"ORIGINAL" * 20)
    demo_zip = shot_root / "demo.zip"
    with zipfile.ZipFile(demo_zip, "w") as archive:
        archive.writestr("mod/characters/law/model.unity3d", b"MODDED" * 20)
        archive.writestr(
            "mod/characters/law/model - Copy.unity3d", b"STRAY" * 20
        )
    analysis = prepare_archive(demo_zip, game_assets, shot_root / "work")
    manual = window._page_widgets["manual"]
    manual._show_analysis(analysis)
    shot("manual_missing")
    cleanup_analysis(analysis)
    manual._reset()

    window.navigate("browse")
    dialog = DonateDialog(window)
    dialog.show()
    for _ in range(30):
        app.processEvents()
    dialog.grab().save(str(OUT / "donate.png"))
    print("saved", OUT / "donate.png")
    dialog.close()

    window.close()
    print("done")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
